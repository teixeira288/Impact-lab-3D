// deformation.wgsl - deformação procedural da carroceria em compute shader.
//
// O módulo físico (C/WASM) calcula, a cada passo, o esmagamento de 36 pontos de contato (c_i, direção local e
// capacidade). Aqui a GPU converte esse campo compacto (36 x 2 vec4) em deslocamento de cada vértice da malha
// (milhares de vértices em paralelo) e depois recalcula as normais por adjacência (sem atomics).
// O deslocamento é sempre função da posição de repouso + estado de esmagamento => persiste após o impacto.

struct Field {
  a: array<vec4f, 36>,   // lx, lz, dirx, dirz (direção local em que a carroceria é empurrada)
  b: array<vec4f, 36>,   // c (m), cap (m), sigma lateral (m), face (0 frente,1 traseira,2 esq,3 dir)
  info: vec4f,           // x: altura da linha de cintura (m)
};

@group(0) @binding(0) var<storage, read> rest: array<vec4f>;
@group(0) @binding(1) var<storage, read> restN: array<vec4f>;
@group(0) @binding(2) var<storage, read_write> outPos: array<vec4f>;
@group(0) @binding(3) var<uniform> field: Field;
@group(0) @binding(4) var<uniform> params: vec4<u32>;

@compute @workgroup_size(64)
fn displace(@builtin(global_invocation_id) gid: vec3u) {
  let i = gid.x;
  if (i >= params.x) { return; }
  let r = rest[i];
  let p = r.xyz;
  let rn = restN[i].xyz;

  var mag4 = 0.0;
  var dirAcc = vec2f(0.0);
  var lift = 0.0;
  for (var s = 0u; s < 36u; s++) {
    let A = field.a[s];
    let B = field.b[s];
    let c = B.x;
    if (c < 0.002) { continue; }
    let dir = normalize(A.zw + vec2f(1e-6, 0.0));
    let rel = vec2f(p.x - A.x, p.z - A.y);
    let along = dot(rel, dir);                       // > 0: mais fundo na carroceria
    let perp = dot(rel, vec2f(-dir.y, dir.x));
    let g = exp(-(perp * perp) / (2.0 * B.z * B.z));
    let dcr = max(1.7 * B.y, 0.7);
    let prof = pow(1.0 - clamp(max(along, 0.0) / dcr, 0.0, 1.0), 1.5);
    let ahead = smoothstep(-0.55, -0.12, along);
    let vf = 1.0 - 0.55 * smoothstep(field.info.x + 0.05, field.info.x + 0.60, p.y);
    let cc = min(c, 1.03 * B.y);
    let m = cc * g * prof * ahead * vf;
    let m4 = m * m * m * m;
    mag4 += m4;
    dirAcc += dir * m4;
    // capô / porta-malas dobrados para cima (somente superfícies voltadas para cima, impactos frontal/traseiro)
    if (B.w < 1.5) {
      let bump = sin(PI_ * clamp(max(along, 0.0) / (dcr * 0.78), 0.0, 1.0));
      lift = max(lift, cc * 0.40 * bump * g * ahead * max(rn.y, 0.0));
    }
  }
  var o = p;
  var dmg = 0.0;
  if (mag4 > 1e-12) {
    let M = sqrt(sqrt(mag4));
    let dv = normalize(dirAcc + vec2f(1e-9, 0.0));
    // amassados: ruído determinístico na posição de repouso (sempre o mesmo para os mesmos parâmetros)
    let n1 = sin(p.x * 41.0 + p.z * 17.0) * sin(p.z * 33.0 - p.y * 23.0) + 0.5 * sin(p.x * 83.0 - p.y * 61.0 + p.z * 29.0);
    let wr = 0.05 * smoothstep(0.02, 0.30, M) * n1;
    o = p + vec3f(dv.x * M, lift, dv.y * M) + rn * wr;
    dmg = clamp(M / 0.40 + lift * 1.5, 0.0, 1.0);
  }
  outPos[i] = vec4f(o, dmg);
}

const PI_: f32 = 3.14159265359;

// ---------------------------------------------------------------------------------------------
// normais por adjacência (CSR): soma ponderada por área das normais das faces incidentes
// ---------------------------------------------------------------------------------------------
@group(0) @binding(0) var<storage, read> pos: array<vec4f>;
@group(0) @binding(1) var<storage, read> idx: array<u32>;
@group(0) @binding(2) var<storage, read> adjOff: array<u32>;
@group(0) @binding(3) var<storage, read> adjList: array<u32>;
@group(0) @binding(4) var<storage, read_write> nrm: array<vec4f>;
@group(0) @binding(5) var<uniform> nparams: vec4<u32>;

@compute @workgroup_size(64)
fn normals(@builtin(global_invocation_id) gid: vec3u) {
  let i = gid.x;
  if (i >= nparams.x) { return; }
  var n = vec3f(0.0);
  let a0 = adjOff[i];
  let a1 = adjOff[i + 1u];
  for (var k = a0; k < a1; k++) {
    let t = adjList[k];
    let p0 = pos[idx[3u * t]].xyz;
    let p1 = pos[idx[3u * t + 1u]].xyz;
    let p2 = pos[idx[3u * t + 2u]].xyz;
    n += cross(p1 - p0, p2 - p0);
  }
  let l = length(n);
  if (l < 1e-12) { nrm[i] = vec4f(0.0, 0.0, 1.0, 0.0); return; }
  nrm[i] = vec4f(n / l, 0.0);
}
