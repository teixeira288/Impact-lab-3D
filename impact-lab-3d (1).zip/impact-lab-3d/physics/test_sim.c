/*
 * Testes de consistência física do motor (build nativo):  make test
 * Verifica distância inicial, velocidade real x alvo, impulso x quantidade de movimento,
 * balanço de energia, determinismo, reinício, escalas de massa/velocidade/obstáculo e ângulos.
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "sim.h"

static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { checks++; if (!(cond)) { fails++; printf("  FALHOU: "); printf(__VA_ARGS__); printf("\n"); } } while (0)

static const float DT = 1.0f / 480.0f;
typedef struct {
    double vbefore_kmh, target_kmh, crush_front, crush_left, crush_rear, peak_g, J, ke0, e_crush, e_fric, ke_after, m;
    double vz0, vz_end, yaw_deg, dist0, zfinal, damage, steer_t;
    double zone[Z_COUNT];
    unsigned broken;
    double obs_travel, vnorm;
} Res;

static Res run(int veh, int motor, float extra, int obs, float target, int face, float ang, float off, double tmax) {
    Res r; memset(&r, 0, sizeof r);
    sim_configure(veh, motor, extra, obs, target, face, ang, off, 0);
    float *o = sim_out();
    r.dist0 = o[O_DIST];
    sim_start();
    int contact_end = 0;
    r.m = o[O_MASS];
    for (int i = 0; i < (int)(tmax * 480); i++) {
        sim_step(DT);
        if (o[O_IMPACTED] > 0.5 && r.vz0 == 0.0) r.vz0 = o[O_VZ];
        if (o[O_IMPACTED] > 0.5 && !contact_end && o[O_NCONTACT] < 0.5 && o[O_EVENTS] > 0) {
            contact_end = 1;
            r.vz_end = o[O_VZ]; r.J = o[O_IMPULSE];
            r.e_crush = o[O_ECRUSH]; r.e_fric = o[O_EFRIC];
            r.ke_after = o[O_KENOW];
        }
        if (o[O_PHASE] == PH_SETTLED) break;
    }
    r.vbefore_kmh = o[O_VBEFORE] * 3.6; r.target_kmh = target;
    float *c = sim_crush();
    for (int k = 0; k < 9; k++) {
        if (c[k] > r.crush_front) r.crush_front = c[k];
        if (c[9 + k] > r.crush_rear) r.crush_rear = c[9 + k];
        if (c[18 + k] > r.crush_left) r.crush_left = c[18 + k];
    }
    r.peak_g = o[O_PEAKG]; r.ke0 = o[O_KE0];
    r.yaw_deg = o[O_YAWDEG_IMP]; r.zfinal = o[O_Z]; r.damage = o[O_DAMAGE];
    for (int z = 0; z < Z_COUNT; z++) r.zone[z] = o[O_ZONE0 + 2 * z];
    r.broken = (unsigned)o[O_BROKEN]; r.obs_travel = o[O_OBSTRAVEL]; r.vnorm = o[O_VNORM];
    return r;
}

int main(void) {
    printf("Impact Lab 3D - testes físicos (sim v%d)\n", sim_version());
    CHECK(sim_out_count() == SIM_OUT_COUNT, "contagem de saída");

    printf("[1] Distância inicial = 200 m (todos os veículos e faces)\n");
    for (int v = 0; v < 3; v++)
        for (int f = 0; f < 4; f++) {
            sim_configure(v, 1, 0, 0, 80, f, 0, 0, 0);
            CHECK(fabs(sim_out()[O_DIST] - 200.0) < 1e-3, "veh %d face %d dist=%f", v, f, sim_out()[O_DIST]);
        }
    sim_configure(0, 0, 0, 0, 80, 0, 25, 0, 1);
    CHECK(fabs(sim_out()[O_DIST] - 200.0) < 1e-3, "manual dist");

    printf("[2] Velocidade real de impacto x alvo (sedan, motor esportivo)\n");
    double targets[6] = {30, 50, 80, 100, 120, 150};
    double prev_crush = -1, prev_g = -1;
    for (int i = 0; i < 6; i++) {
        Res r = run(VEH_SEDAN, 1, 0, 0, (float)targets[i], FACE_FRONT, 0, 0, 40);
        printf("   alvo %5.0f km/h -> real %7.2f km/h | lançamento %5.1f km/h | esmag. %.3f m | pico %6.1f g | dano %.2f\n",
               targets[i], r.vbefore_kmh, sim_out()[O_LAUNCH] * 3.6, r.crush_front, r.peak_g, r.damage);
        CHECK(fabs(r.vbefore_kmh - targets[i]) / targets[i] < 0.02, "alvo %.0f real %.2f", targets[i], r.vbefore_kmh);
        CHECK(r.crush_front > prev_crush, "esmagamento deve crescer com a velocidade");
        CHECK(r.peak_g > prev_g, "pico de g deve crescer com a velocidade");
        CHECK(r.dist0 > 199.999 && r.dist0 < 200.001, "dist0");
        prev_crush = r.crush_front; prev_g = r.peak_g;
    }

    printf("[3] Impulso x quantidade de movimento e [4] balanço de energia (frontal, 80 km/h)\n");
    for (int v = 0; v < 3; v++) {
        Res r = run(v, 1, 0, OBS_WALL, 80, FACE_FRONT, 0, 0, 30);
        double dp = r.m * (r.vz0 - r.vz_end);
        double e_in = r.ke0;
        double e_out = r.e_crush + r.e_fric + r.ke_after;
        printf("   veh %d: J=%.0f N.s  m*dv=%.0f N.s | KE0=%.0f J  crush+fric+KE_after=%.0f J\n", v, r.J, dp, e_in, e_out);
        CHECK(fabs(r.J - dp) / dp < 0.03, "impulso x momento veh %d (%.0f vs %.0f)", v, r.J, dp);
        CHECK(fabs(e_in - e_out) / e_in < 0.04, "energia veh %d (%.0f vs %.0f)", v, e_in, e_out);
    }

    printf("[5] Determinismo\n");
    {
        Res a = run(1, 2, 100, OBS_WALL, 100, FACE_FRONT, 12, 0.3f, 30);
        Res b = run(1, 2, 100, OBS_WALL, 100, FACE_FRONT, 12, 0.3f, 30);
        CHECK(memcmp(&a, &b, sizeof(Res)) == 0, "duas execuções idênticas divergem");
    }

    printf("[6] Reinício restaura estado\n");
    {
        sim_configure(0, 2, 0, 0, 100, 0, 0, 0, 0);
        float fresh[SIM_OUT_COUNT]; memcpy(fresh, sim_out(), sizeof fresh);
        sim_start();
        for (int i = 0; i < 480 * 12; i++) sim_step(DT);
        CHECK(sim_out()[O_T] > 11.0, "simulação avançou");
        sim_reset();
        CHECK(memcmp(fresh, sim_out(), sizeof fresh) == 0, "reset difere do estado inicial");
        float *c = sim_crush(); double sc = 0; for (int i = 0; i < SIM_NSAMP; i++) sc += c[i];
        CHECK(sc == 0.0, "esmagamento zerado");
        /* pausa: sem sim_step o tempo não avança */
        float t0 = sim_out()[O_T];
        CHECK(t0 == 0.0f, "t=0 após reset");
    }

    printf("[7] Massa, obstáculo e velocidade\n");
    {
        Res light = run(VEH_SEDAN, 1, -100, OBS_WALL, 100, FACE_FRONT, 0, 0, 30);
        Res heavy = run(VEH_SEDAN, 1, 500, OBS_WALL, 100, FACE_FRONT, 0, 0, 30);
        printf("   massa leve %.0f kg: %.3f m  | pesada %.0f kg: %.3f m (100 km/h)\n", light.m, light.crush_front, heavy.m, heavy.crush_front);
        CHECK(heavy.crush_front > light.crush_front, "mais massa => mais esmagamento");
        CHECK(heavy.ke0 > light.ke0, "mais massa => mais energia");
        Res wall = run(VEH_SEDAN, 1, 0, OBS_WALL, 80, FACE_FRONT, 0, 0, 30);
        Res bar = run(VEH_SEDAN, 1, 0, OBS_BARRIER, 80, FACE_FRONT, 0, 0, 30);
        Res pole = run(VEH_SEDAN, 1, 0, OBS_POLE, 80, FACE_FRONT, 0, 0, 30);
        printf("   80 km/h: parede %.3f m (%.0f g) | barreira %.3f m (%.0f g, curso %.2f m) | poste %.3f m (%.0f g)\n",
               wall.crush_front, wall.peak_g, bar.crush_front, bar.peak_g, bar.obs_travel, pole.crush_front, pole.peak_g);
        CHECK(bar.crush_front < wall.crush_front, "barreira deve reduzir o esmagamento");
        CHECK(bar.peak_g < wall.peak_g, "barreira deve reduzir o pico de g");
        CHECK(pole.crush_front > wall.crush_front, "poste concentra o esmagamento");
        Res h = run(VEH_HATCH, 1, 0, 0, 100, 0, 0, 0, 30), s = run(VEH_SEDAN, 1, 0, 0, 100, 0, 0, 0, 30), u = run(VEH_SUV, 1, 0, 0, 100, 0, 0, 0, 30);
        printf("   100 km/h: hatch %.0f kg KE %.0f kJ %.3f m | sedan %.0f kg KE %.0f kJ %.3f m | SUV %.0f kg KE %.0f kJ %.3f m\n",
               h.m, h.ke0 / 1e3, h.crush_front, s.m, s.ke0 / 1e3, s.crush_front, u.m, u.ke0 / 1e3, u.crush_front);
        CHECK(h.ke0 < s.ke0 && s.ke0 < u.ke0, "energia cinética ordenada pela massa");
        CHECK(fabs(h.ke0 - 0.5 * h.m * pow(h.vbefore_kmh / 3.6, 2)) / h.ke0 < 1e-3, "E = 1/2 m v^2");
    }

    printf("[8] Impacto angulado, offset, lateral (trenó) e traseiro\n");
    {
        Res a = run(VEH_SEDAN, 1, 0, 0, 80, FACE_FRONT, 20, 0, 30);
        printf("   frontal 20 graus: guinada pós-impacto %.1f graus\n", a.yaw_deg);
        CHECK(fabs(a.yaw_deg) > 3.0, "impacto angulado deve gerar guinada");
        Res b = run(VEH_SEDAN, 1, 0, OBS_BLOCK, 80, FACE_FRONT, 0, 1.2f, 30);
        Res b0 = run(VEH_SEDAN, 1, 0, OBS_BLOCK, 80, FACE_FRONT, 0, 0.0f, 30);
        printf("   bloco de 2 m, offset +1,2 m: guinada %.1f graus (centrado: %.1f)\n", b.yaw_deg, b0.yaw_deg);
        CHECK(fabs(b.yaw_deg) > 5.0 && fabs(b0.yaw_deg) < 0.5, "impacto deslocado (overlap parcial) deve girar; centrado não");
        Res l = run(VEH_SEDAN, 1, 0, 0, 50, FACE_LEFT, 0, 0, 30);
        printf("   lateral esquerda 50 km/h: esmag. lateral %.3f m, frente %.3f m, zonas L=%.2f R=%.2f estr=%.2f\n",
               l.crush_left, l.crush_front, l.zone[Z_LEFT], l.zone[Z_RIGHT], l.zone[Z_STRUCT]);
        CHECK(l.crush_left > 0.05 && l.zone[Z_FRONT] < 0.05, "impacto lateral deforma a lateral e não a frente");
        CHECK(l.zone[Z_LEFT] > 0.3 && l.zone[Z_RIGHT] < 0.01, "mapa de danos lateral esquerda");
        Res rr = run(VEH_SEDAN, 1, 0, 0, 40, FACE_REAR, 0, 0, 40);
        printf("   traseira 40 km/h: real %.1f km/h, esmag. traseiro %.3f m, frente %.3f m, zona traseira %.2f\n",
               rr.vbefore_kmh, rr.crush_rear, rr.crush_front, rr.zone[Z_REAR]);
        CHECK(rr.crush_rear > 0.05 && rr.zone[Z_FRONT] < 0.02, "impacto traseiro deforma a traseira");
        CHECK(fabs(rr.vbefore_kmh - 40) < 1.2, "ré atinge velocidade alvo");
    }

    printf("[9] Sem atravessamento a 150 km/h (todos os veículos)\n");
    for (int v = 0; v < 3; v++) {
        Res r = run(v, 2, 0, 0, 150, 0, 0, 0, 40);
        printf("   veh %d: real %.1f km/h, esmag. %.3f m, pico %.0f g, CG z final %.2f m, dano %.2f, quebrados 0x%x\n",
               v, r.vbefore_kmh, r.crush_front, r.peak_g, r.zfinal, r.damage, r.broken);
        CHECK(r.zfinal < 0.2, "o CG não pode atravessar a parede (z=%.2f)", r.zfinal);
        CHECK(r.crush_front > 0.5, "grande esmagamento a 150 km/h");
        CHECK(r.zone[Z_FRONT] > 0.7, "zona frontal severa a 150 km/h");
    }

    printf("[10] Especificações simuladas\n");
    for (int v = 0; v < 3; v++)
        for (int m = 0; m < 3; m++) {
            sim_vehicle_dims(v, m, 0);
            float *s = sim_spec_ptr();
            printf("   veh %d motor %d: %.0f kg %.0f cv %.0f Nm | 0-100 %.1f s | vmax %.0f km/h | %.2f x %.2f m\n",
                   v, m, s[S_MASS], s[S_POWER], s[S_TORQUE], s[S_0100], s[S_VMAX], s[S_LENGTH], s[S_WIDTH]);
            CHECK(s[S_0100] > 4.0 && s[S_0100] < 20.0, "0-100 plausível");
            CHECK(s[S_VMAX] > 150.0 && s[S_VMAX] < 280.0, "vmax plausível");
        }

    printf("\n%d verificações, %d falhas\n", checks, fails);
    return fails ? 1 : 0;
}
