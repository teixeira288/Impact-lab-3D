// scene.wgsl - pista de testes, parede/obstáculos, edifícios, garagem e céu (materiais procedurais)
// Pressupõe lighting.wgsl concatenado antes.

struct ObjU {
  model: mat4x4f,
  tint: vec4f,
};
@group(1) @binding(0) var<uniform> obj: ObjU;

struct SOut {
  @builtin(position) clip: vec4f,
  @location(0) wpos: vec3f,
  @location(1) wn: vec3f,
  @location(2) uv: vec2f,
  @location(3) @interpolate(flat) mat: u32,
  @location(4) lpos: vec3f,
};

@vertex
fn vs_scene(@location(0) pos: vec3f, @location(1) nrm: vec3f, @location(2) uv: vec2f, @location(3) mat: f32) -> SOut {
  var o: SOut;
  let wp = obj.model * vec4f(pos, 1.0);
  o.clip = frame.viewProj * wp;
  o.wpos = wp.xyz;
  o.wn = normalize((obj.model * vec4f(nrm, 0.0)).xyz);
  o.uv = uv;
  o.mat = u32(mat + 0.5);
  o.lpos = pos;
  return o;
}

@vertex
fn vs_shadow_scene(@location(0) pos: vec3f) -> @builtin(position) vec4f {
  return frame.lightVP * obj.model * vec4f(pos, 1.0);
}

fn lineMask(d: f32, w: f32) -> f32 {
  return smoothstep(w, w * 0.5, d);
}

@fragment
fn fs_scene(in: SOut) -> @location(0) vec4f {
  let N = normalize(in.wn);   // normais explícitas por vértice (geometria dupla face: cull none)
  let V = normalize(frame.camPos.xyz - in.wpos);
  let wp = in.wpos;
  let night = frame.params.y;
  var albedo = vec3f(0.5);
  var metallic = 0.0;
  var rough = 0.8;
  var emissive = vec3f(0.0);
  var ao = 1.0;
  let m = in.mat;

  if (m == 0u) {
    // asfalto de teste
    let n1 = fbm(wp.xz * 0.35);
    let fine = hash21(floor(wp.xz * 55.0));
    var base = vec3f(0.105) + 0.045 * n1 + 0.025 * fine;
    let polish = smoothstep(2.6, 0.4, abs(wp.x));
    base *= 1.0 - 0.18 * polish;
    // remendos e manchas
    base *= 0.85 + 0.3 * smoothstep(0.45, 0.7, fbm(wp.xz * 0.9 + 4.0));
    var mark = 0.0;
    let ax = abs(wp.x);
    mark = max(mark, lineMask(abs(ax - 6.45), 0.09));
    let dash = step(fract(wp.z / 9.0), 0.33);
    mark = max(mark, dash * lineMask(ax, 0.09));
    let kz = abs(wp.z / 25.0 - round(wp.z / 25.0)) * 25.0;
    let major = select(1.0, 2.0, abs(wp.z / 100.0 - round(wp.z / 100.0)) * 100.0 < 0.4);
    mark = max(mark, lineMask(kz, 0.11 * major) * step(ax, 6.4) * step(wp.z, 1.0));
    // linha de largada (referência frontal a 200 m): xadrez
    let sl = step(abs(wp.z + 200.0), 0.30) * step(ax, 6.4);
    let chk = step(0.5, fract((floor(wp.x / 0.3) + floor((wp.z + 200.0) / 0.3)) * 0.5));
    mark = max(mark, sl * (0.4 + 0.6 * chk));
    let wear = 0.55 + 0.45 * fbm(wp.xz * 3.0);
    albedo = mix(base, vec3f(0.72, 0.72, 0.7), clamp(mark * wear, 0.0, 1.0));
    rough = mix(0.88, 0.5, polish * 0.4);
  } else if (m == 1u) {
    let g = fbm(wp.xz * 0.8);
    let stripe = 0.85 + 0.15 * sin(wp.x * 0.45);
    albedo = mix(vec3f(0.028, 0.085, 0.02), vec3f(0.05, 0.13, 0.03), g) * stripe;
    rough = 1.0;
  } else if (m == 2u) {
    // concreto com juntas de painel e manchas
    var uvw = wp.xy;
    if (abs(N.x) > 0.7) { uvw = wp.zy; }
    if (abs(N.y) > 0.7) { uvw = wp.xz; }
    let seamX = lineMask(abs(fract(uvw.x / 3.0 + 0.5) - 0.5) * 3.0, 0.02);
    let seamY = lineMask(abs(fract(uvw.y / 1.5 + 0.5) - 0.5) * 1.5, 0.02);
    let stain = fbm(vec2f(uvw.x * 1.7, uvw.y * 0.22));
    var c = vec3f(0.50, 0.50, 0.48) * (0.82 + 0.3 * fbm(uvw * 2.2)) * (0.85 + 0.25 * hash21(floor(uvw * 80.0)));
    c *= 1.0 - 0.28 * smoothstep(0.5, 0.8, stain);
    c *= 1.0 - 0.55 * max(seamX, seamY);
    albedo = c;
    rough = 0.92;
    ao = mix(0.55, 1.0, smoothstep(0.0, 0.5, wp.y));
  } else if (m == 3u) {
    albedo = vec3f(0.55, 0.56, 0.58) * (0.85 + 0.2 * hash21(floor(wp.xz * 10.0 + wp.y * 3.0)));
    metallic = 0.8;
    rough = 0.45;
  } else if (m == 4u) {
    let ln = lineMask(abs(fract(wp.y / 2.2 + 0.5) - 0.5) * 2.2, 0.03);
    albedo = vec3f(0.72, 0.73, 0.74) * (1.0 - 0.4 * ln);
    rough = 0.7;
  } else if (m == 5u) {
    var uvw = vec2f(wp.x + wp.z, wp.y);
    let fx = fract(uvw.x / 1.6);
    let fy = fract(uvw.y / 1.3);
    let frameLine = max(lineMask(abs(fx - 0.5) * 1.6 - 0.74, 0.04), lineMask(abs(fy - 0.5) * 1.3 - 0.60, 0.04));
    albedo = vec3f(0.02, 0.04, 0.06);
    metallic = 0.0;
    rough = 0.05;
    let cell = floor(vec2f(uvw.x / 1.6, uvw.y / 1.3));
    let lit = step(0.55, hash21(cell)) * night;
    emissive = vec3f(1.0, 0.82, 0.55) * lit * 1.4 * (1.0 - frameLine);
    albedo = mix(albedo, vec3f(0.12, 0.12, 0.13), frameLine);
  } else if (m == 6u) {
    emissive = vec3f(1.0, 0.85, 0.6) * (2.5 + 14.0 * night);
    albedo = vec3f(0.9);
  } else if (m == 7u) {
    let c = textureSampleLevel(atlasTex, atlasSamp, in.uv, 0.0);
    if (c.a < 0.12) { discard; }
    albedo = c.rgb;
    rough = 0.6;
    emissive = c.rgb * (0.10 + 0.9 * night);
  } else if (m == 8u) {
    let st = step(fract(wp.z / 3.0), 0.5);
    albedo = mix(vec3f(0.75, 0.04, 0.04), vec3f(0.85, 0.85, 0.85), st);
    rough = 0.6;
  } else if (m == 9u) {
    let d = fract((wp.x + wp.y * 1.0) * 0.9);
    let stp = smoothstep(0.47, 0.5, d) * (1.0 - smoothstep(0.97, 1.0, d));
    albedo = mix(vec3f(0.88, 0.62, 0.04), vec3f(0.02), step(0.5, d));
    if (abs(N.z) < 0.5) { albedo = vec3f(0.85, 0.58, 0.04); }
    rough = 0.55;
  } else if (m == 10u) {
    let h = clamp(wp.y / 240.0, 0.0, 1.0);
    let n = fbm(wp.xz * 0.004 + wp.y * 0.02);
    albedo = mix(vec3f(0.10, 0.17, 0.12), vec3f(0.30, 0.34, 0.40), smoothstep(0.1, 0.7, h + 0.25 * (n - 0.5)));
    rough = 1.0;
  } else if (m == 11u) {
    let n1 = fbm(wp.xz * 0.6);
    albedo = vec3f(0.035) + 0.02 * n1;
    let gl = max(lineMask(abs(fract(wp.x / 2.0 + 0.5) - 0.5) * 2.0, 0.02), lineMask(abs(fract(wp.z / 2.0 + 0.5) - 0.5) * 2.0, 0.02));
    albedo = mix(albedo, vec3f(0.01), gl * 0.7);
    rough = 0.28 + 0.15 * n1;
    metallic = 0.1;
  } else if (m == 12u) {
    let groove = lineMask(abs(fract((wp.x + wp.z) / 1.2 + 0.5) - 0.5) * 1.2, 0.025);
    albedo = vec3f(0.05, 0.055, 0.065) * (1.0 - 0.6 * groove) + 0.01 * fbm(wp.xy * 4.0);
    metallic = 0.3;
    rough = 0.5;
    let acc = lineMask(abs(wp.y - 1.1), 0.035);
    emissive = vec3f(0.1, 0.45, 1.0) * acc * 2.0;
  } else if (m == 13u) {
    emissive = select(vec3f(1.0, 1.0, 1.05) * 6.0, vec3f(0.15, 0.5, 1.0) * 4.0, in.uv.y > 0.5);
    albedo = vec3f(0.9);
  } else if (m == 14u) {
    let r = length(wp.xz);
    albedo = vec3f(0.07, 0.075, 0.085) * (0.85 + 0.15 * sin(r * 24.0));
    metallic = 0.6;
    rough = 0.32;
    let ring = lineMask(abs(r - 3.0), 0.035);
    emissive = vec3f(0.25, 0.6, 1.0) * ring * 3.0;
    if (abs(N.y) < 0.5) { albedo = vec3f(0.03); }
  } else if (m == 18u) {
    let g = fbm(wp.xz * 3.0 + wp.y);
    albedo = mix(vec3f(0.03, 0.10, 0.03), vec3f(0.07, 0.2, 0.06), g);
    rough = 0.95;
  } else if (m == 19u) {
    albedo = vec3f(0.14, 0.09, 0.05);
    rough = 0.95;
  }

  albedo *= obj.tint.rgb;
  var shadow = 1.0;
  if (m != 10u) { shadow = shadowFactor(wp, N); }
  var col = shadePBR(albedo, metallic, rough, N, V, wp, shadow, ao) + emissive;
  if (m == 10u) {
    col = albedo * (ambientLight(N) * 1.2 + frame.sunColor.rgb * max(dot(N, normalize(frame.sunDir.xyz)), 0.0) * 0.3);
  }
  return finishColor(col, wp);
}

// ---------------------------------------------------------------------------------------------
// céu (triângulo de tela cheia)
// ---------------------------------------------------------------------------------------------
struct SkyOut {
  @builtin(position) clip: vec4f,
  @location(0) ndc: vec2f,
};

@vertex
fn vs_sky(@builtin(vertex_index) vi: u32) -> SkyOut {
  var p = array<vec2f, 3>(vec2f(-1.0, -1.0), vec2f(3.0, -1.0), vec2f(-1.0, 3.0));
  var o: SkyOut;
  o.clip = vec4f(p[vi], 1.0, 1.0);
  o.ndc = p[vi];
  return o;
}

@fragment
fn fs_sky(in: SkyOut) -> @location(0) vec4f {
  let w = frame.invViewProj * vec4f(in.ndc, 1.0, 1.0);
  let dir = normalize(w.xyz / w.w - frame.camPos.xyz);
  var col = skyColor(dir);
  let night = frame.params.y;
  if (dir.y > 0.0) {
    let cp = dir.xz / (dir.y + 0.12) * 1.6 + vec2f(frame.params.x * 0.012, 0.0);
    let cl = smoothstep(0.50, 0.78, fbm(cp));
    let lit = max(dot(vec3f(0.0, 1.0, 0.0), normalize(frame.sunDir.xyz)), 0.0) * 0.6 + 0.4;
    let ccol = mix(frame.skyHor.rgb * 1.05, frame.sunColor.rgb * 0.5 + frame.skyHor.rgb * 0.7, 0.5) * lit + vec3f(0.01);
    col = mix(col, ccol, cl * 0.75 * smoothstep(0.0, 0.25, dir.y));
    let st = step(0.9972, hash31(floor(dir * 260.0)));
    col += vec3f(1.0) * st * night * smoothstep(0.02, 0.3, dir.y) * 1.2;
  }
  let t = aces(col);
  return vec4f(pow(t, vec3f(1.0 / 2.2)), 1.0);
}
