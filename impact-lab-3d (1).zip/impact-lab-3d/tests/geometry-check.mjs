// Verifica a geometria procedural dos veículos (contagens, limites, normais para fora) usando as dimensões do módulo C.
import { readFile } from 'node:fs/promises';
import { buildVehicle } from '../src/vehicle.js';
const bytes = await readFile(new URL('../wasm/sim.wasm', import.meta.url));
const env = { sin: Math.sin, cos: Math.cos, tan: Math.tan, atan2: Math.atan2, exp: Math.exp, tanh: Math.tanh, pow: Math.pow };
const { instance } = await WebAssembly.instantiate(bytes, { env });
const x = instance.exports; let fails = 0;
for (let v = 0; v < 3; v++) {
  x.sim_vehicle_dims(v, 1, 0);
  const s = new Float32Array(x.memory.buffer, x.sim_spec_ptr(), 16);
  const d = { zf: s[5], zr: s[6], W: s[7], H: s[8], a: s[9], b: s[10], hcg: s[11], rw: s[12], track: s[13], length: s[15] };
  const g = buildVehicle(v, d);
  let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9], bad = 0;
  for (let i = 0; i < g.vertexCount; i++) for (let k = 0; k < 3; k++) { const p = g.rest[4 * i + k]; if (!Number.isFinite(p)) bad++; mn[k] = Math.min(mn[k], p); mx[k] = Math.max(mx[k], p); }
  // normais: fração apontando para fora do centro (somente patches exteriores de pintura)
  let out = 0, tot = 0;
  for (const r of g.ranges.filter((q) => q.mat === 0)) for (let k = r.first; k < r.first + r.count; k += 3) {
    const i = g.indices[k]; const p = [g.rest[4 * i], g.rest[4 * i + 1] - 0.8, g.rest[4 * i + 2]]; const n = [g.restNrm[4 * i], g.restNrm[4 * i + 1], g.restNrm[4 * i + 2]];
    tot++; if (p[0] * n[0] + p[1] * n[1] + p[2] * n[2] > 0) out++;
  }
  console.log(`veh ${v}: ${g.vertexCount} vértices, ${g.indices.length / 3} triângulos, ${g.ranges.length} ranges | x[${mn[0].toFixed(2)},${mx[0].toFixed(2)}] y[${mn[1].toFixed(2)},${mx[1].toFixed(2)}] z[${mn[2].toFixed(2)},${mx[2].toFixed(2)}] | normais p/ fora ${(100 * out / tot).toFixed(0)}% | NaN ${bad}`);
  if (bad || out / tot < 0.9) fails++;
  if (Math.abs(mx[2] - d.zf) > 0.05 || Math.abs(mn[2] + d.zr) > 0.05 || mx[1] < d.H - 0.12) { fails++; console.log('  dimensões divergem das físicas'); }
}
process.exit(fails ? 1 : 0);
