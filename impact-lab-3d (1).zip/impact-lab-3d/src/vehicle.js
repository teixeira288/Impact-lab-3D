// vehicle.js - geometria 3D procedural dos veículos (carroceria, vidros, faróis, interior, rodas)
//
// Sistema de coordenadas local: +z = frente, +x = lado esquerdo, +y = cima, origem = CG projetado no solo.
// As dimensões (comprimento, largura, entre-eixos, raio da roda...) vêm do módulo físico (C) para que a
// geometria visual seja coerente com a simulação.
//
// A carroceria é construída por "patches" lofted (seções transversais ao longo de z) separados por material,
// de forma que cada região (para-brisa, janela lateral, farol...) tenha geometria própria, creases corretos e
// possa mudar de estado (quebrado) sem alterar a malha.

export const MAT = {
  PAINT: 0, PLASTIC: 1, RUBBER: 2,
  GLASS_WS: 3, GLASS_RR: 4, GLASS_L: 5, GLASS_R: 6,
  HEAD_L: 7, HEAD_R: 8, TAIL_L: 9, TAIL_R: 10,
  INTERIOR: 11, METAL: 12, CLUSTER: 13, SCREEN: 14, UNDER: 15, BEDCOVER: 16, CHROME: 17,
  WHEEL_TIRE: 20, WHEEL_RIM: 21, WHEEL_DISC: 22, WHEEL_BARREL: 23
};
export const isGlass = (m) => m >= MAT.GLASS_WS && m <= MAT.GLASS_R;

export const VEHICLE_INFO = [
  { id: 'hatch', name: 'Hatch compacto', tags: 'Leve | Ágil | Econômico', short: 'HATCH COMPACTO' },
  { id: 'sedan', name: 'Sedan executivo', tags: 'Equilíbrio | Conforto | Estabilidade', short: 'SEDAN EXECUTIVO' },
  { id: 'suv', name: 'SUV / Picape', tags: 'Robusto | Espaçoso | Potente', short: 'SUV / PICAPE' }
];

// Chaves [u, valor]; u = 0 na ponta dianteira, 1 na ponta traseira (fração do comprimento total).
const STYLES = [
  { // hatch
    hb: [[0, 0.72], [0.03, 0.76], [0.10, 0.84], [0.20, 0.92], [0.27, 0.95], [0.45, 0.99], [0.75, 1.00], [0.92, 0.98], [1, 0.88]],
    roof: [[0.25, 0.96], [0.30, 1.15], [0.36, 1.35], [0.42, 1.46], [0.52, 1.50], [0.66, 1.49], [0.78, 1.44], [0.88, 1.30], [0.96, 1.00]],
    yb: [[0, 0.30], [0.04, 0.24], [0.10, 0.17], [0.90, 0.17], [0.96, 0.26], [1, 0.32]],
    cowl: 0.25, roofF: 0.42, roofR: 0.78, cabinEnd: 0.96, win1a: 0.5, win2b: 0.45, bp: true,
    noseR: 0.5, tailR: 0.45, eye: [0.36, 1.20, 0.30], bedCover: false, lightBand: 0.23, mirrorU: 0.31,
    wheelArch: 1.22, paintSill: 0.30
  },
  { // sedan
    hb: [[0, 0.70], [0.03, 0.74], [0.10, 0.83], [0.22, 0.90], [0.30, 0.94], [0.45, 0.97], [0.62, 0.98], [0.76, 1.00], [0.90, 0.99], [1, 0.90]],
    roof: [[0.28, 0.95], [0.33, 1.12], [0.39, 1.30], [0.45, 1.43], [0.52, 1.46], [0.60, 1.44], [0.66, 1.36], [0.72, 1.18], [0.76, 1.00]],
    yb: [[0, 0.30], [0.04, 0.24], [0.10, 0.17], [0.90, 0.17], [0.96, 0.26], [1, 0.32]],
    cowl: 0.28, roofF: 0.45, roofR: 0.60, cabinEnd: 0.76, win1a: 0.4, win2b: 0.45, bp: true,
    noseR: 0.55, tailR: 0.5, eye: [0.36, 1.15, 0.24], bedCover: false, lightBand: 0.21, mirrorU: 0.34,
    wheelArch: 1.2, paintSill: 0.30
  },
  { // SUV / picape
    hb: [[0, 0.92], [0.03, 0.98], [0.10, 1.08], [0.22, 1.15], [0.27, 1.18], [0.54, 1.18], [0.60, 1.09], [0.75, 1.10], [1, 1.06]],
    roof: [[0.26, 1.20], [0.30, 1.38], [0.35, 1.62], [0.40, 1.82], [0.48, 1.85], [0.52, 1.85], [0.545, 1.80], [0.56, 1.35], [0.57, 1.12]],
    yb: [[0, 0.40], [0.05, 0.31], [0.12, 0.25], [0.90, 0.25], [0.96, 0.32], [1, 0.40]],
    cowl: 0.26, roofF: 0.40, roofR: 0.52, cabinEnd: 0.57, win1a: 0.4, win2b: 0.35, bp: false,
    noseR: 0.55, tailR: 0.45, eye: [0.38, 1.50, 0.52], bedCover: true, lightBand: 0.25, mirrorU: 0.30,
    wheelArch: 1.2, paintSill: 0.36
  }
];

// ---------------------------------------------------------------------------------------------
// utilidades matemáticas
// ---------------------------------------------------------------------------------------------
function monoCurve(pts) {
  const n = pts.length, x = pts.map((p) => p[0]), y = pts.map((p) => p[1]);
  const d = new Array(n - 1), m = new Array(n);
  for (let i = 0; i < n - 1; i++) d[i] = (y[i + 1] - y[i]) / (x[i + 1] - x[i]);
  m[0] = d[0]; m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i++) m[i] = d[i - 1] * d[i] <= 0 ? 0 : (d[i - 1] + d[i]) / 2;
  for (let i = 0; i < n - 1; i++) {
    if (d[i] === 0) { m[i] = 0; m[i + 1] = 0; continue; }
    const a = m[i] / d[i], b = m[i + 1] / d[i], s = a * a + b * b;
    if (s > 9) { const t = 3 / Math.sqrt(s); m[i] = t * a * d[i]; m[i + 1] = t * b * d[i]; }
  }
  return (u) => {
    if (u <= x[0]) return y[0];
    if (u >= x[n - 1]) return y[n - 1];
    let i = 0; while (u > x[i + 1]) i++;
    const h = x[i + 1] - x[i], t = (u - x[i]) / h, t2 = t * t, t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * y[i] + (t3 - 2 * t2 + t) * h * m[i] + (-2 * t3 + 3 * t2) * y[i + 1] + (t3 - t2) * h * m[i + 1];
  };
}

// Catmull-Rom: reamostra uma polilinha de pontos de controle em m amostras uniformes no parâmetro
function sampleCR(ctrl, m) {
  const n = ctrl.length;
  if (n === 1) return Array.from({ length: m }, () => ctrl[0].slice());
  const out = [];
  const P = (i) => ctrl[Math.max(0, Math.min(n - 1, i))];
  for (let k = 0; k < m; k++) {
    const t = (k / (m - 1)) * (n - 1);
    let i = Math.floor(t); if (i >= n - 1) i = n - 2;
    const f = t - i, p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    const f2 = f * f, f3 = f2 * f;
    const q = [0, 0];
    for (let c = 0; c < 2; c++) {
      q[c] = 0.5 * ((2 * p1[c]) + (-p0[c] + p2[c]) * f + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * f2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * f3);
    }
    out.push(q);
  }
  return out;
}

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const clamp01 = (v) => Math.max(0, Math.min(1, v));

// ---------------------------------------------------------------------------------------------
// construtor de malha
// ---------------------------------------------------------------------------------------------
class MeshBuilder {
  constructor() {
    this.pos = []; // x,y,z
    this.idx = [];
    this.ranges = []; // {first,count,mat}
  }
  get vertexCount() { return this.pos.length / 3; }

  /** adiciona uma grade rows x cols de vértices e quads; orienta para fora a partir de `center`. */
  addGrid(rows, cols, getPoint, mat, center, opts = {}) {
    const base = this.vertexCount;
    for (let i = 0; i < rows; i++) for (let j = 0; j < cols; j++) { const p = getPoint(i, j); this.pos.push(p[0], p[1], p[2]); }
    const tris = [];
    for (let i = 0; i < rows - 1; i++) for (let j = 0; j < cols - 1; j++) {
      const a = base + i * cols + j, b = a + 1, c = a + cols, d = c + 1;
      tris.push([a, c, b], [b, c, d]);
    }
    // orientação: soma de dot(normal da face, centróide - centro)
    let s = 0;
    for (const [a, b, c] of tris) {
      const pa = this.p(a), pb = this.p(b), pc = this.p(c);
      const n = cross(sub(pb, pa), sub(pc, pa));
      const cen = [(pa[0] + pb[0] + pc[0]) / 3, (pa[1] + pb[1] + pc[1]) / 3, (pa[2] + pb[2] + pc[2]) / 3];
      s += dot(n, sub(cen, center));
    }
    const flip = opts.forceFlip ? true : s < 0;
    const first = this.idx.length;
    for (const [a, b, c] of tris) { if (flip) this.idx.push(a, c, b); else this.idx.push(a, b, c); }
    this.ranges.push({ first, count: this.idx.length - first, mat, name: opts.name || '' });
  }
  p(i) { return [this.pos[3 * i], this.pos[3 * i + 1], this.pos[3 * i + 2]]; }
}

// ---------------------------------------------------------------------------------------------
// construção da carroceria completa
// ---------------------------------------------------------------------------------------------
/**
 * @param {number} vehIndex 0 hatch, 1 sedan, 2 SUV/picape
 * @param {object} d dimensões vindas do módulo C: {zf, zr, W, H, a, b, hcg, rw, track, length}
 */
export function buildVehicle(vehIndex, d) {
  const st = STYLES[vehIndex];
  const L = d.zf + d.zr, hw = d.W / 2;
  const zOf = (u) => d.zf - u * L;
  const uOf = (z) => (d.zf - z) / L;
  const hbC = monoCurve(st.hb), ybC = monoCurve(st.yb), roofC = monoCurve(st.roof);
  const hb = (z) => hbC(uOf(z)) * (d.H / [1.5, 1.46, 1.85][vehIndex]) * 0 + hbC(uOf(z));
  const yb = (z) => ybC(uOf(z));
  const inCabin = (z) => { const u = uOf(z); return u >= st.cowl - 1e-6 && u <= st.cabinEnd + 1e-6; };
  const hr = (z) => {
    const u = uOf(z);
    const crown = hb(z) + 0.025;
    if (u < st.cowl || u > st.cabinEnd) return crown;
    return Math.max(crown, roofC(u));
  };
  const wsAt = (z) => {
    const u = uOf(z);
    const k = u < 0.08 ? 0.93 + 0.055 * (u / 0.08) : u > 0.93 ? 1 - 0.06 * ((u - 0.93) / 0.07) : 1;
    return hw * k;
  };
  const noseF = (z) => { const t = Math.min(1, (d.zf - z) / st.noseR); return Math.pow(Math.max(0, 1 - Math.pow(1 - t, 3)), 1 / 3); };
  const noseR = (z) => { const t = Math.min(1, (z + d.zr) / st.tailR); return Math.pow(Math.max(0, 1 - Math.pow(1 - t, 3)), 1 / 3); };
  const widthScale = (z) => Math.min(noseF(z), noseR(z));

  // breakpoints longitudinais
  const zCowl = zOf(st.cowl), zRoofF = zOf(st.roofF), zRoofR = zOf(st.roofR), zEnd = zOf(st.cabinEnd);
  const uBp = st.roofF + 0.5 * (st.roofR - st.roofF);
  const zBp = zOf(uBp);
  const w1a = zOf(st.cowl + st.win1a * (st.roofF - st.cowl));
  const w1b = st.bp ? zOf(uBp - 0.012) : zOf(st.cabinEnd - st.win2b * (st.cabinEnd - st.roofR));
  const w2a = st.bp ? zOf(uBp + 0.012) : null;
  const w2b = st.bp ? zOf(st.cabinEnd - st.win2b * (st.cabinEnd - st.roofR)) : null;
  const zLightF0 = d.zf - 0.48, zLightF1 = d.zf - 0.10 * st.noseR;
  const zLightR0 = -d.zr + 0.10 * st.tailR, zLightR1 = -d.zr + 0.45;
  const zGrilleF = zLightF1;
  const bedStart = zEnd; // pickup: caçamba atrás da cabine

  // estações em z (de frente para trás)
  const T = [0, 0.0005, 0.002, 0.005, 0.012, 0.025, 0.05, 0.1, 0.15, 0.22, 0.3, 0.4, 0.55, 0.75, 1.0];
  const zs = new Set();
  for (const t of T) { zs.add(+(d.zf - st.noseR * t).toFixed(5)); zs.add(+(-d.zr + st.tailR * t).toFixed(5)); }
  const bps = [zCowl, zRoofF, zRoofR, zEnd, zBp, w1a, w1b, w2a, w2b, zLightF0, zLightF1, zLightR0, zLightR1, d.a, -d.b].filter((z) => z != null);
  for (const z of bps) zs.add(+z.toFixed(5));
  const zMidA = d.zf - st.noseR, zMidB = -d.zr + st.tailR;
  for (let z = zMidA; z > zMidB; z -= 0.07) zs.add(+z.toFixed(5));
  let stations = [...zs].sort((a, b) => b - a);
  // remove estações quase duplicadas (< 4 mm), exceto as da ponta
  const dedup = [stations[0]];
  for (let i = 1; i < stations.length; i++) if (dedup[dedup.length - 1] - stations[i] > 0.004) dedup.push(stations[i]);
  stations = dedup;
  const stationsIn = (za, zb) => stations.filter((z) => z <= za + 1e-4 && z >= zb - 1e-4);

  const mb = new MeshBuilder();
  const center = [0, 0.8, 0];

  // pontos de controle de cada segmento do anel para uma estação z e lado s (+1 esquerda)
  const ringPts = {
    lowA: (z, s) => { const w = wsAt(z), y0 = yb(z), y1 = hb(z) - 0.30; return [[s * w * 0.93, y0], [s * w * 0.978, y0 + 0.5 * (y1 - y0)], [s * w * 0.995, y1]]; },
    lowB: (z, s) => { const w = wsAt(z), y1 = hb(z) - 0.30, y2 = hb(z) - 0.07; return [[s * w * 0.995, y1], [s * w * 1.0, 0.5 * (y1 + y2)], [s * w * 1.0, y2]]; },
    lowC: (z, s) => { const w = wsAt(z), y2 = hb(z) - 0.07; return [[s * w, y2], [s * w * 0.995, hb(z) - 0.025]]; },
    shelf: (z, s) => { const w = wsAt(z), wc = w * 0.915; return [[s * w * 0.995, hb(z) - 0.025], [s * (w * 0.95 + wc * 0.05), hb(z) - 0.002], [s * wc, hb(z) + 0.015]]; },
    win: (z, s) => { const w = wsAt(z), wc = w * 0.915, hc = hr(z) - hb(z), wt = wc - 0.14 * w * clamp01(hc / 0.5); return [[s * wc, hb(z) + 0.015], [s * wt, Math.max(hb(z) + 0.02, hr(z) - 0.045)]]; },
    rail: (z, s) => { const w = wsAt(z), wc = w * 0.915, hc = hr(z) - hb(z), wt = wc - 0.14 * w * clamp01(hc / 0.5), wr = wt - 0.05 * w * clamp01(hc / 0.3); return [[s * wt, Math.max(hb(z) + 0.02, hr(z) - 0.045)], [s * wr, hr(z)]]; },
    top: (z) => {
      const w = wsAt(z), wc = w * 0.915, hc = hr(z) - hb(z), wt = wc - 0.14 * w * clamp01(hc / 0.5), wr = wt - 0.05 * w * clamp01(hc / 0.3);
      const crown = inCabin(z) && hc > 0.1 ? 0.012 : 0.02;
      return [[wr, hr(z)], [wr * 0.66, hr(z) + crown * 0.55], [wr * 0.33, hr(z) + crown * 0.9], [0, hr(z) + crown], [-wr * 0.33, hr(z) + crown * 0.9], [-wr * 0.66, hr(z) + crown * 0.55], [-wr, hr(z)]];
    },
    under: (z) => { const w = wsAt(z) * 0.93, y = yb(z); return [[w, y], [w * 0.5, y + 0.005], [0, y + 0.01], [-w * 0.5, y + 0.005], [-w, y]]; }
  };
  const segSamples = { lowA: 6, lowB: 6, lowC: 3, shelf: 4, win: 5, rail: 3, top: 17, under: 9 };

  const addPatch = (seg, za, zb, mat, side, name) => {
    const zl = stationsIn(za, zb);
    if (zl.length < 2) return;
    const ns = segSamples[seg];
    const rings = zl.map((z) => {
      const ctrl = side === 0 ? ringPts[seg](z) : ringPts[seg](z, side);
      const smp = sampleCR(ctrl, ns), ws = widthScale(z);
      return smp.map(([x, y]) => [x * ws, y, z]);
    });
    mb.addGrid(zl.length, ns, (i, j) => rings[i][j], mat, center, { name: `${seg}${side > 0 ? 'L' : side < 0 ? 'R' : ''}:${name || mat}` });
  };

  // percorre as zonas de um segmento: lista [z0, z1, material]
  const zones = (list) => list.forEach(([za, zb, m, s, nm]) => addPatch(nm[0], za, zb, m, s, nm[1]));
  const zfF = d.zf, zrR = -d.zr;
  for (const s of [1, -1]) {
    const headM = s > 0 ? MAT.HEAD_L : MAT.HEAD_R, tailM = s > 0 ? MAT.TAIL_L : MAT.TAIL_R, glM = s > 0 ? MAT.GLASS_L : MAT.GLASS_R;
    zones([
      // faixa inferior (para-choque / soleira)
      [zfF, zGrilleF, MAT.PLASTIC, s, ['lowA', 'intake']],
      [zGrilleF, zrR + 0.05, MAT.PAINT, s, ['lowA', 'body']],
      [zrR + 0.05, zrR, MAT.PLASTIC, s, ['lowA', 'diffuser']],
      // faixa de faróis/lanternas
      [zfF, zGrilleF, MAT.PLASTIC, s, ['lowB', 'grille']],
      [zGrilleF, zLightF0, headM, s, ['lowB', 'headlight']],
      [zLightF0, zLightR1, MAT.PAINT, s, ['lowB', 'body']],
      [zLightR1, zLightR0, tailM, s, ['lowB', 'taillight']],
      [zLightR0, zrR, MAT.PAINT, s, ['lowB', 'plate']],
      // faixa superior da lateral e prateleira
      [zfF, zrR, MAT.PAINT, s, ['lowC', 'body']],
      [zfF, zrR, MAT.PAINT, s, ['shelf', 'body']],
      [zfF, zrR, MAT.PAINT, s, ['rail', 'body']]
    ]);
    // janelas laterais (vidro) e pilares (lataria)
    const winZones = [[zfF, w1a, MAT.PAINT, 'pillarA']];
    winZones.push([w1a, w1b, glM, 'win1']);
    if (st.bp) { winZones.push([w1b, w2a, MAT.PAINT, 'pillarB']); winZones.push([w2a, w2b, glM, 'win2']); winZones.push([w2b, zrR, MAT.PAINT, 'pillarC']); }
    else winZones.push([w1b, zrR, MAT.PAINT, 'pillarC']);
    for (const [za, zb, m, nm] of winZones) addPatch('win', za, zb, m, s, nm);
  }
  // topo: capô, para-brisa, teto, vidro traseiro, porta-malas / caçamba
  const bed = st.bedCover ? MAT.BEDCOVER : MAT.PAINT;
  addPatch('top', zfF, zCowl, MAT.PAINT, 0, 'hood');
  addPatch('top', zCowl, zRoofF, MAT.GLASS_WS, 0, 'windshield');
  addPatch('top', zRoofF, zRoofR, MAT.PAINT, 0, 'roof');
  addPatch('top', zRoofR, zEnd, st.bedCover ? MAT.GLASS_RR : MAT.GLASS_RR, 0, 'rearglass');
  addPatch('top', zEnd, zrR, bed, 0, 'deck');
  // fundo
  addPatch('under', zfF, zrR, MAT.UNDER, 0, 'under');

  // ----- retrovisores (pequenas peças pintadas, deformáveis pela mesma regra) -----
  const mirrorZ = zOf(st.mirrorU), mirrorY = hb(mirrorZ) + 0.10, mirrorX = wsAt(mirrorZ) * 0.97 + 0.09;
  for (const s of [1, -1]) addBox(mb, [s * mirrorX, mirrorY, mirrorZ - 0.03], [0.17, 0.10, 0.11], MAT.PAINT, 2, 'mirror');

  // ----- placas e detalhes -----
  addBox(mb, [0, yb(zfF) + 0.17, zfF - 0.015], [0.46, 0.12, 0.02], MAT.METAL, 1, 'plateF');
  addBox(mb, [0, hb(zrR) - 0.22, zrR + 0.012], [0.46, 0.12, 0.02], MAT.METAL, 1, 'plateR');

  // ----- interior -----
  const zc = zCowl;
  const dashTop = hb(zc) - 0.02;
  const eye = st.eye.slice();
  // painel: perfil lateral (z,y) extrudado na largura
  const dashZ0 = zc + 0.18, dashZ1 = eye[2] + 0.62;
  const dashProfile = [[dashZ0, 0.45], [dashZ0, dashTop + 0.02], [zc - 0.05, dashTop + 0.05], [zc - 0.30, dashTop - 0.02], [dashZ1 - 0.10, dashTop - 0.10], [dashZ1, dashTop - 0.22], [dashZ1, 0.45]];
  extrudeProfile(mb, dashProfile, -hw * 0.86, hw * 0.86, MAT.INTERIOR, 'dashboard');
  // console central
  addBox(mb, [0, 0.40, (dashZ1 + (eye[2] - 0.5)) / 2], [0.26, 0.20, dashZ1 - (eye[2] - 0.5)], MAT.INTERIOR, 2, 'console');
  // tela central e painel de instrumentos
  const clusterZ = dashZ1 - 0.02;
  addQuad(mb, [eye[0] - 0.17, dashTop - 0.20, clusterZ - 0.002], [eye[0] + 0.17, dashTop - 0.20, clusterZ - 0.002], [eye[0] + 0.17, dashTop - 0.06, clusterZ - 0.06], [eye[0] - 0.17, dashTop - 0.06, clusterZ - 0.06], MAT.CLUSTER, [0, 1, -1]);
  addQuad(mb, [-0.14, dashTop - 0.20, clusterZ - 0.02], [0.14, dashTop - 0.20, clusterZ - 0.02], [0.14, dashTop - 0.06, clusterZ - 0.07], [-0.14, dashTop - 0.06, clusterZ - 0.07], MAT.SCREEN, [0, 1, -1]);
  // volante (toro)
  const wheelC = [eye[0], dashTop - 0.12, eye[2] + 0.50];
  addTorus(mb, wheelC, 0.185, 0.019, 0.42, MAT.INTERIOR, 'steeringwheel');
  addBox(mb, [wheelC[0], wheelC[1], wheelC[2] + 0.005], [0.13, 0.06, 0.02], MAT.INTERIOR, 1, 'hub');
  // bancos
  const seatY = Math.max(0.55, hb(zc) - 0.42);
  const seatZ = eye[2] - 0.05;
  for (const sx of [eye[0], -eye[0]]) {
    addBox(mb, [sx, seatY, seatZ], [0.50, 0.14, 0.50], MAT.INTERIOR, 3, 'seat');
    addBox(mb, [sx, seatY + 0.32, seatZ - 0.27], [0.50, 0.62, 0.12], MAT.INTERIOR, 3, 'seatback');
    addBox(mb, [sx, seatY + 0.68, seatZ - 0.27], [0.28, 0.20, 0.10], MAT.INTERIOR, 2, 'headrest');
  }
  const rearSeatZ = seatZ - Math.min(1.0, 0.45 * L * 0.35) - 0.35;
  if (st.cabinEnd > 0.7 || vehIndex === 2) {
    addBox(mb, [0, seatY, rearSeatZ], [hw * 1.25, 0.14, 0.50], MAT.INTERIOR, 3, 'rearseat');
    addBox(mb, [0, seatY + 0.30, rearSeatZ - 0.27], [hw * 1.25, 0.58, 0.12], MAT.INTERIOR, 3, 'rearseatback');
  }
  // assoalho
  mb.addGrid(4, 4, (i, j) => [(-0.7 + 1.4 * j / 3) * hw * 0.85 * (j === 0 || j === 3 ? 1 : 1), yb(0) + 0.27, dashZ0 - 0.1 - (dashZ0 - 0.1 - (zOf(st.cabinEnd) + 0.15)) * i / 3], MAT.INTERIOR, [0, 0.1, 0], {});

  // ----- finalização: normais de repouso e adjacência -----
  const nV = mb.vertexCount;
  const posArr = new Float32Array(mb.pos);
  const idxArr = new Uint32Array(mb.idx);
  const matPerVertex = new Float32Array(nV);
  for (const r of mb.ranges) for (let k = r.first; k < r.first + r.count; k++) matPerVertex[idxArr[k]] = r.mat;
  const restN = computeNormals(posArr, idxArr, nV);
  const rest = new Float32Array(nV * 4), restNrm = new Float32Array(nV * 4);
  for (let i = 0; i < nV; i++) {
    rest[4 * i] = posArr[3 * i]; rest[4 * i + 1] = posArr[3 * i + 1]; rest[4 * i + 2] = posArr[3 * i + 2]; rest[4 * i + 3] = matPerVertex[i];
    restNrm[4 * i] = restN[3 * i]; restNrm[4 * i + 1] = restN[3 * i + 1]; restNrm[4 * i + 2] = restN[3 * i + 2];
  }
  const adj = buildAdjacency(idxArr, nV);

  const wheels = buildWheelMesh(d.rw, [0.195, 0.205, 0.265][vehIndex]);
  const wheelPos = [
    [hw * 0 + d.track / 2, d.rw, d.a], [-d.track / 2, d.rw, d.a],
    [d.track / 2, d.rw, -d.b], [-d.track / 2, d.rw, -d.b]
  ];
  return {
    index: vehIndex, dims: d, style: st,
    vertexCount: nV, rest, restNrm, indices: idxArr, ranges: mb.ranges,
    adjOffsets: adj.offsets, adjList: adj.list,
    wheels, wheelPos, archR: d.rw * st.wheelArch,
    eye, beltY: hb(zCowl), doorLines: [w1a, w1b, st.bp ? w2a : 0, st.bp ? w2b : 0],
    zCowl, zRoofF, zBp, sillY: st.paintSill,
    clusterCenter: [eye[0], dashTop - 0.13, clusterZ - 0.03], hoodTopY: hb(0.4),
    wheelWidth: [0.195, 0.205, 0.265][vehIndex],
    info: VEHICLE_INFO[vehIndex]
  };
}

// ---------------------------------------------------------------------------------------------
// primitivas auxiliares
// ---------------------------------------------------------------------------------------------
function addBox(mb, c, s, mat, sub = 2, name = '') {
  const [cx, cy, cz] = c, [sx, sy, sz] = s;
  const faces = [
    [[1, 0, 0], [0, 1, 0], [0, 0, 1], sx, sy, sz], [[-1, 0, 0], [0, 1, 0], [0, 0, 1], sx, sy, sz],
    [[0, 1, 0], [1, 0, 0], [0, 0, 1], sy, sx, sz], [[0, -1, 0], [1, 0, 0], [0, 0, 1], sy, sx, sz],
    [[0, 0, 1], [1, 0, 0], [0, 1, 0], sz, sx, sy], [[0, 0, -1], [1, 0, 0], [0, 1, 0], sz, sx, sy]
  ];
  for (const [n, u, v, sn, su, sv] of faces) {
    const g = sub + 1;
    mb.addGrid(g, g, (i, j) => {
      const a = (i / sub - 0.5) * su, b = (j / sub - 0.5) * sv;
      return [cx + n[0] * sn / 2 + u[0] * a + v[0] * b, cy + n[1] * sn / 2 + u[1] * a + v[1] * b, cz + n[2] * sn / 2 + u[2] * a + v[2] * b];
    }, mat, c, { name });
  }
}
function addQuad(mb, p0, p1, p2, p3, mat, nHint) {
  mb.addGrid(2, 2, (i, j) => (i === 0 ? (j === 0 ? p0 : p1) : (j === 0 ? p3 : p2)), mat, [p0[0] + nHint[0] * -1, p0[1] + nHint[1] * -1, p0[2] + nHint[2] * -1], { name: 'quad' });
}
function extrudeProfile(mb, prof, x0, x1, mat, name) {
  const n = prof.length, cx = 0;
  let cy = 0, cz = 0; for (const p of prof) { cz += p[0] / n; cy += p[1] / n; }
  const nx = 7;
  for (let e = 0; e < n; e++) {
    const a = prof[e], b = prof[(e + 1) % n];
    mb.addGrid(2, nx, (i, j) => [x0 + (x1 - x0) * j / (nx - 1), i === 0 ? a[1] : b[1], i === 0 ? a[0] : b[0]], mat, [cx, cy, cz], { name });
  }
  // tampas laterais
  for (const x of [x0, x1]) {
    mb.addGrid(2, n, (i, j) => [x, prof[j][1], prof[j][0] + (i === 0 ? 0 : 0.0001)], mat, [cx, cy, cz], { name });
  }
}
function addTorus(mb, c, R, r, tilt, mat, name) {
  const nu = 28, nv = 8, ct = Math.cos(tilt), stt = Math.sin(tilt);
  mb.addGrid(nu + 1, nv + 1, (i, j) => {
    const a = (i / nu) * Math.PI * 2, b = (j / nv) * Math.PI * 2;
    const x = (R + r * Math.cos(b)) * Math.cos(a), y0 = (R + r * Math.cos(b)) * Math.sin(a), z0 = r * Math.sin(b);
    // inclinação do plano do volante: rotaciona em torno de x
    return [c[0] + x, c[1] + y0 * ct - z0 * stt, c[2] + y0 * stt + z0 * ct];
  }, mat, c, { name });
}

function computeNormals(pos, idx, n) {
  const nrm = new Float32Array(n * 3);
  for (let t = 0; t < idx.length; t += 3) {
    const a = idx[t], b = idx[t + 1], c = idx[t + 2];
    const ux = pos[3 * b] - pos[3 * a], uy = pos[3 * b + 1] - pos[3 * a + 1], uz = pos[3 * b + 2] - pos[3 * a + 2];
    const vx = pos[3 * c] - pos[3 * a], vy = pos[3 * c + 1] - pos[3 * a + 1], vz = pos[3 * c + 2] - pos[3 * a + 2];
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    for (const v of [a, b, c]) { nrm[3 * v] += nx; nrm[3 * v + 1] += ny; nrm[3 * v + 2] += nz; }
  }
  for (let i = 0; i < n; i++) {
    const l = Math.hypot(nrm[3 * i], nrm[3 * i + 1], nrm[3 * i + 2]);
    if (l < 1e-12) { nrm[3 * i + 2] = 1; continue; }
    nrm[3 * i] /= l; nrm[3 * i + 1] /= l; nrm[3 * i + 2] /= l;
  }
  return nrm;
}

function buildAdjacency(idx, n) {
  const counts = new Uint32Array(n + 1);
  for (let k = 0; k < idx.length; k++) counts[idx[k] + 1]++;
  for (let i = 0; i < n; i++) counts[i + 1] += counts[i];
  const offsets = counts, list = new Uint32Array(idx.length), fill = new Uint32Array(n);
  for (let t = 0; t < idx.length / 3; t++) for (let k = 0; k < 3; k++) { const v = idx[3 * t + k]; list[offsets[v] + fill[v]++] = t; }
  return { offsets, list };
}

// ---------------------------------------------------------------------------------------------
// roda: pneu (revolução), aro (disco com raios procedurais no shader), disco de freio e barril
// Eixo da roda ao longo de +x (face externa em +x). Código de material em pos.w.
// ---------------------------------------------------------------------------------------------
function buildWheelMesh(R, width) {
  const pos = [], nrm = [], idx = [];
  const seg = 48;
  const hwid = width / 2, rimR = R * 0.62;
  const push = (p, n, code) => { pos.push(p[0], p[1], p[2], code); nrm.push(n[0], n[1], n[2], rimR); return pos.length / 4 - 1; };
  // perfil do pneu (x = largura ao longo do eixo, r = raio) - girado em torno de x
  const prof = [
    [hwid * 0.92, rimR * 1.0], [hwid * 1.0, rimR * 1.12], [hwid * 1.0, R * 0.84], [hwid * 0.92, R * 0.95], [hwid * 0.62, R * 0.995],
    [0.0, R], [-hwid * 0.62, R * 0.995], [-hwid * 0.92, R * 0.95], [-hwid * 1.0, R * 0.84], [-hwid * 1.0, rimR * 1.12], [-hwid * 0.92, rimR * 1.0]
  ];
  const pn = prof.length;
  const profN = prof.map((p, i) => { const a = prof[Math.max(0, i - 1)], b = prof[Math.min(pn - 1, i + 1)]; const tx = b[0] - a[0], tr = b[1] - a[1]; const l = Math.hypot(tx, tr); return [tr / l, -tx / l]; });
  const base = pos.length / 4;
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    for (let j = 0; j < pn; j++) {
      const [x, r] = prof[j], [nx, nr] = profN[j];
      push([x, r * ca, r * sa], [nx, nr * ca, nr * sa], MAT.WHEEL_TIRE);
    }
  }
  for (let i = 0; i < seg; i++) for (let j = 0; j < pn - 1; j++) {
    const a = base + i * pn + j, b = a + pn, c = a + 1, d = b + 1;
    idx.push(a, c, b, c, d, b);
  }
  // face do aro (disco) e interior escuro (disco de freio + barril)
  const rimBase = pos.length / 4;
  const xr = hwid * 0.80;
  const cI = push([xr, 0, 0], [1, 0, 0], MAT.WHEEL_RIM);
  for (let i = 0; i <= seg; i++) { const a = (i / seg) * Math.PI * 2; push([xr * 0.9, rimR * 1.02 * Math.cos(a), rimR * 1.02 * Math.sin(a)], [1, 0, 0], MAT.WHEEL_RIM); }
  for (let i = 0; i < seg; i++) idx.push(cI, rimBase + 2 + i, rimBase + 1 + i);
  // barril do aro (cilindro interno)
  const bb = pos.length / 4;
  for (let i = 0; i <= seg; i++) { const a = (i / seg) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a); push([xr * 0.9, rimR * 1.02 * ca, rimR * 1.02 * sa], [0, -ca, -sa], MAT.WHEEL_BARREL); push([-xr * 0.9, rimR * 1.02 * ca, rimR * 1.02 * sa], [0, -ca, -sa], MAT.WHEEL_BARREL); }
  for (let i = 0; i < seg; i++) { const a = bb + 2 * i; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  // disco de freio (visível entre os raios) e cubo
  const dbase = pos.length / 4;
  const xd = hwid * 0.30;
  const cD = push([xd, 0, 0], [1, 0, 0], MAT.WHEEL_DISC);
  for (let i = 0; i <= seg; i++) { const a = (i / seg) * Math.PI * 2; push([xd, rimR * 0.9 * Math.cos(a), rimR * 0.9 * Math.sin(a)], [1, 0, 0], MAT.WHEEL_DISC); }
  for (let i = 0; i < seg; i++) idx.push(cD, dbase + 2 + i, dbase + 1 + i);
  // face interna (lado do carro)
  const ibase = pos.length / 4;
  const cX = push([-xr, 0, 0], [-1, 0, 0], MAT.WHEEL_BARREL);
  for (let i = 0; i <= seg; i++) { const a = (i / seg) * Math.PI * 2; push([-xr * 0.9, rimR * 1.02 * Math.cos(a), rimR * 1.02 * Math.sin(a)], [-1, 0, 0], MAT.WHEEL_BARREL); }
  for (let i = 0; i < seg; i++) idx.push(cX, ibase + 1 + i, ibase + 2 + i);
  return { pos: new Float32Array(pos), nrm: new Float32Array(nrm), indices: new Uint32Array(idx), count: idx.length, radius: R, width };
}
