// damage-map.js - esquema do veículo em vista superior com as 8 zonas de dano calculadas pela simulação.
// Cores: verde (0-25%), amarelo (25-50%), laranja (50-75%), vermelho (>75%). Clique em uma zona para ver detalhes.

import { ZONES } from './physics-bridge.js';

export const ZONE_LABELS = {
  front: 'Dianteira (para-choque)', hood: 'Capô', left: 'Lateral esquerda', right: 'Lateral direita',
  roof: 'Teto / cabine', rear: 'Traseira (porta-malas)', wheels: 'Rodas / suspensão', struct: 'Estrutura (monobloco)'
};

export function damageColor(d) {
  if (d < 0.25) return '#3ecf6e';
  if (d < 0.5) return '#f2d54a';
  if (d < 0.75) return '#ff9b2f';
  return '#ee3b3b';
}
export function damageLabel(d) {
  if (d < 0.05) return 'Sem dano';
  if (d < 0.25) return 'Leve';
  if (d < 0.5) return 'Moderado';
  if (d < 0.75) return 'Severo';
  return 'Crítico';
}

const NS = 'http://www.w3.org/2000/svg';
const el = (n, a = {}, parent) => { const e = document.createElementNS(NS, n); for (const k in a) e.setAttribute(k, a[k]); if (parent) parent.appendChild(e); return e; };

export class DamageMap {
  /** @param {HTMLElement} root contêiner; @param {(zone:string)=>void} onSelect */
  constructor(root, onSelect) {
    this.root = root;
    this.onSelect = onSelect || (() => {});
    this.shapes = {};
    this.labels = {};
    this.selected = null;
    const svg = el('svg', { viewBox: '0 0 220 400', class: 'dmg-svg', role: 'img', 'aria-label': 'Mapa de danos do veículo, vista superior' });
    // contorno de fundo
    el('path', { d: 'M110 14 C150 14 176 34 178 74 L182 150 L182 250 L180 330 C178 368 150 388 110 388 C70 388 42 368 40 330 L38 250 L38 150 L42 74 C44 34 70 14 110 14Z', class: 'dmg-outline' }, svg);
    const mk = (id, d, tx, ty) => {
      const g = el('g', { class: 'dmg-zone', 'data-zone': id, tabindex: 0, role: 'button', 'aria-label': ZONE_LABELS[id] }, svg);
      const p = el('path', { d, fill: '#3ecf6e', class: 'dmg-shape' }, g);
      const t = el('text', { x: tx, y: ty, class: 'dmg-pct', 'text-anchor': 'middle', 'dominant-baseline': 'middle' }, g);
      t.textContent = '0%';
      g.addEventListener('click', () => this.select(id));
      g.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.select(id); } });
      this.shapes[id] = p; this.labels[id] = t;
    };
    mk('front', 'M110 14 C150 14 176 34 178 74 L178 86 L42 86 L42 74 C44 34 70 14 110 14Z', 110, 54);
    mk('hood', 'M46 92 L174 92 L172 160 L48 160Z', 110, 126);
    mk('roof', 'M52 166 L168 166 L168 250 L52 250Z', 110, 208);
    mk('rear', 'M44 300 L176 300 L178 330 C176 368 150 388 110 388 C70 388 44 368 42 330Z', 110, 340);
    mk('left', 'M24 92 L40 92 L40 296 L24 296 Q16 194 24 92Z', 22, 194);
    mk('right', 'M196 92 L180 92 L180 296 L196 296 Q204 194 196 92Z', 198, 194);
    mk('struct', 'M52 256 L168 256 L168 294 L52 294Z', 110, 275);
    // rodas (um grupo sobre as quatro rodas)
    const wg = el('g', { class: 'dmg-zone', 'data-zone': 'wheels', tabindex: 0, role: 'button', 'aria-label': ZONE_LABELS.wheels }, svg);
    this.wheelRects = [[14, 100], [190, 100], [14, 252], [190, 252]].map(([x, y]) => el('rect', { x: x - 2, y, width: 18, height: 40, rx: 5, fill: '#3ecf6e', class: 'dmg-shape' }, wg));
    const wt = el('text', { x: 110, y: 232, class: 'dmg-pct small', 'text-anchor': 'middle', 'dominant-baseline': 'middle' }, wg);
    wt.textContent = '';
    this.wheelLabel = wt;
    wg.addEventListener('click', () => this.select('wheels'));
    wg.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.select('wheels'); } });
    // setas de orientação
    const fr = el('text', { x: 110, y: 8, class: 'dmg-dir', 'text-anchor': 'middle' }, svg); fr.textContent = 'FRENTE';
    const bk = el('text', { x: 110, y: 398, class: 'dmg-dir', 'text-anchor': 'middle' }, svg); bk.textContent = 'TRÁS';
    root.innerHTML = '';
    root.appendChild(svg);
    this.svg = svg;
    this.values = ZONES.map(() => ({ d: 0, disp: 0 }));
  }

  select(id) { this.selected = id; for (const g of this.svg.querySelectorAll('.dmg-zone')) g.classList.toggle('sel', g.dataset.zone === id); this.onSelect(id); }

  /** @param {Float32Array} out vetor de saída da simulação (O.ZONE0 = 40) */
  update(out) {
    for (let i = 0; i < ZONES.length; i++) {
      const z = ZONES[i], d = Math.min(1, Math.max(0, out[40 + 2 * i])), disp = out[41 + 2 * i];
      this.values[i].d = d; this.values[i].disp = disp;
      const c = damageColor(d);
      if (z === 'wheels') { for (const r of this.wheelRects) r.setAttribute('fill', c); this.wheelLabel.textContent = ''; } // % das rodas: painel de detalhes (evita sobrepor o rótulo do teto)
      else { this.shapes[z].setAttribute('fill', c); this.labels[z].textContent = Math.round(d * 100) + '%'; }
    }
  }
  value(zone) { return this.values[ZONES.indexOf(zone)]; }
}
