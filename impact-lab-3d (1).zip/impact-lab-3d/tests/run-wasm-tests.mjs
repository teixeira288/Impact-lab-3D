// Testes do módulo WebAssembly compilado (Node >= 18):  node tests/run-wasm-tests.mjs
// Confirma que wasm/sim.wasm carrega, expõe a API esperada e reproduz os resultados do build nativo.
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const bytes = await readFile(path.join(here, '..', 'wasm', 'sim.wasm'));
const env = { sin: Math.sin, cos: Math.cos, tan: Math.tan, atan2: Math.atan2, exp: Math.exp, tanh: Math.tanh, pow: Math.pow };
const { instance } = await WebAssembly.instantiate(bytes, { env });
const x = instance.exports;
let fails = 0, checks = 0;
const check = (c, m) => { checks++; if (!c) { fails++; console.log('  FALHOU:', m); } };

check(x.sim_version() === 3, 'versão');
const N = x.sim_out_count();
check(N === 128, 'contagem de saída ' + N);
const mem = x.memory.buffer;
const out = new Float32Array(mem, x.sim_out(), N);
const crush = new Float32Array(mem, x.sim_crush(), 36);
const O = { T: 0, Z: 2, VBEFORE: 22, KE0: 25, PEAKG: 28, DIST: 16, MASS: 31, IMPACTED: 21, PHASE: 20, DAMAGE: 56, ZONE0: 40, IMPULSE: 26 };

for (const target of [30, 50, 80, 100, 120, 150]) {
  x.sim_configure(1, 1, 0, 0, target, 0, 0, 0, 0);
  check(Math.abs(out[O.DIST] - 200) < 1e-3, 'distância inicial 200 m');
  x.sim_start();
  for (let i = 0; i < 480 * 40 && out[O.PHASE] !== 3; i++) x.sim_step(1 / 480);
  const real = out[O.VBEFORE] * 3.6;
  const cmax = Math.max(...crush.slice(0, 9));
  console.log(`  alvo ${String(target).padStart(3)} km/h -> real ${real.toFixed(2)} km/h | esmag. ${cmax.toFixed(3)} m | pico ${out[O.PEAKG].toFixed(0)} g | dano ${out[O.DAMAGE].toFixed(2)}`);
  check(Math.abs(real - target) / target < 0.02, 'velocidade real ~ alvo ' + target);
  const E = 0.5 * out[O.MASS] * (out[O.VBEFORE]) ** 2;
  check(Math.abs(E - out[O.KE0]) / E < 1e-4, 'E = 1/2 m v^2');
  check(cmax > 0.05, 'houve deformação');
}
// pausa lógica: sem chamar sim_step o tempo não muda
x.sim_configure(0, 0, 0, 0, 80, 0, 0, 0, 0); x.sim_start();
for (let i = 0; i < 480; i++) x.sim_step(1 / 480);
const t1 = out[O.T]; const z1 = out[O.Z];
check(t1 > 0.99 && t1 < 1.01, 't = 1 s');
check(out[O.T] === t1 && out[O.Z] === z1, 'estado estável sem passos');
x.sim_reset();
check(out[O.T] === 0 && Math.abs(out[O.DIST] - 200) < 1e-3, 'reset');
console.log(`\n${checks} verificações, ${fails} falhas`);
process.exit(fails ? 1 : 0);
