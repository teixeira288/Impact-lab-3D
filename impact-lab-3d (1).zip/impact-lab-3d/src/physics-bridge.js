// physics-bridge.js - carrega o módulo físico (C -> WebAssembly) e expõe uma API tipada ao JavaScript.
//
// Memória compartilhada: o módulo usa memória linear estática (sem malloc, sem crescimento). O JS lê os resultados por
// Float32Array sobre essa memória (ponteiros obtidos uma única vez). Os tipos numéricos cruzam a fronteira como
// int32 (índices/modos) e float32 (grandezas físicas). Os índices abaixo espelham physics/sim.h e são validados
// em tempo de carga (versão e tamanho do vetor de saída) para evitar dessincronização entre C e JS.

export const SIM_VERSION = 3;
export const OUT_COUNT = 128;
export const NSAMP = 36;

export const O = {
  T: 0, X: 1, Z: 2, Y: 3, YAW: 4, PITCH: 5, ROLL: 6, SPEED: 7, U: 8, V: 9, VX: 10, VZ: 11, OMEGA: 12, ALONG: 13, ALAT: 14,
  GNOW: 15, DIST: 16, THR: 17, BRK: 18, STEER: 19, PHASE: 20, IMPACTED: 21, VBEFORE: 22, VNORM: 23, TIMPACT: 24, KE0: 25,
  IMPULSE: 26, PEAKA: 27, PEAKG: 28, ECRUSH: 29, EFRIC: 30, MASS: 31, TARGET: 32, LAUNCH: 33, SPIN: 34, KENOW: 35,
  ZONE0: 40, DAMAGE: 56, STATE: 57, BROKEN: 58, IMPX: 60, IMPY: 61, IMPZ: 62, IMPLX: 63, IMPLZ: 64, EVENTS: 65, EVSTR: 66,
  NCONTACT: 67, FTOTAL: 68, BRAKELIGHT: 69, OBSTRAVEL: 70, ANGLEDEG: 71, VAFTER: 72, SLED: 73, MODE: 74, FACE: 75, OBSTACLE: 76,
  REFX: 77, REFZ: 78, STEPS: 79, YAWDEG_IMP: 80, CONTACT_T: 81, PEAKF: 82, NSUB: 83, JVX: 84, JVZ: 85
};
export const PHASE = { IDLE: 0, RUNNING: 1, IMPACT: 2, SETTLED: 3 };
export const ZONES = ['front', 'hood', 'left', 'right', 'roof', 'rear', 'wheels', 'struct'];
export const BRK = { HEAD_L: 1, HEAD_R: 2, WSHIELD: 4, RGLASS: 8, TAIL_L: 16, TAIL_R: 32, WIN_L: 64, WIN_R: 128, HOOD: 256, BUMPER_F: 512, BUMPER_R: 1024 };
export const FACE = { FRONT: 0, REAR: 1, LEFT: 2, RIGHT: 3 };
export const OBSTACLE = { WALL: 0, BARRIER: 1, POLE: 2, BLOCK: 3 };
const S = { MASS: 0, POWER: 1, TORQUE: 2, T0100: 3, VMAX: 4, ZF: 5, ZR: 6, WIDTH: 7, HEIGHT: 8, A: 9, B: 10, HCG: 11, RW: 12, TRACK: 13, BRAKEG: 14, LENGTH: 15 };

export class PhysicsError extends Error {
  constructor(code, message, cause) { super(message); this.code = code; this.cause = cause; }
}

export class Physics {
  static async load(url = new URL('../wasm/sim.wasm', import.meta.url)) {
    let bytes;
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      bytes = await res.arrayBuffer();
    } catch (e) {
      throw new PhysicsError('wasm-fetch', 'Não foi possível baixar wasm/sim.wasm. Execute o projeto por um servidor HTTP local (veja o README) e compile o módulo com "make" em physics/.', e);
    }
    if (!WebAssembly || !WebAssembly.instantiate) throw new PhysicsError('no-wasm', 'Este navegador não suporta WebAssembly.');
    // funções matemáticas importadas pelo módulo (o build sem libc usa as do motor JS)
    const env = { sin: Math.sin, cos: Math.cos, tan: Math.tan, atan2: Math.atan2, exp: Math.exp, tanh: Math.tanh, pow: Math.pow };
    let inst;
    try { inst = (await WebAssembly.instantiate(bytes, { env })).instance; } catch (e) {
      throw new PhysicsError('wasm-instantiate', 'Falha ao instanciar o módulo WebAssembly: ' + e.message, e);
    }
    const p = new Physics(inst.exports);
    p.validate();
    return p;
  }

  constructor(x) {
    this.x = x;
    this._buf = null;
    this._bind();
  }

  _bind() {
    const x = this.x;
    this._buf = x.memory.buffer;
    this.out = new Float32Array(this._buf, x.sim_out(), OUT_COUNT);
    this.crush = new Float32Array(this._buf, x.sim_crush(), NSAMP);
    this.dirs = new Float32Array(this._buf, x.sim_crush_dir(), NSAMP * 2);
    this.samples = new Float32Array(this._buf, x.sim_samples(), NSAMP * 8);
    this.specs = new Float32Array(this._buf, x.sim_spec_ptr(), 16);
  }
  /** garante views válidas (caso a memória do WASM cresça e o buffer seja substituído) */
  sync() { if (this._buf !== this.x.memory.buffer) this._bind(); }

  validate() {
    const x = this.x;
    for (const n of ['sim_version', 'sim_out_count', 'sim_out', 'sim_crush', 'sim_crush_dir', 'sim_samples', 'sim_spec_ptr', 'sim_vehicle_dims', 'sim_configure', 'sim_reset', 'sim_start', 'sim_set_input', 'sim_set_gear', 'sim_step']) {
      if (typeof x[n] !== 'function') throw new PhysicsError('wasm-api', `O módulo WebAssembly não exporta ${n}. Recompile com "make" em physics/.`);
    }
    if (x.sim_version() !== SIM_VERSION) throw new PhysicsError('wasm-version', `Versão do módulo físico (${x.sim_version()}) diferente da esperada pelo JavaScript (${SIM_VERSION}). Recompile o módulo.`);
    if (x.sim_out_count() !== OUT_COUNT) throw new PhysicsError('wasm-layout', 'Layout do vetor de saída divergente entre C e JavaScript.');
  }

  /** dimensões e especificações simuladas de um veículo/motorização */
  vehicleSpec(veh, motor, extra = 0) {
    this.sync();
    this.x.sim_vehicle_dims(veh, motor, extra);
    const s = this.specs;
    return {
      mass: s[S.MASS], power: s[S.POWER], torque: s[S.TORQUE], t0100: s[S.T0100], vmax: s[S.VMAX], brakeG: s[S.BRAKEG],
      zf: s[S.ZF], zr: s[S.ZR], W: s[S.WIDTH], H: s[S.HEIGHT], a: s[S.A], b: s[S.B], hcg: s[S.HCG], rw: s[S.RW], track: s[S.TRACK], length: s[S.LENGTH]
    };
  }

  configure(c) {
    this.sync();
    this.x.sim_configure(c.vehicle | 0, c.motor | 0, c.extraMass || 0, c.obstacle | 0, c.targetKmh, c.face | 0, c.angleDeg || 0, c.offsetM || 0, c.manual ? 1 : 0);
    this.cfg = { ...c };
  }
  reset() { this.x.sim_reset(); }
  start() { this.x.sim_start(); }
  setInput(thr, brk, steer) { this.x.sim_set_input(thr, brk, steer); }
  setGear(g) { this.x.sim_set_gear(g); }
  /** um passo fixo de física (o chamador garante dt constante) */
  step(dt) { this.x.sim_step(dt); }
}
