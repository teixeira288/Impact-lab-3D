// lighting.wgsl - código comum: uniform de quadro, ruído, ambiente analítico (reflexos), sombras, PBR e tone mapping.
// É concatenado antes de vehicle.wgsl, scene.wgsl e particles.wgsl.

struct Frame {
  viewProj: mat4x4f,
  lightVP: mat4x4f,
  invViewProj: mat4x4f,
  camPos: vec4f,
  sunDir: vec4f,      // xyz: direção PARA o sol; w: intensidade
  sunColor: vec4f,
  skyTop: vec4f,
  skyHor: vec4f,
  ground: vec4f,
  params: vec4f,      // x: tempo, y: noite (0..1), z: garagem (0/1), w: densidade de névoa
  misc: vec4f,        // x: texel da sombra, y: velocidade (m/s), z: luz de freio, w: flash de impacto
  camRight: vec4f,
  camUp: vec4f,
  headPos: vec4f,     // xyz: ponto médio dos faróis (mundo); w: ligados (0/1)
  headDir: vec4f,     // xyz: direção do feixe
  headSide: vec4f,    // xyz: eixo lateral do veículo
};

@group(0) @binding(0) var<uniform> frame: Frame;
@group(0) @binding(1) var shadowTex: texture_depth_2d;
@group(0) @binding(2) var shadowSamp: sampler_comparison;
@group(0) @binding(3) var atlasTex: texture_2d<f32>;
@group(0) @binding(4) var atlasSamp: sampler;

const PI: f32 = 3.14159265359;

fn hash21(p: vec2f) -> f32 {
  var q = fract(p * vec2f(123.34, 456.21));
  q += dot(q, q + 45.32);
  return fract(q.x * q.y);
}
fn hash31(p: vec3f) -> f32 {
  var q = fract(p * vec3f(0.1031, 0.1030, 0.0973));
  q += dot(q, q.yxz + 33.33);
  return fract((q.x + q.y) * q.z);
}
fn hash22(p: vec2f) -> vec2f {
  let n = vec2f(hash21(p), hash21(p + 17.17));
  return n;
}
fn vnoise(p: vec2f) -> f32 {
  let i = floor(p);
  let f = fract(p);
  let u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash21(i), hash21(i + vec2f(1, 0)), u.x), mix(hash21(i + vec2f(0, 1)), hash21(i + vec2f(1, 1)), u.x), u.y);
}
fn fbm(p: vec2f) -> f32 {
  var a = 0.5;
  var s = 0.0;
  var q = p;
  for (var i = 0; i < 5; i++) {
    s += a * vnoise(q);
    q = q * 2.03 + vec2f(17.3, 9.1);
    a *= 0.5;
  }
  return s;
}
// distância à fronteira da célula de Voronoi (F2 - F1): usada para trincas de vidro
fn voronoiEdge(p: vec2f) -> f32 {
  let ip = floor(p);
  let fp = fract(p);
  var f1 = 8.0;
  var f2 = 8.0;
  for (var j = -1; j <= 1; j++) {
    for (var i = -1; i <= 1; i++) {
      let g = vec2f(f32(i), f32(j));
      let o = hash22(ip + g);
      let d = length(g + o - fp);
      if (d < f1) { f2 = f1; f1 = d; } else if (d < f2) { f2 = d; }
    }
  }
  return f2 - f1;
}

// Ambiente analítico: usado como "mapa de reflexo" aproximado e para a luz ambiente.
fn skyColor(r: vec3f) -> vec3f {
  let t = clamp(r.y, 0.0, 1.0);
  var c = mix(frame.skyHor.rgb, frame.skyTop.rgb, pow(t, 0.55));
  let sd = max(dot(r, normalize(frame.sunDir.xyz)), 0.0);
  c += frame.sunColor.rgb * (pow(sd, 700.0) * 4.0 + pow(sd, 12.0) * 0.12 * frame.sunDir.w);
  if (r.y < 0.0) {
    c = mix(frame.skyHor.rgb * 0.9, frame.ground.rgb, clamp(-r.y * 3.0, 0.0, 1.0));
  }
  return c;
}

fn studioEnv(r: vec3f) -> vec3f {
  var base = mix(vec3f(0.012, 0.014, 0.018), vec3f(0.05, 0.06, 0.075), clamp(r.y * 0.5 + 0.5, 0.0, 1.0));
  // softboxes no teto (duas barras longas) e painéis laterais
  if (r.y > 0.25) {
    let p = r.xz / r.y;
    let bar = smoothstep(0.16, 0.10, abs(abs(p.x) - 1.05)) * smoothstep(5.0, 3.5, abs(p.y));
    base += vec3f(1.0, 1.0, 1.05) * bar * 5.0;
    let ring = smoothstep(0.05, 0.0, abs(length(p) - 2.6)) * 0.7;
    base += vec3f(0.35, 0.6, 1.0) * ring;
  }
  let side = smoothstep(0.55, 0.42, abs(r.y - 0.18)) * smoothstep(0.35, 0.2, abs(abs(r.x) - 0.9) * 1.2);
  base += vec3f(0.5, 0.7, 1.0) * side * 0.5;
  return base;
}

fn envColor(r: vec3f) -> vec3f {
  if (frame.params.z > 0.5) { return studioEnv(r); }
  return skyColor(r);
}

fn ambientLight(n: vec3f) -> vec3f {
  if (frame.params.z > 0.5) {
    return mix(vec3f(0.018, 0.02, 0.026), vec3f(0.07, 0.08, 0.10), n.y * 0.5 + 0.5);
  }
  return mix(frame.ground.rgb, frame.skyTop.rgb * 0.9 + frame.skyHor.rgb * 0.3, n.y * 0.5 + 0.5);
}

fn shadowFactor(wp: vec3f, n: vec3f) -> f32 {
  let ls = frame.lightVP * vec4f(wp + n * 0.06, 1.0);
  let ndc = ls.xyz / ls.w;
  let uv = vec2f(ndc.x * 0.5 + 0.5, 1.0 - (ndc.y * 0.5 + 0.5));
  var inside = 1.0;
  if (uv.x < 0.01 || uv.x > 0.99 || uv.y < 0.01 || uv.y > 0.99 || ndc.z > 1.0 || ndc.z < 0.0) { inside = 0.0; }
  let texel = frame.misc.x;
  var s = 0.0;
  for (var i = -1; i <= 1; i++) {
    for (var j = -1; j <= 1; j++) {
      s += textureSampleCompareLevel(shadowTex, shadowSamp, uv + vec2f(f32(i), f32(j)) * texel, ndc.z - 0.0012);
    }
  }
  s = s / 9.0;
  return mix(1.0, s, inside);
}

// luzes de poste (noite): 4 postos mais próximos de cada lado
fn poleLight(wp: vec3f, n: vec3f) -> vec3f {
  let night = frame.params.y;
  if (night < 0.01 || frame.params.z > 0.5) { return vec3f(0.0); }
  var acc = vec3f(0.0);
  let base = round(wp.z / 36.0);
  for (var k = -2; k <= 2; k++) {
    for (var s = 0; s < 2; s++) {
      let lp = vec3f(select(-10.0, 10.0, s == 1), 8.8, (base + f32(k)) * 36.0);
      let d = lp - wp;
      let dist2 = dot(d, d);
      let l = d * inverseSqrt(dist2);
      let att = 1.0 / (1.0 + dist2 * 0.02);
      acc += vec3f(1.0, 0.78, 0.5) * max(dot(n, l), 0.0) * att * 9.0;
    }
  }
  return acc * night;
}

// faróis do veículo (feixe em cone) iluminando cenário e obstáculo
fn headBeam(wp: vec3f, n: vec3f) -> vec3f {
  if (frame.headPos.w < 0.5) { return vec3f(0.0); }
  var acc = vec3f(0.0);
  for (var s = 0; s < 2; s++) {
    let off = select(-0.6, 0.6, s == 1);
    let lp = frame.headPos.xyz + frame.headSide.xyz * off;
    let d = wp - lp;
    let dist = length(d);
    let l = d / max(dist, 0.001);
    let cosA = dot(l, normalize(frame.headDir.xyz));
    let cone = smoothstep(0.88, 0.97, cosA);
    let att = 1.0 / (1.0 + dist * dist * 0.004);
    acc += vec3f(1.0, 0.95, 0.85) * cone * att * max(dot(n, -l), 0.0) * 60.0;
  }
  return acc * (0.25 + 0.75 * frame.params.y);
}

fn shadePBR(albedo: vec3f, metallic: f32, rough: f32, N: vec3f, V: vec3f, P: vec3f, shadow: f32, ao: f32) -> vec3f {
  let L = normalize(frame.sunDir.xyz);
  let H = normalize(L + V);
  let NdL = max(dot(N, L), 0.0);
  let NdV = max(dot(N, V), 1e-3);
  let NdH = max(dot(N, H), 0.0);
  let VdH = max(dot(V, H), 0.0);
  let r = clamp(rough, 0.04, 1.0);
  let a = r * r;
  let a2 = a * a;
  let dd = NdH * NdH * (a2 - 1.0) + 1.0;
  let D = a2 / (PI * dd * dd);
  let k = (r + 1.0) * (r + 1.0) / 8.0;
  let G = (NdV / (NdV * (1.0 - k) + k)) * (NdL / (NdL * (1.0 - k) + k));
  let F0 = mix(vec3f(0.04), albedo, metallic);
  let F = F0 + (vec3f(1.0) - F0) * pow(1.0 - VdH, 5.0);
  let spec = D * G * F / (4.0 * NdL * NdV + 1e-3);
  let kd = (vec3f(1.0) - F) * (1.0 - metallic);
  let direct = (kd * albedo / PI + spec) * frame.sunColor.rgb * NdL * shadow;
  let amb = ambientLight(N);
  let R = reflect(-V, N);
  let envSharp = envColor(R);
  let envSoft = ambientLight(R);
  let env = mix(envSharp, envSoft, clamp(r * r * 1.8, 0.0, 1.0));
  let Fe = F0 + (max(vec3f(1.0 - r), F0) - F0) * pow(1.0 - NdV, 5.0);
  let horizon = smoothstep(-0.1, 0.1, R.y);
  var col = direct + kd * albedo * amb * ao + env * Fe * mix(0.35, 1.0, horizon) * ao * (1.0 - 0.88 * r);
  col += albedo * (poleLight(P, N) + headBeam(P, N)) / PI * (1.0 - metallic * 0.8);
  return col;
}

fn aces(x: vec3f) -> vec3f {
  let a = 2.51;
  let b = 0.03;
  let c = 2.43;
  let d = 0.59;
  let e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), vec3f(0.0), vec3f(1.0));
}

fn finishColor(c: vec3f, wp: vec3f) -> vec4f {
  // névoa atmosférica
  let dist = length(wp - frame.camPos.xyz);
  let fogAmt = 1.0 - exp(-dist * frame.params.w);
  let dir = normalize(wp - frame.camPos.xyz);
  let fogCol = select(skyColor(vec3f(dir.x, max(dir.y, 0.0) * 0.2, dir.z)), vec3f(0.01, 0.012, 0.016), frame.params.z > 0.5);
  var col = mix(c, fogCol, clamp(fogAmt, 0.0, 1.0));
  col += vec3f(1.0, 0.85, 0.6) * frame.misc.w * 0.12;
  let t = aces(col * 1.0);
  return vec4f(pow(t, vec3f(1.0 / 2.2)), 1.0);
}
