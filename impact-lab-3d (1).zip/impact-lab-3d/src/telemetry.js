// telemetry.js - painel de telemetria técnica: FPS, tempos de CPU/GPU, física, dispatches, draw calls e curva de g.

export class Telemetry {
  constructor() {
    this.frames = 0;
    this.fps = 0;
    this.frameMs = 0;
    this.worst = 0;
    this._acc = 0;
    this._n = 0;
    this._t = 0;
    this.physMs = 0;
    this.stepsPerFrame = 0;
    this.uiMs = 0;
    this.gHistory = new Float32Array(240);
    this.gHead = 0;
    this.gMax = 1;
    this.fpsHistory = new Float32Array(120);
    this.fHead = 0;
  }

  /** chamada por quadro com o tempo real decorrido (s) */
  frame(dtReal) {
    this.frames++;
    this._acc += dtReal; this._n++;
    this.worst = Math.max(this.worst * 0.98, dtReal * 1000);
    if (this._acc >= 0.5) {
      this.fps = this._n / this._acc;
      this.frameMs = (this._acc / this._n) * 1000;
      this.fpsHistory[this.fHead++ % this.fpsHistory.length] = this.fps;
      this._acc = 0; this._n = 0;
    }
  }

  pushG(g) {
    this.gHistory[this.gHead++ % this.gHistory.length] = g;
    if (g > this.gMax) this.gMax = g;
  }
  resetCurve() { this.gHistory.fill(0); this.gHead = 0; this.gMax = 1; }

  /** desenha a curva de desaceleração (g) em um canvas 2D */
  drawCurve(canvas) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(0, (h * i) / 4); ctx.lineTo(w, (h * i) / 4); ctx.stroke(); }
    const n = this.gHistory.length, top = Math.max(5, this.gMax * 1.1);
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const v = this.gHistory[(this.gHead + i) % n];
      const x = (i / (n - 1)) * w, y = h - (v / top) * (h - 4) - 2;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = '#ff8a3d'; ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.font = '10px ui-monospace,monospace';
    ctx.fillText(top.toFixed(0) + ' g', 3, 11);
  }
}
