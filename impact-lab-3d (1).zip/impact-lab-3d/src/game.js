// game.js - orquestração: inicialização (WebGPU + WASM), laço principal (requestAnimationFrame + passo fixo de física),
// gerenciador de simulação (iniciar/pausar/reiniciar/voltar a 200 m/câmera lenta), efeitos de impacto e resultado.

import { Physics, PhysicsError, O, PHASE, BRK } from './physics-bridge.js';
import { Renderer, RendererError } from './renderer.js';
import { displacePoint } from './deformation.js';
import { CameraRig, CAMERAS } from './cameras.js';
import { Controls } from './controls.js';
import { Telemetry } from './telemetry.js';
import { AudioEngine } from './audio.js';
import { UI, VEHICLES, MOTORS, OBSTACLES, TOUCH, MOBILE } from './ui.js';
import { clamp, mat4 } from './math.js';

const FIXED_DT = 1 / 480;
const MAX_FRAME = 0.1;          // limita o tempo real acumulado por quadro (evita "espiral da morte")
const QUALITY = {
  // maxPixels: orçamento de pixels internos (celular costuma ter 2-3 MP na tela; MSAA 4x multiplica o custo)
  low: { scale: 0.75, shadowSize: 1024, particles: 0.3, maxPixels: 600_000 },
  med: { scale: 0.9, shadowSize: 2048, particles: 0.65, maxPixels: 1_300_000 },
  high: { scale: 1, shadowSize: 2048, particles: 1, maxPixels: 3_500_000 }
};
const $ = (id) => document.getElementById(id);
const IDENT = [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]];

class Game {
  constructor() {
    this.mode = 'loading';
    this.phys = null; this.r = null; this.dims = null;
    this.ui = new UI({
      go: (s) => this.go(s), startTest: () => this.enterTrack(), configChanged: (v) => this.onConfigChanged(v),
      settingChanged: (k, v) => this.onSetting(k, v), action: (a, v) => this.action(a, v)
    });
    this.cams = new CameraRig();
    this.camIndex = 0;
    this.tele = new Telemetry();
    this.audio = new AudioEngine();
    this.controls = new Controls((a, e) => this.action(a, e));
    this.acc = 0; this.rate = 1; this.slow = false; this.paused = false;
    this.idleTimer = 0; this.resultTimer = -1; this.resultShown = false;
    this.lastEvents = 0; this.lastBroken = 0; this.lastCrushSum = 0;
    this.flash = 0; this.time = 0; this.menuT = 0;
    this.pose = { x: 0, y: 0, z: -200, yaw: 0, pitch: 0, roll: 0 };
    this.stepsLast = 0; this.physMs = 0; this._teleT = 0; this._thumbT = 0; this.recovering = false;
    this.last = performance.now();
  }

  // -------------------------------------------------------------------------------------------
  /** verifica pré-requisitos do navegador ANTES de baixar qualquer coisa e explica a causa em português */
  preflight() {
    const origin = location.origin === 'null' ? location.href : location.origin;
    if (location.protocol === 'file:') {
      this.ui.fatal('Abra por um servidor, não pelo arquivo', 'O navegador bloqueia módulos ES, fetch de shaders/WASM e WebGPU em páginas abertas via file://.',
        'Endereço atual: ' + location.href, ['No computador: rode "python3 serve.py" na pasta do projeto e abra o endereço mostrado.', 'No celular: abra o endereço HTTPS publicado (veja o README, seção "Celular").']);
      return false;
    }
    if (!window.isSecureContext) {
      this.ui.fatal('WebGPU exige conexão segura (HTTPS)', 'Esta página foi aberta por um endereço HTTP que o Chrome não considera seguro, então a WebGPU fica desativada. Só https:// e http://localhost são "contexto seguro".',
        'Endereço atual: ' + origin,
        ['Opção mais simples: publique a pasta em um serviço HTTPS gratuito (GitHub Pages, Netlify, Cloudflare Pages) e abra o link no celular.',
         'Pelo cabo USB: ative a depuração USB, rode "adb reverse tcp:8000 tcp:8000" e abra http://localhost:8000 no Chrome do celular.',
         'Pela rede Wi-Fi: no Chrome do celular abra chrome://flags/#unsafely-treat-insecure-origin-as-secure, adicione ' + origin + ', ative e reinicie o Chrome.',
         'Ou rode "python3 serve.py --https" no computador e aceite o aviso de certificado no celular.']);
      return false;
    }
    if (!navigator.gpu) {
      this.ui.fatal('WebGPU indisponível neste navegador', 'O Chrome não expõe a API WebGPU neste aparelho.', navigator.userAgent,
        ['Use o Google Chrome (não o navegador da Samsung, Firefox ou o app embutido de outros apps).', 'Android: Chrome 121 ou superior e Android 12 ou superior, em aparelhos com GPU Qualcomm ou ARM (Mali). Aparelhos mais antigos não têm WebGPU.',
         'Atualize o Chrome e o "Android System WebView"/sistema pela loja/configurações.', 'Em chrome://flags procure "WebGPU" e ative "Unsafe WebGPU Support", reiniciando o Chrome.', 'Abra diagnostico.html neste mesmo endereço para um relatório detalhado.']);
      return false;
    }
    return true;
  }

  async boot() {
    document.body.classList.toggle('is-touch', TOUCH);
    this.ui.init();
    if (!this.preflight()) return;
    document.addEventListener('visibilitychange', () => { if (document.hidden && this.mode === 'track' && !this.paused) this.action('pause'); if (document.hidden && this.audio.ctx) this.audio.ctx.suspend(); else if (this.audio.ctx) this.audio.ctx.resume(); });
    this.controls.bindTouch($('touch'));
    document.querySelectorAll('.js-fs').forEach((b) => b.addEventListener('click', () => this.toggleFullscreen()));
    try {
      this.ui.setLoading('Carregando módulo físico (WebAssembly)…');
      this.phys = await Physics.load();
      this.ui.setLoading('Inicializando WebGPU e compilando shaders…');
      await this.createRenderer();
    } catch (e) { this.showBootError(e); return; }
    this.bindCanvas();
    addEventListener('resize', () => this.r && this.r.resize());
    this.applySettings();
    this.ui.setAbout(`Adaptador: ${this.adapterText()} · Módulo físico v${this.phys.x.sim_version()} · passo fixo ${Math.round(1 / FIXED_DT)} Hz`);
    this.ui.show('menu'); this.mode = 'menu';
    this.onConfigChanged(true);
    this.last = performance.now();
    requestAnimationFrame((t) => this.frame(t));
  }

  adapterText() { const a = this.r && this.r.adapterInfo || {}; return [a.vendor, a.architecture, a.device, a.description].filter(Boolean).join(' ') || 'WebGPU'; }

  async createRenderer() {
    const canvas = $('gpu');
    this.dims = [0, 1, 2].map((v) => this.phys.vehicleSpec(v, 1, 0));
    this.r = await Renderer.create(canvas, { offscreen: /[?&]offscreen=1/.test(location.search) }); // offscreen: só para testes automatizados sem tela
    this.r.onError = (m) => { console.error('[WebGPU]', m); this.gpuErrors = (this.gpuErrors || 0) + 1; this.ui.toast('Erro de GPU: ' + String(m).slice(0, 160), true, 6000); };
    this.r.onDeviceLost = (info) => this.onDeviceLost(info);
    this.r.loadVehicles(this.dims);
    this.r.setQuality(QUALITY[this.ui.settings.quality] || QUALITY.high);
  }

  showBootError(e) {
    console.error(e);
    const help = [];
    let title = 'Não foi possível iniciar o simulador', msg = e.message || String(e);
    if (e instanceof RendererError) {
      if (e.code === 'no-webgpu') { title = 'WebGPU indisponível'; help.push('Use o Google Chrome 113 ou superior (desktop) ou Chrome 121+ no Android.', 'Verifique chrome://gpu e se a aceleração por hardware está ativada.', 'Em Linux, pode ser necessário iniciar com --enable-unsafe-webgpu --enable-features=Vulkan.', 'A página precisa ser aberta por http://localhost ou https:// (contexto seguro), não por file://.'); }
      else if (e.code === 'no-adapter') { title = 'Nenhuma GPU compatível'; help.push('Atualize os drivers de vídeo.', 'Desative extensões/flags que bloqueiem a GPU e reinicie o navegador.'); }
      else if (e.code === 'shader-compile') { title = 'Erro ao compilar shader (WGSL)'; }
      else if (e.code === 'shader-fetch') { title = 'Arquivo de shader não encontrado'; help.push('Sirva a pasta do projeto por um servidor HTTP (veja o README).'); }
    } else if (e instanceof PhysicsError) {
      title = 'Falha no módulo de física (WebAssembly)';
      help.push('Execute "make" na pasta physics/ para gerar wasm/sim.wasm.', 'Abra o projeto por um servidor HTTP (ex.: python3 -m http.server).');
    } else if (!navigator.gpu) { title = 'WebGPU indisponível'; }
    this.ui.fatal(title, msg, e.detail ? (Array.isArray(e.detail) ? e.detail.map((x) => x.message).join('\n') : String(e.detail)) : (e.stack || '').split('\n').slice(0, 4).join('\n'), help);
  }

  async onDeviceLost(info) {
    if (this.recovering) return;
    this.recovering = true; this._inflight = 0;
    console.warn('Dispositivo WebGPU perdido:', info && info.message);
    this.ui.toast('A GPU foi reiniciada. Recuperando…', true, 5000);
    try {
      await this.createRenderer();
      this.applySettings();
      this.recovering = false;
      if (this.mode === 'track') this.resetTest(false);
      this.ui.toast('Renderização recuperada.');
    } catch (e) { this.ui.fatal('Dispositivo gráfico perdido', 'Não foi possível recuperar a GPU automaticamente.', (info && info.message) || '', ['Recarregue a página.']); }
  }

  // -------------------------------------------------------------------------------------------
  // configuração
  // -------------------------------------------------------------------------------------------
  cfg() {
    const c = this.ui.config;
    return { vehicle: c.vehicle, motor: c.motor, extraMass: c.extra, obstacle: c.obstacle, targetKmh: c.target, face: c.face, angleDeg: c.angle, offsetM: c.offset, manual: c.manual };
  }

  onConfigChanged(visual) {
    if (!this.phys || this.mode === 'track') return;
    const c = this.ui.config;
    this.phys.configure(this.cfg());
    const launchKmh = this.phys.out[O.LAUNCH] * 3.6;
    this.ui.renderSpecs(this.phys.vehicleSpec(c.vehicle, c.motor, c.extra), { launchKmh });
    this.phys.configure(this.cfg());  // vehicleSpec reconstrói o modelo: restaura a configuração completa
    if (visual) { clearTimeout(this._thumbT); this._thumbT = setTimeout(() => this.refreshThumbs(), 120); }
  }

  async refreshThumbs() {
    if (!this.r || this.r.lost) return;
    const paint = this.ui.paintColor();
    try { for (let i = 0; i < 3; i++) this.ui.setThumb(i, await this.r.renderThumbnail(i, paint, 224, 116)); } catch (e) { console.warn('miniaturas:', e); }
  }

  onSetting(k, v) {
    if (k === 'telemetry') this.ui.showTelemetry(v);
    else this.applySettings();
  }

  applySettings() {
    const s = this.ui.settings;
    if (this.r) this.r.setQuality(QUALITY[s.quality] || QUALITY.high);
    this.audio.setVolume(s.volume);
    if (this.audio.enabled !== s.audio) { this.audio.enabled = s.audio; if (!s.audio) this.audio.setEnabled(false); else if (this.mode === 'track') this.audio.start(); }
    this.ui.showTelemetry(s.telemetry);
  }

  // -------------------------------------------------------------------------------------------
  // navegação e gerenciador de simulação
  // -------------------------------------------------------------------------------------------
  go(s) {
    if (s === 'play') return this.enterTrack();
    if (s === 'exit') { window.close(); this.ui.toast('Você pode fechar esta aba. Até a próxima!'); return; }
    if (this.mode === 'track') this.leaveTrack();
    this.mode = s;
    this.ui.show(s);
    if (s === 'garage') { this.onConfigChanged(true); this.cams.garage.auto = true; }
  }

  enterTrack() {
    this.audio.start();
    this.mode = 'track';
    this.ui.show('track');
    this.camIndex = 0; this.cams.setMode(CAMERAS[0].id); this.cams.orbit.auto = true; this.cams.orbit.yaw = 0.55;
    this.ui.setCamera(0);
    this.ui.setTitle(`${VEHICLES[this.ui.config.vehicle].name} · ${MOTORS[this.ui.config.motor]} · ${OBSTACLES[this.ui.config.obstacle]} · alvo ${Math.round(this.ui.config.target)} km/h`);
    this.controls.enabled = this.ui.config.manual;
    this.resetTest(true);
    if (TOUCH && matchMedia('(orientation: portrait)').matches) this.ui.toast('Dica: gire o celular para o modo paisagem e use ⛶ para tela cheia.', false, 5000);
  }

  leaveTrack() {
    for (const v of this.r.vehicles) v.deformer.reset();
    this.r.clearParticles();
    this.paused = false; this.ui.setPaused(false);
  }

  /** volta a 200 m, restaura a carroceria (física + malha + partículas). autoStart: inicia sozinho após 1 s */
  resetTest(autoStart) {
    const cfg = this.cfg();
    this.phys.configure(cfg);
    this.r.vehicle(cfg.vehicle).deformer.reset();
    this.r.clearParticles();
    this.acc = 0; this.paused = false; this.ui.setPaused(false);
    this.idleTimer = autoStart ? 1.0 : -1;
    this.resultShown = false; this.resultTimer = -1;
    this.lastEvents = 0; this.lastBroken = 0; this.lastCrushSum = 0; this.flash = 0;
    this.tele.resetCurve(); this.stepCount = 0;
    this.launchKmh = this.phys.out[O.LAUNCH] * 3.6;
    $('result').classList.add('hidden');
    this.cams._init = false;
    this.readPose();
  }

  action(a, arg) {
    if (a.startsWith('cam') && a.length === 4) { if (this.mode === 'track') this.setCamera(+a[3]); return; }
    switch (a) {
      case 'gamepad': this.ui.toast(arg ? 'Controle conectado: ' + String(arg).slice(0, 40) : 'Controle desconectado'); break;
      case 'fullscreen': this.toggleFullscreen(); break;
      case 'toggleHud': document.body.classList.toggle('hide-hud'); break;
      case 'toggleTelemetry': { const s = this.ui.settings; s.telemetry = !s.telemetry; $('set-telemetry').checked = s.telemetry; this.ui.showTelemetry(s.telemetry); break; }
      default: break;
    }
    if (this.mode !== 'track') { if (a === 'start' && this.mode === 'menu') this.enterTrack(); return; }
    switch (a) {
      case 'start': this.paused = false; this.ui.setPaused(false); this.idleTimer = -1; if (this.phys.out[O.PHASE] === PHASE.IDLE) this.phys.start(); break;
      case 'pause': this.paused = !this.paused; this.ui.setPaused(this.paused); this.idleTimer = this.paused ? -1 : this.idleTimer; break;
      case 'restart': this.resetTest(false); this.phys.start(); break;
      case 'reset200': case 'restoreBody': this.resetTest(false); break;
      case 'nextCamera': this.setCamera((this.camIndex + 1) % CAMERAS.length); break;
      case 'slowmo': this.slow = !this.slow; this.ui.setSlow(this.slow); break;
      case 'rate': this.rate = arg; break;
      case 'speedUp': case 'speedDown': {
        const L = [0.05, 0.1, 0.25, 0.5, 1, 2, 4]; let i = L.indexOf(this.rate); if (i < 0) i = 4;
        i = clamp(i + (a === 'speedUp' ? 1 : -1), 0, L.length - 1); this.rate = L[i]; this.ui.setRate(this.rate); break;
      }
      default: break;
    }
  }

  async toggleFullscreen() {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
        try { await screen.orientation.lock('landscape'); } catch { /* nem todos os navegadores permitem */ }
      } else await document.exitFullscreen();
    } catch (e) { this.ui.toast('Tela cheia indisponível neste navegador.', true); }
  }

  setCamera(i) { this.camIndex = i; this.cams.setMode(CAMERAS[i].id); this.ui.setCamera(i); }

  bindCanvas() {
    const cv = $('gpu');
    const ptrs = new Map();   // ponteiros ativos (1 dedo = girar, 2 dedos = pinça/zoom)
    let pinch = 0;
    cv.addEventListener('pointerdown', (e) => { ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); cv.setPointerCapture(e.pointerId); if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = Math.hypot(a.x - b.x, a.y - b.y); } });
    const end = (e) => { ptrs.delete(e.pointerId); pinch = 0; };
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    cv.addEventListener('pointermove', (e) => {
      const p = ptrs.get(e.pointerId); if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY;
      if (ptrs.size >= 2) {
        const [a, b] = [...ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y);
        if (pinch > 0 && this.mode === 'track' && this.camIndex === 0) this.cams.zoom((pinch - d) * 2.2);
        pinch = d; return;
      }
      if (this.mode === 'garage') this.cams.dragGarage(dx);
      else if (this.mode === 'track' && this.camIndex === 0) this.cams.drag(dx, dy);
    });
    cv.addEventListener('wheel', (e) => { if (this.mode === 'track' && this.camIndex === 0) { e.preventDefault(); this.cams.zoom(e.deltaY); } }, { passive: false });
    cv.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  // -------------------------------------------------------------------------------------------
  // laço principal
  // -------------------------------------------------------------------------------------------
  readPose() {
    const o = this.phys.out;
    this.pose = { x: o[O.X], y: o[O.Y], z: o[O.Z], yaw: o[O.YAW], pitch: o[O.PITCH], roll: o[O.ROLL] };
  }

  frame(now) {
    requestAnimationFrame((t) => this.frame(t));
    const real = Math.min(MAX_FRAME, (now - this.last) / 1000); this.last = now;
    this.tele.frame(real);
    if (!this.r || this.r.lost || this.recovering) return;
    this.time += real;
    const aspect = $('gpu').clientWidth / Math.max(1, $('gpu').clientHeight);
    const env = this.mode === 'garage' ? 'garage' : this.ui.settings.env;
    let f;
    if (this.mode === 'track') f = this.trackFrame(real, aspect, env);
    else if (this.mode === 'garage') f = this.garageFrame(real, aspect);
    else f = this.showcaseFrame(real, aspect, env);
    // contrapressão: não enfileira quadros novos enquanto a GPU ainda processa os anteriores (evita acúmulo de latência)
    if (this._inflight >= 2) { this.skipped = (this.skipped || 0) + 1; return; }
    try { this.r.renderFrame(f); this._inflight = (this._inflight || 0) + 1; this.r.device.queue.onSubmittedWorkDone().then(() => { this._inflight--; }, () => { this._inflight = 0; }); } catch (e) { console.error(e); this.ui.toast('Erro de renderização: ' + e.message, true, 6000); }
    const t = performance.now();
    if (t - this._teleT > 250) { this._teleT = t; this.updateTelemetryPanel(); }
  }

  // plano de fundo do menu/configurações/sobre: veículo parado a 5 m da parede com câmera em órbita lenta
  showcaseFrame(dt, aspect, env) {
    this.menuT += dt;
    const c = this.ui.config, d = this.dims[c.vehicle], a = 0.9 + this.menuT * 0.12;
    const pose = { x: 0, y: 0, z: -5.2, yaw: 0, pitch: 0, roll: 0 };
    const tgt = [0, 0.8, -4.5], R = 9.5;
    const eye = [Math.sin(a) * R * 0.55 + 3, 1.7, -5.2 - Math.cos(a) * R * 0.5 - 1.5];
    eye[2] = Math.min(eye[2], -1.2);
    return this.makeFrame({ mode: 'track', env, cam: this.camFrom(eye, tgt, 0.8, aspect), pose, dt: 0, effects: false });
  }

  garageFrame(dt, aspect) {
    const c = this.ui.config, d = this.dims[c.vehicle];
    const w = innerWidth, h = innerHeight, compact = w <= 900 || h <= 520;
    const layout = !compact ? {} : (aspect < 1 ? { shiftDown: 0.55 } : { shiftRight: 1.25 });
    const g = this.cams.garageCamera(dt, aspect, d.length, layout);
    const pose = { x: 0, y: 0.18, z: 0, yaw: g.yaw, pitch: 0, roll: 0 };
    return this.makeFrame({ mode: 'garage', env: 'garage', cam: g, pose, dt: 0, effects: false });
  }

  camFrom(eye, tgt, fov, aspect) {
    return { eye, view: mat4.lookAt(eye, tgt, [0, 1, 0]), proj: mat4.perspective(fov, aspect, 0.1, 3000) };
  }

  makeFrame({ mode, env, cam, pose, dt, effects, crush, wheels, broken, brake, speedKmh, obstacle, flash, headlights }) {
    const c = this.ui.config;
    const night = env === 'night' || env === 'dusk';
    return {
      mode, env, cam, time: this.time, dt, effects: effects !== false, flash: flash || 0,
      vehicle: {
        index: c.vehicle, paint: this.ui.paintColor(), pose, broken: broken || 0, brake: brake || 0,
        headlights: headlights !== undefined ? headlights : night, speedKmh: speedKmh || 0,
        wheels: wheels || { steer: 0, spin: 0, offsets: IDENT, toe: [0, 0, 0, 0] }
      },
      obstacle: obstacle || { type: c.obstacle, travel: 0, wallActive: true },
      crush
    };
  }

  trackFrame(real, aspect, env) {
    const ph = this.phys, o = ph.out, c = this.ui.config;
    ph.sync();
    // contagem regressiva inicial
    if (this.idleTimer > 0 && !this.paused) { this.idleTimer -= real; if (this.idleTimer <= 0) { this.idleTimer = -1; ph.start(); } }

    // entrada manual
    const inp = this.controls.poll(real);
    if (c.manual) ph.setInput(inp.throttle, inp.brake, inp.steer);

    // passo fixo com acumulador (independe da taxa de quadros; pausa não acumula)
    const timeScale = this.paused ? 0 : this.rate * (this.slow ? 0.1 : 1);
    this.acc += real * timeScale;
    let steps = 0;
    const t0 = performance.now();
    const maxSteps = 4000;
    const wasImpacted = o[O.IMPACTED];
    while (this.acc >= FIXED_DT && steps < maxSteps) {
      ph.step(FIXED_DT);
      this.acc -= FIXED_DT; steps++; this.stepCount++;
      if (o[O.IMPACTED] && (this.stepCount & 1) === 0) this.tele.pushG(o[O.GNOW]);
    }
    if (steps >= maxSteps) this.acc = 0;
    this.physMs = performance.now() - t0; this.stepsLast = steps;
    this.readPose();
    const phase = o[O.PHASE], impacted = o[O.IMPACTED] > 0.5;

    // eventos de impacto
    const events = o[O.EVENTS];
    if (events !== this.lastEvents) {
      this.lastEvents = events;
      this.onImpactEvent(o[O.EVSTR], !wasImpacted);
    }
    this.flash *= Math.exp(-9 * real);
    const brokenMask = o[O.BROKEN] | 0;
    if (brokenMask !== this.lastBroken) {
      const newly = brokenMask & ~this.lastBroken;
      this.lastBroken = brokenMask;
      if (newly & (BRK.WSHIELD | BRK.RGLASS | BRK.WIN_L | BRK.WIN_R)) this.onGlassBreak();
    }
    // emissão contínua durante o esmagamento (poeira/faíscas conforme o crescimento do esmagamento)
    let crushSum = 0; for (let i = 0; i < 36; i++) crushSum += ph.crush[i];
    const dCrush = crushSum - this.lastCrushSum; this.lastCrushSum = crushSum;
    if (dCrush > 0.002 && this.ui.settings.particles) this.emitCrushDebris(dCrush, o[O.SPEED]);

    // rodas (esterçamento, giro e deslocamento por suspensão avariada)
    const geom = this.r.vehicle(c.vehicle).geom;
    const offsets = [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]], toe = [0, 0, 0, 0];
    if (impacted && crushSum > 0.01) {
      for (let w = 0; w < 4; w++) {
        const r = displacePoint(ph.crush, ph.dirs, ph.samples, geom.dims, geom.wheelPos[w], geom.beltY);
        offsets[w] = [r[0], 0, r[2]];
        if (w < 2) toe[w] = clamp(r[3] * 0.45, 0, 0.35) * (w === 0 ? 1 : -1);
      }
    }
    const wheels = { steer: o[O.STEER], spin: o[O.SPIN], offsets, toe };

    // câmera
    const timeSinceImpact = impacted ? Math.max(0, o[O.T] - o[O.TIMPACT]) : 0;
    if (!this.ui.settings.shake) this.cams.shake = 0;
    const cam = this.cams.update(real, aspect, { pose: this.pose, dims: geom.dims, geom, speed: o[O.SPEED], phase, impacted, timeSinceImpact, paused: this.paused });

    // HUD / áudio
    const speedKmh = o[O.SPEED] * 3.6;
    this.ui.updateHud({
      speedKmh, dist: o[O.DIST], time: o[O.T], g: o[O.GNOW], out: o, gaugeMax: c.target > 180 || this.launchKmh > 190 ? 300 : 200, targetKmh: c.target
    });
    this.ui.setPhase(this.phaseText(phase));
    this.audio.update(o[O.SPEED], o[O.THR], phase === PHASE.RUNNING || phase === PHASE.IDLE);

    // resultado ao repousar
    if (phase === PHASE.SETTLED && !this.resultShown) {
      if (this.resultTimer < 0) this.resultTimer = 1.0;
      else { this.resultTimer -= real; if (this.resultTimer <= 0) this.showResult(); }
    }

    return this.makeFrame({
      mode: 'track', env, cam, pose: this.pose, dt: real * timeScale, effects: this.ui.settings.particles, flash: this.flash,
      crush: { crush: ph.crush, dirs: ph.dirs, samples: ph.samples }, wheels, broken: brokenMask, brake: o[O.BRAKELIGHT], speedKmh,
      obstacle: { type: c.obstacle, travel: o[O.OBSTRAVEL], wallActive: true }
    });
  }

  phaseText(p) {
    let t = ['Pronto · 200 m', 'Em movimento', 'Impacto', 'Em repouso'][p] || '';
    if (this.paused) t = 'Pausado';
    else if (this.slow) t += ' · câmera lenta';
    else if (this.rate !== 1) t += ' · ' + String(this.rate).replace('.', ',') + '×';
    return t;
  }

  showResult() {
    this.resultShown = true;
    const o = this.phys.out, ph = this.phys;
    let mc = 0; for (let i = 0; i < 36; i++) mc = Math.max(mc, ph.crush[i]);
    this.ui.showResult({ out: o, target: this.ui.config.target, launch: this.launchKmh, maxCrush: mc });
  }

  // -------------------------------------------------------------------------------------------
  // efeitos
  // -------------------------------------------------------------------------------------------
  onImpactEvent(strength, first) {
    const k = clamp(strength / 2.0e6, 0.05, 1);
    this.flash = Math.max(this.flash, first ? 1 : k * 0.5);
    this.cams.kick(first ? 0.4 + k : k * 0.5);
    this.audio.impact(k);
    if (this.ui.settings.particles) {
      const o = this.phys.out;
      this.burst([o[O.IMPX], Math.max(0.25, o[O.IMPY] || 0.5), o[O.IMPZ]], clamp(Math.round(80 + k * 500), 60, 700), k);
    }
  }

  onGlassBreak() {
    this.audio.glass();
    if (!this.ui.settings.particles) return;
    const p = this.pose, g = this.r.vehicle(this.ui.config.vehicle).geom, n = 160;
    const sy = Math.sin(p.yaw), cy = Math.cos(p.yaw);
    const d = new Float32Array(n * 16);
    for (let i = 0; i < n; i++) {
      const lx = (Math.random() - 0.5) * 1.1, lz = g.dims.zf * 0.15 + Math.random() * 0.6, ly = 1.05 + Math.random() * 0.25;
      const o = i * 16, v = this.phys.out[O.SPEED];
      d[o] = p.x + cy * lx + sy * lz; d[o + 1] = ly; d[o + 2] = p.z - sy * lx + cy * lz; d[o + 3] = 1.6 + Math.random();
      const sp = 1 + Math.random() * 4;
      d[o + 4] = (Math.random() - 0.5) * sp; d[o + 5] = 1 + Math.random() * 3; d[o + 6] = (Math.random() - 0.3) * sp - v * 0.12; d[o + 7] = 0.025 + Math.random() * 0.03;
      d[o + 8] = 0.85; d[o + 9] = 0.95; d[o + 10] = 1; d[o + 11] = 0.9;
      d[o + 12] = 3; d[o + 13] = d[o + 3]; d[o + 14] = Math.random() * 6; d[o + 15] = Math.random();
    }
    this.r.spawnParticles(d);
  }

  /** explosão de partículas no ponto de impacto: poeira, faíscas, fragmentos */
  burst(center, n, k) {
    const d = new Float32Array(n * 16), speed = this.phys.out[O.VBEFORE] || this.phys.out[O.SPEED];
    const dirOut = this.dirFromWall();
    for (let i = 0; i < n; i++) {
      const o = i * 16, r = Math.random();
      const kind = r < 0.38 ? 0 : r < 0.68 ? 1 : 2;
      const life = kind === 0 ? 1.8 + Math.random() * 1.8 : kind === 1 ? 0.5 + Math.random() * 0.8 : 1.5 + Math.random() * 2.5;
      d[o] = center[0] + (Math.random() - 0.5) * 1.2; d[o + 1] = center[1] + (Math.random() - 0.4) * 0.7; d[o + 2] = center[2] + (Math.random() - 0.5) * 0.4;
      d[o + 3] = life;
      const sp = (kind === 1 ? 4 + Math.random() * 12 : kind === 2 ? 2 + Math.random() * 9 : 0.5 + Math.random() * 3) * (0.35 + k * 0.9 + speed * 0.006);
      let vx = (Math.random() - 0.5) * 1.4 + dirOut[0] * 0.9, vy = Math.random() * 0.9 + 0.1, vz = (Math.random() - 0.5) * 1.4 + dirOut[2] * 0.9;
      const l = Math.hypot(vx, vy, vz) || 1;
      d[o + 4] = vx / l * sp; d[o + 5] = vy / l * sp; d[o + 6] = vz / l * sp;
      d[o + 7] = kind === 0 ? 0.35 + Math.random() * 0.6 : kind === 1 ? 0.03 : 0.05 + Math.random() * 0.08;
      if (kind === 0) { const g = 0.45 + Math.random() * 0.2; d[o + 8] = g; d[o + 9] = g * 0.97; d[o + 10] = g * 0.92; d[o + 11] = 0.5; }
      else if (kind === 1) { d[o + 8] = 3.0; d[o + 9] = 1.6; d[o + 10] = 0.5; d[o + 11] = 1; }
      else { const p = this.ui.paintColor(); d[o + 8] = p[0]; d[o + 9] = p[1]; d[o + 10] = p[2]; d[o + 11] = 1; }
      d[o + 12] = kind; d[o + 13] = life; d[o + 14] = Math.random() * 6.28; d[o + 15] = Math.random();
    }
    this.r.spawnParticles(d);
  }

  /** direção horizontal "para longe do obstáculo" (aprox.): oposta à velocidade pré-impacto */
  dirFromWall() {
    const o = this.phys.out, vx = o[O.VX], vz = o[O.VZ], l = Math.hypot(vx, vz);
    if (l < 0.5) return [0, 0, -1];
    return [-vx / l, 0, -vz / l];
  }

  emitCrushDebris(dCrush, speed) {
    const n = clamp(Math.round(dCrush * 380), 1, 40);
    const o = this.phys.out;
    this.burst([o[O.IMPX], Math.max(0.3, o[O.IMPY] || 0.5), o[O.IMPZ]], n, clamp(speed / 40, 0.05, 0.6));
  }

  // -------------------------------------------------------------------------------------------
  updateTelemetryPanel() {
    if (!this.ui.settings.telemetry || this.mode !== 'track') return;
    const o = this.phys.out, st = this.r.stats, t = this.tele;
    const rows = [
      ['FPS', t.fps.toFixed(0)], ['Quadro (médio / pior)', t.frameMs.toFixed(1) + ' / ' + t.worst.toFixed(0) + ' ms'],
      ['CPU render', st.cpuMs.toFixed(2) + ' ms'], ['GPU (timestamp)', st.gpuMs == null ? (this.r.hasTimestamps ? '…' : 'n/d') : st.gpuMs.toFixed(2) + ' ms'],
      ['Física', this.physMs.toFixed(2) + ' ms · ' + this.stepsLast + ' passos'], ['Draw calls', String(st.drawCalls)], ['Dispatches deformação', String(st.dispatches)],
      ['Resolução', $('gpu').width + '×' + $('gpu').height], ['t simulado', o[O.T].toFixed(3) + ' s'], ['Sub-passos CCD', String(o[O.NSUB] | 0)],
      ['Contatos / F normal', (o[O.NCONTACT] | 0) + ' / ' + (o[O.FTOTAL] / 1000).toFixed(0) + ' kN'], ['Pico (corpo rígido)', o[O.PEAKG].toFixed(0) + ' g'], ['Erros de GPU', String(this.gpuErrors || 0)]
    ];
    $('tele-table').innerHTML = rows.map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('');
    t.drawCurve($('gcurve'));
  }
}

const game = new Game();
window.__impactlab = game; // gancho para testes automatizados
game.boot();
