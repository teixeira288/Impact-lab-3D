// audio.js - áudio sintetizado (Web Audio): motor, vento e impacto. Sem arquivos externos. Inicia após gesto do usuário.

export class AudioEngine {
  constructor() { this.ctx = null; this.enabled = true; this.volume = 0.5; this.on = false; }

  start() {
    if (this.ctx || !this.enabled) { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const c = this.ctx = new AC();
    this.master = c.createGain(); this.master.gain.value = this.volume; this.master.connect(c.destination);
    // motor: dois osciladores + filtro
    this.osc1 = c.createOscillator(); this.osc1.type = 'sawtooth';
    this.osc2 = c.createOscillator(); this.osc2.type = 'square';
    this.eng = c.createGain(); this.eng.gain.value = 0;
    this.lp = c.createBiquadFilter(); this.lp.type = 'lowpass'; this.lp.frequency.value = 600;
    this.osc1.connect(this.lp); this.osc2.connect(this.lp); this.lp.connect(this.eng); this.eng.connect(this.master);
    this.osc1.start(); this.osc2.start();
    // vento: ruído filtrado
    const buf = c.createBuffer(1, c.sampleRate * 2, c.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
    this.wind = c.createBufferSource(); this.wind.buffer = buf; this.wind.loop = true;
    this.wf = c.createBiquadFilter(); this.wf.type = 'bandpass'; this.wf.frequency.value = 500; this.wf.Q.value = 0.6;
    this.wg = c.createGain(); this.wg.gain.value = 0;
    this.wind.connect(this.wf); this.wf.connect(this.wg); this.wg.connect(this.master); this.wind.start();
    this.on = true;
  }

  setVolume(v) { this.volume = v; if (this.master) this.master.gain.value = v; }
  setEnabled(e) { this.enabled = e; if (!e && this.ctx) { this.ctx.close(); this.ctx = null; this.on = false; } }

  /** atualiza o som contínuo: velocidade (m/s), aceleração (0..1) e se o motor está ativo */
  update(speed, throttle, active) {
    if (!this.on) return;
    const t = this.ctx.currentTime;
    const rpm = 900 + Math.min(speed, 60) * 85 + throttle * 700;
    const f = rpm / 60 * 2;
    this.osc1.frequency.setTargetAtTime(f, t, 0.05); this.osc2.frequency.setTargetAtTime(f * 0.5, t, 0.05);
    this.lp.frequency.setTargetAtTime(350 + throttle * 900 + speed * 8, t, 0.08);
    this.eng.gain.setTargetAtTime(active ? 0.05 + throttle * 0.05 : 0, t, 0.08);
    this.wf.frequency.setTargetAtTime(300 + speed * 18, t, 0.1);
    this.wg.gain.setTargetAtTime(active ? Math.min(0.25, speed / 120) : 0, t, 0.1);
  }

  /** estrondo de impacto proporcional à energia/força (0..1) */
  impact(strength) {
    if (!this.on) return;
    const c = this.ctx, t = c.currentTime, s = Math.min(1, Math.max(0.1, strength));
    const src = c.createBufferSource(); src.buffer = this.noiseBuf;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(2500, t); lp.frequency.exponentialRampToValueAtTime(120, t + 0.8);
    const g = c.createGain(); g.gain.setValueAtTime(s * 1.0, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.9);
    src.connect(lp); lp.connect(g); g.connect(this.master); src.start(t); src.stop(t + 1);
    const o = c.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(90, t); o.frequency.exponentialRampToValueAtTime(30, t + 0.5);
    const og = c.createGain(); og.gain.setValueAtTime(s * 0.9, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
    o.connect(og); og.connect(this.master); o.start(t); o.stop(t + 0.7);
  }

  /** estilhaços de vidro */
  glass() {
    if (!this.on) return;
    const c = this.ctx, t = c.currentTime;
    const src = c.createBufferSource(); src.buffer = this.noiseBuf;
    const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 3500;
    const g = c.createGain(); g.gain.setValueAtTime(0.35, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
    src.connect(hp); hp.connect(g); g.connect(this.master); src.start(t); src.stop(t + 0.8);
  }
}
