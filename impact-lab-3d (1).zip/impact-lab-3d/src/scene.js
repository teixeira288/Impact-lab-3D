// scene.js - geometria 3D do cenário: pista de testes, obstáculos, edifícios, garagem e atlas de textos.
// Todas as malhas são procedurais (nenhuma imagem 2D substitui geometria). Formato do vértice:
// pos(3) normal(3) uv(2) material(1) = 9 floats.

export const SMAT = {
  ASPHALT: 0, GRASS: 1, CONCRETE: 2, METAL: 3, BUILDING: 4, GLASS: 5, LAMP: 6, DECAL: 7, CURB: 8, BARRIER: 9,
  MOUNTAIN: 10, GARAGE_FLOOR: 11, GARAGE_WALL: 12, LIGHT: 13, PLATFORM: 14, FOLIAGE: 18, TRUNK: 19
};

const ATLAS_W = 2048, ATLAS_H = 1024;
export const ATLAS_RECTS = {};
const LABELS = [25, 50, 75, 100, 125, 150, 175, 200];
LABELS.forEach((v, i) => { const c = i % 4, r = Math.floor(i / 4); ATLAS_RECTS['d' + v] = [c * 256, r * 128, c * 256 + 256, r * 128 + 128]; });
ATLAS_RECTS.logo = [0, 256, 1600, 656];
ATLAS_RECTS.banner = [1600, 256, 1856, 768];
ATLAS_RECTS.obs = [0, 768, 1024, 896];
ATLAS_RECTS.track = [1024, 768, 2048, 896];
ATLAS_RECTS.lab = [0, 896, 1024, 1024];
const rectUV = (n) => { const r = ATLAS_RECTS[n]; return [r[0] / ATLAS_W, r[1] / ATLAS_H, r[2] / ATLAS_W, r[3] / ATLAS_H]; };

/** Desenha o atlas de textos (canvas 2D) usado por decalques e placas. */
export function makeAtlasCanvas() {
  const c = (typeof OffscreenCanvas !== 'undefined') ? new OffscreenCanvas(ATLAS_W, ATLAS_H) : Object.assign(document.createElement('canvas'), { width: ATLAS_W, height: ATLAS_H });
  const g = c.getContext('2d');
  g.clearRect(0, 0, ATLAS_W, ATLAS_H);
  g.textAlign = 'center'; g.textBaseline = 'middle';
  for (const v of LABELS) {
    const [x0, y0, x1, y1] = ATLAS_RECTS['d' + v];
    g.font = '700 84px "Segoe UI", Arial, sans-serif'; g.fillStyle = '#f2f4f5';
    g.fillText(v + ' m', (x0 + x1) / 2, (y0 + y1) / 2 + 4);
  }
  const panel = (name, bg, draw) => {
    const [x0, y0, x1, y1] = ATLAS_RECTS[name];
    g.fillStyle = bg; g.fillRect(x0, y0, x1 - x0, y1 - y0);
    draw(x0, y0, x1 - x0, y1 - y0);
  };
  panel('logo', '#071019', (x, y, w, h) => {
    const grd = g.createLinearGradient(x, y, x + w, y + h); grd.addColorStop(0, '#0c2238'); grd.addColorStop(1, '#050b12');
    g.fillStyle = grd; g.fillRect(x, y, w, h);
    g.strokeStyle = '#27a8ff'; g.lineWidth = 8; g.strokeRect(x + 14, y + 14, w - 28, h - 28);
    g.font = 'italic 900 210px "Segoe UI", Arial, sans-serif'; g.fillStyle = '#f4f7fa';
    g.fillText('IMPACT LAB', x + w * 0.40, y + h * 0.5);
    g.fillStyle = '#2d9bff'; g.fillText('3D', x + w * 0.88, y + h * 0.5);
  });
  panel('banner', '#0b3a66', (x, y, w, h) => {
    g.fillStyle = '#0a2c4d'; g.fillRect(x, y, w, h);
    g.save(); g.translate(x + w / 2, y + h / 2); g.rotate(-Math.PI / 2);
    g.font = 'italic 900 112px "Segoe UI", Arial, sans-serif'; g.fillStyle = '#ffffff'; g.fillText('IMPACT LAB', 0, -14);
    g.fillStyle = '#4db3ff'; g.font = 'italic 900 90px "Segoe UI", Arial, sans-serif'; g.fillText('3D', 0, 76); g.restore();
  });
  panel('obs', '#10151b', (x, y, w, h) => {
    g.strokeStyle = '#27a8ff'; g.lineWidth = 6; g.strokeRect(x + 6, y + 6, w - 12, h - 12);
    g.font = '700 62px "Segoe UI", Arial, sans-serif'; g.fillStyle = '#e9f2fa'; g.fillText('ÁREA DE OBSERVAÇÃO', x + w / 2, y + h / 2 + 3);
  });
  panel('track', '#10151b', (x, y, w, h) => {
    g.strokeStyle = '#27a8ff'; g.lineWidth = 6; g.strokeRect(x + 6, y + 6, w - 12, h - 12);
    g.font = '700 62px "Segoe UI", Arial, sans-serif'; g.fillStyle = '#e9f2fa'; g.fillText('PISTA DE TESTES • 200 m', x + w / 2, y + h / 2 + 3);
  });
  panel('lab', '#10151b', (x, y, w, h) => {
    g.font = '700 70px "Segoe UI", Arial, sans-serif'; g.fillStyle = '#9fdcff'; g.fillText('LABORATÓRIO DE COLISÕES', x + w / 2, y + h / 2 + 3);
  });
  return c;
}

class SceneMesh {
  constructor() { this.v = []; this.i = []; }
  get n() { return this.v.length / 9; }
  vert(p, n, uv, m) { this.v.push(p[0], p[1], p[2], n[0], n[1], n[2], uv[0], uv[1], m); return this.n - 1; }
  quad(p0, p1, p2, p3, n, m, uvr = [0, 0, 1, 1]) {
    const a = this.vert(p0, n, [uvr[0], uvr[3]], m), b = this.vert(p1, n, [uvr[2], uvr[3]], m);
    const c = this.vert(p2, n, [uvr[2], uvr[1]], m), d = this.vert(p3, n, [uvr[0], uvr[1]], m);
    this.i.push(a, b, c, a, c, d);
  }
  /** caixa alinhada aos eixos (x0..x1, y0..y1, z0..z1). */
  box(x0, y0, z0, x1, y1, z1, m, uvr) {
    this.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], [0, 0, 1], m, uvr);
    this.quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [0, 0, -1], m, uvr);
    this.quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [1, 0, 0], m, uvr);
    this.quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], [-1, 0, 0], m, uvr);
    this.quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], [0, 1, 0], m, uvr);
    this.quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [0, -1, 0], m, uvr);
  }
  /** apenas a face frontal (z = z0, normal -z), para placas e painéis */
  panelZ(x0, y0, x1, y1, z, nz, m, uvr) {
    if (nz < 0) this.quad([x1, y0, z], [x0, y0, z], [x0, y1, z], [x1, y1, z], [0, 0, -1], m, uvr);
    else this.quad([x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z], [0, 0, 1], m, uvr);
  }
  cyl(cx, cy, cz, r, h, seg, m, cap = true) {
    for (let k = 0; k < seg; k++) {
      const a0 = (k / seg) * Math.PI * 2, a1 = ((k + 1) / seg) * Math.PI * 2;
      const c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
      const p0 = [cx + r * c0, cy, cz + r * s0], p1 = [cx + r * c1, cy, cz + r * s1];
      const a = this.vert(p0, [c0, 0, s0], [k / seg, 0], m), b = this.vert(p1, [c1, 0, s1], [(k + 1) / seg, 0], m);
      const c = this.vert([p1[0], cy + h, p1[2]], [c1, 0, s1], [(k + 1) / seg, 1], m), d = this.vert([p0[0], cy + h, p0[2]], [c0, 0, s0], [k / seg, 1], m);
      this.i.push(a, c, b, a, d, c);
      if (cap) {
        const t = this.vert([cx, cy + h, cz], [0, 1, 0], [0.5, 0.5], m), t0 = this.vert([p0[0], cy + h, p0[2]], [0, 1, 0], [0, 0], m), t1 = this.vert([p1[0], cy + h, p1[2]], [0, 1, 0], [1, 0], m);
        this.i.push(t, t1, t0);
      }
    }
  }
  cone(cx, cy, cz, r, h, seg, m) {
    for (let k = 0; k < seg; k++) {
      const a0 = (k / seg) * Math.PI * 2, a1 = ((k + 1) / seg) * Math.PI * 2;
      const c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
      const am = (a0 + a1) / 2, nn = [Math.cos(am) * 0.8, 0.6, Math.sin(am) * 0.8];
      const a = this.vert([cx + r * c0, cy, cz + r * s0], nn, [0, 0], m), b = this.vert([cx + r * c1, cy, cz + r * s1], nn, [1, 0], m), t = this.vert([cx, cy + h, cz], nn, [0.5, 1], m);
      this.i.push(a, t, b);
    }
  }
  build() { return { vertices: new Float32Array(this.v), indices: new Uint32Array(this.i) }; }
}

function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

// ---------------------------------------------------------------------------------------------
// Pista: terreno (apenas recebe sombra) e props (projetam e recebem sombra)
// ---------------------------------------------------------------------------------------------
export function buildTrackGround() {
  const m = new SceneMesh();
  // grama
  m.quad([-1600, -0.03, 1600], [1600, -0.03, 1600], [1600, -0.03, -1600], [-1600, -0.03, -1600], [0, 1, 0], SMAT.GRASS);
  // asfalto da pista (z de -330 a +45) e pátio de apoio
  m.quad([-8.2, 0, 45], [8.2, 0, 45], [8.2, 0, -330], [-8.2, 0, -330], [0, 1, 0], SMAT.ASPHALT);
  m.quad([12, 0, -20], [48, 0, -20], [48, 0, -130], [12, 0, -130], [0, 1, 0], SMAT.ASPHALT);
  m.quad([-52, 0, -20], [-12, 0, -20], [-12, 0, -100], [-52, 0, -100], [0, 1, 0], SMAT.ASPHALT);
  m.quad([8.2, 0, -50], [12, 0, -50], [12, 0, -30], [8.2, 0, -30], [0, 1, 0], SMAT.ASPHALT);
  // zebras laterais
  for (const s of [-1, 1]) m.box(s > 0 ? 8.2 : -8.8, 0, -330, s > 0 ? 8.8 : -8.2, 0.03, 45, SMAT.CURB);
  // marcadores no chão
  for (const v of LABELS) {
    const uv = rectUV('d' + v);
    // u cresce para -x (direita de quem olha para +z): o texto lê-se corretamente atrás do veículo
    m.quad([-3.1, 0.012, -v - 1.8], [-6.3, 0.012, -v - 1.8], [-6.3, 0.012, -v + 1.0 - 1.8 + 0.8], [-3.1, 0.012, -v + 1.0 - 1.8 + 0.8], [0, 1, 0], SMAT.DECAL, uv);
  }
  // marcador "200 m" grande na linha de largada
  m.quad([6.0, 0.012, -203.3], [2.2, 0.012, -203.3], [2.2, 0.012, -201.6], [6.0, 0.012, -201.6], [0, 1, 0], SMAT.DECAL, rectUV('d200'));
  return m.build();
}

export function buildTrackProps() {
  const m = new SceneMesh();
  const R = rng(12345);
  // postes de iluminação (a cada 36 m, x = +-10)
  for (let z = -324; z <= 36; z += 36) {
    for (const s of [-1, 1]) {
      const x = s * 10;
      m.box(x - 0.12, 0, z - 0.12, x + 0.12, 8.8, z + 0.12, SMAT.METAL);
      m.box(x - (s > 0 ? 1.6 : -0.0), 8.7, z - 0.1, x + (s > 0 ? 0.0 : 1.6), 8.85, z + 0.1, SMAT.METAL);
      m.box(x - s * 1.7 - 0.45, 8.62, z - 0.22, x - s * 1.7 + 0.45, 8.72, z + 0.22, SMAT.LAMP);
    }
  }
  // cerca de proteção e postes
  for (const s of [-1, 1]) {
    const x = s * 9.3;
    m.box(x - 0.03, 0.55, -330, x + 0.03, 0.62, 45, SMAT.METAL);
    m.box(x - 0.03, 1.0, -330, x + 0.03, 1.07, 45, SMAT.METAL);
    for (let z = -328; z <= 44; z += 4) m.box(x - 0.06, 0, z - 0.06, x + 0.06, 1.1, z + 0.06, SMAT.METAL);
  }
  // placas de distância (a cada 25 m) nas duas laterais
  for (const v of LABELS) {
    const uv = rectUV('d' + v);
    for (const s of [-1, 1]) {
      const x = s * 8.85;
      m.box(x - 0.04, 0, -v - 0.04, x + 0.04, 1.4, -v + 0.04, SMAT.METAL);
      // face voltada para a pista, legível por quem vem da largada
      if (s > 0) m.quad([x - 0.06, 1.1, -v - 0.55], [x - 0.06, 1.1, -v + 0.55], [x - 0.06, 1.65, -v + 0.55], [x - 0.06, 1.65, -v - 0.55], [-1, 0, 0], SMAT.DECAL, uv);
      else m.quad([x + 0.06, 1.1, -v + 0.55], [x + 0.06, 1.1, -v - 0.55], [x + 0.06, 1.65, -v - 0.55], [x + 0.06, 1.65, -v + 0.55], [1, 0, 0], SMAT.DECAL, uv);
    }
  }
  // outdoor "IMPACT LAB 3D" ao lado da parede
  m.box(13.0, 0, -13.2, 13.4, 5.2, -12.8, SMAT.METAL);
  m.box(27.6, 0, -13.2, 28.0, 5.2, -12.8, SMAT.METAL);
  m.box(12.6, 2.4, -12.8, 28.4, 6.0, -12.6, SMAT.METAL);
  m.panelZ(12.9, 2.6, 28.1, 5.8, -12.74, -1, SMAT.DECAL, rectUV('logo'));
  // bandeira vertical
  m.box(9.7, 0, -6.1, 9.9, 7.5, -5.9, SMAT.METAL);
  m.panelZ(8.6, 3.0, 9.7, 7.0, -6.12, -1, SMAT.DECAL, rectUV('banner'));
  // área de observação (edifício de 2 pavimentos, fachada de vidro voltada para a pista)
  m.box(20, 0, -76, 40, 0.3, -30, SMAT.CONCRETE);
  m.box(20, 0.3, -76, 40, 6.6, -70, SMAT.BUILDING);
  m.box(20, 0.3, -76, 21, 6.6, -30, SMAT.BUILDING);
  m.box(39, 0.3, -76, 40, 6.6, -30, SMAT.BUILDING);
  m.box(20, 0.3, -31, 40, 6.6, -30, SMAT.BUILDING);
  m.box(20, 3.4, -76, 21.4, 3.7, -30, SMAT.CONCRETE);
  m.box(20, 0.3, -76, 20.35, 6.6, -30, SMAT.GLASS);
  m.box(17.5, 6.6, -78, 40.5, 7.0, -28, SMAT.CONCRETE);
  for (let z = -75; z <= -31; z += 11) m.box(17.7, 0.3, z - 0.18, 18.1, 6.6, z + 0.18, SMAT.CONCRETE);
  m.panelZ(24, 7.05, 36, 8.2, -27.9, -1, SMAT.DECAL, rectUV('obs'));
  m.panelZ(24, 7.05, 36, 8.2, -78.1, 1, SMAT.DECAL, rectUV('obs'));
  m.quad([17.45, 7.05, -40], [17.45, 7.05, -68], [17.45, 8.2, -68], [17.45, 8.2, -40], [-1, 0, 0], SMAT.DECAL, rectUV('obs'));
  // torre de controle
  m.box(26, 0, -118, 30, 15, -114, SMAT.BUILDING);
  m.box(24.8, 15, -119.2, 31.2, 15.4, -112.8, SMAT.CONCRETE);
  m.box(25.0, 15.4, -119, 31.0, 18.2, -113, SMAT.GLASS);
  m.box(24.8, 18.2, -119.2, 31.2, 18.6, -112.8, SMAT.CONCRETE);
  m.box(27.9, 18.6, -116.1, 28.1, 23, -115.9, SMAT.METAL);
  // box de garagem / laboratório
  m.box(-46, 0, -88, -24, 5.0, -36, SMAT.BUILDING);
  m.box(-46.5, 5.0, -88.5, -23.5, 5.4, -35.5, SMAT.CONCRETE);
  m.box(-24.1, 0.0, -84, -23.9, 4.2, -40, SMAT.GLASS);
  for (let z = -82; z <= -42; z += 10) m.box(-24.2, 0, z - 2.2, -23.8, 3.2, z + 2.2, SMAT.METAL);
  m.quad([-23.8, 5.6, -76], [-23.8, 5.6, -48], [-23.8, 7.0, -48], [-23.8, 7.0, -76], [1, 0, 0], SMAT.DECAL, rectUV('lab'));
  // arquibancada simples
  for (let k = 0; k < 6; k++) m.box(-8.2 - 3.2 - k * 1.4 - 0.0, 0, -165, -8.2 - 0.0 - 3.2 - k * 1.4 + 1.4, 0.5 + k * 0.5, -135, SMAT.CONCRETE);
  // árvores
  for (let i = 0; i < 180; i++) {
    const side = R() < 0.5 ? -1 : 1;
    const x = side * (22 + R() * 140), z = -330 + R() * 400;
    if (Math.abs(x) < 52 && z > -135 && z < -20) continue;
    if (x > 8 && x < 50 && z > -140 && z < -10) continue;
    const h = 5 + R() * 5;
    m.cyl(x, 0, z, 0.25, 2.2, 6, SMAT.TRUNK);
    m.cone(x, 1.6, z, 1.9 + R() * 0.8, h, 8, SMAT.FOLIAGE);
  }
  return m.build();
}

export function buildMountains() {
  const m = new SceneMesh();
  const N = 120, Rr = 1250;
  const hAt = (a) => 70 + 80 * Math.sin(a * 3 + 0.7) * Math.sin(a * 7.3) + 55 * Math.sin(a * 13.1 + 2) + 40 * Math.abs(Math.sin(a * 5.7 + 1)) + 25 * Math.sin(a * 29);
  for (let k = 0; k < N; k++) {
    const a0 = (k / N) * Math.PI * 2, a1 = ((k + 1) / N) * Math.PI * 2;
    const h0 = Math.max(10, hAt(a0)), h1 = Math.max(10, hAt(a1));
    const p = (a, y) => [Math.cos(a) * Rr, y, Math.sin(a) * Rr];
    const n = [-Math.cos((a0 + a1) / 2), 0.2, -Math.sin((a0 + a1) / 2)];
    const a = m.vert(p(a0, -20), n, [0, 0], SMAT.MOUNTAIN), b = m.vert(p(a1, -20), n, [1, 0], SMAT.MOUNTAIN);
    const c = m.vert(p(a1, h1), n, [1, 1], SMAT.MOUNTAIN), d = m.vert(p(a0, h0), n, [0, 1], SMAT.MOUNTAIN);
    m.i.push(a, c, b, a, d, c);
  }
  return m.build();
}

// ---------------------------------------------------------------------------------------------
// Obstáculos (superfície de contato em z = 0, material atrás em z > 0)
// ---------------------------------------------------------------------------------------------
export function buildObstacles() {
  const wall = new SceneMesh();
  wall.box(-12, 0, 0, 12, 4.2, 1.6, SMAT.CONCRETE);
  wall.box(-12.2, 4.2, -0.15, 12.2, 4.45, 1.75, SMAT.CONCRETE);
  const barrier = new SceneMesh();
  // barreira de segurança: módulos amarelos/pretos com 1,2 m de profundidade (curso de absorção)
  barrier.box(-6, 0, 0, 6, 1.1, 1.2, SMAT.BARRIER);
  const pole = new SceneMesh();
  pole.box(-0.3, 0, 0, 0.3, 4.0, 0.6, SMAT.CONCRETE);
  pole.box(-0.36, 3.9, -0.06, 0.36, 4.1, 0.66, SMAT.CONCRETE);
  pole.box(-0.12, 0.0, 0.6, 0.12, 1.2, 0.72, SMAT.METAL);
  const block = new SceneMesh();
  block.box(-1, 0, 0, 1, 1.6, 2, SMAT.CONCRETE);
  return { wall: wall.build(), barrier: barrier.build(), pole: pole.build(), block: block.build() };
}

// ---------------------------------------------------------------------------------------------
// Garagem 3D: sala de exposição com plataforma giratória e iluminação cinematográfica
// ---------------------------------------------------------------------------------------------
export function buildGarage() {
  const m = new SceneMesh();
  const X0 = -15, X1 = 15, Z0 = -13, Z1 = 15, H = 7.2;
  m.quad([X0, 0, Z1], [X1, 0, Z1], [X1, 0, Z0], [X0, 0, Z0], [0, 1, 0], SMAT.GARAGE_FLOOR);
  m.quad([X0, H, Z0], [X1, H, Z0], [X1, H, Z1], [X0, H, Z1], [0, -1, 0], SMAT.GARAGE_WALL);
  m.quad([X1, 0, Z1], [X0, 0, Z1], [X0, H, Z1], [X1, H, Z1], [0, 0, -1], SMAT.GARAGE_WALL);
  m.quad([X0, 0, Z0], [X1, 0, Z0], [X1, H, Z0], [X0, H, Z0], [0, 0, 1], SMAT.GARAGE_WALL);
  m.quad([X0, 0, Z1], [X0, 0, Z0], [X0, H, Z0], [X0, H, Z1], [1, 0, 0], SMAT.GARAGE_WALL);
  m.quad([X1, 0, Z0], [X1, 0, Z1], [X1, H, Z1], [X1, H, Z0], [-1, 0, 0], SMAT.GARAGE_WALL);
  // barras de luz no teto
  for (const x of [-4.2, 4.2]) m.box(x - 0.18, H - 0.12, Z0 + 1, x + 0.18, H - 0.02, Z1 - 1, SMAT.LIGHT, [0, 0, 1, 0.25]);
  m.box(-8, H - 0.12, -6, 8, H - 0.02, -5.7, SMAT.LIGHT, [0, 0, 1, 0.25]);
  m.box(-8, H - 0.12, 5.7, 8, H - 0.02, 6, SMAT.LIGHT, [0, 0, 1, 0.25]);
  // colunas com neon azul
  for (const z of [-9, 0, 9]) for (const x of [-13.5, 13.5]) {
    m.box(x - 0.45, 0, z - 0.45, x + 0.45, H, z + 0.45, SMAT.GARAGE_WALL);
    m.box(x - 0.47 + (x < 0 ? 0.94 : 0), 0.4, z - 0.12, x + 0.47 - (x > 0 ? 0.94 : 0), H - 0.8, z + 0.12, SMAT.LIGHT, [0, 0.7, 1, 1]);
  }
  // bancadas e armários ao fundo
  m.box(-12, 0, Z1 - 2.2, 12, 1.1, Z1 - 0.2, SMAT.GARAGE_WALL);
  m.box(-12, 1.1, Z1 - 2.3, 12, 1.2, Z1 - 0.1, SMAT.METAL);
  m.box(-12, 1.3, Z1 - 0.4, 12, 3.8, Z1 - 0.2, SMAT.GARAGE_WALL);
  m.box(-11.8, 1.9, Z1 - 0.42, 11.8, 2.0, Z1 - 0.38, SMAT.LIGHT, [0, 0.7, 1, 1]);
  // painel com o logotipo
  m.panelZ(-6, 3.6, 6, 6.2, Z1 - 0.1, -1, SMAT.DECAL, rectUV('logo'));
  // plataforma de exposição (disco giratório)
  m.cyl(0, 0, 0, 3.4, 0.18, 64, SMAT.PLATFORM, true);
  m.cyl(0, 0, 0, 3.6, 0.07, 64, SMAT.PLATFORM, true);
  return m.build();
}
