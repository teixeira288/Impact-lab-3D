// controls.js - entrada: teclado, Gamepad API e controles de toque.
// Produz um estado analógico { throttle, brake, steer } (steer: -1 direita .. +1 esquerda, convenção yaw+ = esquerda)
// e dispara "ações" (pausar, reiniciar, trocar câmera...) por callback.

const DEAD = 0.12;

export class Controls {
  constructor(onAction) {
    this.onAction = onAction || (() => {});
    this.keys = new Set();
    this.state = { throttle: 0, brake: 0, steer: 0 };
    this.touch = { throttle: 0, brake: 0, steer: 0 };
    this.gamepadName = null;
    this._smooth = { steer: 0, throttle: 0, brake: 0 };
    this._padPrev = [];
    this.enabled = true;
    this._bind();
  }

  _bind() {
    const typing = (e) => /^(INPUT|SELECT|TEXTAREA)$/.test((e.target && e.target.tagName) || '');
    addEventListener('keydown', (e) => {
      if (typing(e) || e.ctrlKey || e.metaKey || e.altKey) return;
      const k = e.code;
      if (!this.keys.has(k)) {
        const a = ACTIONS[k];
        if (a) { this.onAction(a, e); if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(k)) e.preventDefault(); }
      }
      this.keys.add(k);
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(k)) e.preventDefault();
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());
    addEventListener('gamepadconnected', (e) => { this.gamepadName = e.gamepad.id; this.onAction('gamepad', e.gamepad.id); });
    addEventListener('gamepaddisconnected', () => { this.gamepadName = null; this.onAction('gamepad', null); });
  }

  /** liga botões de toque (elementos com data-touch="throttle|brake|left|right") */
  bindTouch(root) {
    const set = (name, v) => {
      if (name === 'throttle') this.touch.throttle = v;
      else if (name === 'brake') this.touch.brake = v;
      else if (name === 'left') this.touch.steer = v ? 1 : (this.touch.steer > 0 ? 0 : this.touch.steer);
      else if (name === 'right') this.touch.steer = v ? -1 : (this.touch.steer < 0 ? 0 : this.touch.steer);
    };
    root.querySelectorAll('[data-touch]').forEach((el) => {
      const n = el.dataset.touch;
      const down = (e) => { e.preventDefault(); el.classList.add('on'); set(n, 1); };
      const up = (e) => { e.preventDefault(); el.classList.remove('on'); set(n, 0); };
      el.addEventListener('pointerdown', down);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
      el.addEventListener('pointerleave', up);
    });
  }

  /** deve ser chamado uma vez por quadro de renderização */
  poll(dt) {
    let thr = 0, brk = 0, str = 0;
    const K = this.keys;
    if (K.has('KeyW') || K.has('ArrowUp')) thr = 1;
    if (K.has('KeyS') || K.has('ArrowDown')) brk = 1;
    if (K.has('Space')) brk = 1;
    if (K.has('KeyA') || K.has('ArrowLeft')) str += 1;
    if (K.has('KeyD') || K.has('ArrowRight')) str -= 1;
    thr = Math.max(thr, this.touch.throttle); brk = Math.max(brk, this.touch.brake); if (this.touch.steer) str = this.touch.steer;

    // Gamepad (padrão): gatilhos RT/LT, analógico esquerdo, botões A (reiniciar), B (câmera), Start (pausa)
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (const p of pads) {
      if (!p || !p.connected) continue;
      const ax = Math.abs(p.axes[0]) > DEAD ? p.axes[0] : 0;
      if (ax) str = -ax;
      const rt = p.buttons[7] ? p.buttons[7].value : 0, lt = p.buttons[6] ? p.buttons[6].value : 0;
      if (rt > 0.05) thr = Math.max(thr, rt);
      if (lt > 0.05) brk = Math.max(brk, lt);
      const prev = this._padPrev[p.index] || [];
      const edge = (i) => p.buttons[i] && p.buttons[i].pressed && !prev[i];
      if (edge(9)) this.onAction('pause');
      if (edge(0)) this.onAction('restart');
      if (edge(1)) this.onAction('nextCamera');
      if (edge(3)) this.onAction('reset200');
      this._padPrev[p.index] = p.buttons.map((b) => b.pressed);
      this.gamepadName = p.id;
    }

    // suavização (direção e pedais não são binários)
    const s = this._smooth, ks = 1 - Math.exp(-dt * 7), kp = 1 - Math.exp(-dt * 9);
    s.steer += (str - s.steer) * ks;
    s.throttle += (thr - s.throttle) * kp;
    s.brake += (brk - s.brake) * kp;
    this.state.throttle = this.enabled ? s.throttle : 0;
    this.state.brake = this.enabled ? s.brake : 0;
    this.state.steer = this.enabled ? s.steer : 0;
    return this.state;
  }
}

const ACTIONS = {
  KeyP: 'pause', Escape: 'pause', KeyR: 'restart', KeyT: 'reset200', KeyB: 'restoreBody', KeyV: 'nextCamera', KeyM: 'slowmo',
  KeyH: 'toggleHud', KeyF: 'toggleTelemetry', Enter: 'start', KeyC: 'nextCamera',
  Digit1: 'cam0', Digit2: 'cam1', Digit3: 'cam2', Digit4: 'cam3', Digit5: 'cam4', Digit6: 'cam5',
  Period: 'speedUp', Comma: 'speedDown'
};
