// renderer.js - motor gráfico WebGPU: pipelines, sombras, MSAA, veículos deformáveis, cenário, partículas e telemetria de GPU.
//
// Todos os elementos principais (veículos, pista, parede, obstáculos, garagem) são malhas 3D renderizadas pelo WebGPU
// (shaders WGSL em /shaders). Nada é desenhado como imagem 2D no lugar da geometria.
import { mat4, vec3 } from './math.js';
import { buildVehicle, isGlass } from './vehicle.js';
import { GPUDeformer } from './deformation.js';
import { buildTrackGround, buildTrackProps, buildMountains, buildObstacles, buildGarage, makeAtlasCanvas } from './scene.js';

export class RendererError extends Error {
  constructor(code, message, detail) { super(message); this.code = code; this.detail = detail; }
}

const DEPTH = 'depth32float';
const SAMPLES = 4;
const MAX_PARTICLES = 4096;
const FRAME_FLOATS = 100;

const ENVS = {
  day: { sun: [0.5, 0.72, -0.42], sunI: 1.0, sunColor: [3.4, 3.1, 2.7], skyTop: [0.20, 0.40, 0.85], skyHor: [0.62, 0.76, 0.92], ground: [0.10, 0.10, 0.085], night: 0, fog: 0.00055 },
  dusk: { sun: [0.62, 0.11, -0.36], sunI: 1.0, sunColor: [3.2, 1.45, 0.62], skyTop: [0.07, 0.12, 0.30], skyHor: [0.95, 0.45, 0.22], ground: [0.05, 0.04, 0.04], night: 0.45, fog: 0.0008 },
  night: { sun: [0.3, 0.5, -0.6], sunI: 0.2, sunColor: [0.30, 0.40, 0.70], skyTop: [0.004, 0.008, 0.03], skyHor: [0.02, 0.03, 0.075], ground: [0.01, 0.012, 0.02], night: 1, fog: 0.0011 },
  garage: { sun: [0.22, 0.92, -0.32], sunI: 0.5, sunColor: [2.6, 2.7, 2.9], skyTop: [0.02, 0.02, 0.03], skyHor: [0.02, 0.02, 0.03], ground: [0.02, 0.02, 0.025], night: 0, fog: 0.004 }
};

async function fetchText(url) {
  const r = await fetch(url);
  if (!r.ok) throw new RendererError('shader-fetch', `Não foi possível carregar o shader ${url} (HTTP ${r.status}).`);
  return r.text();
}

export class Renderer {
  static async create(canvas, opts = {}) {
    const r = new Renderer(canvas, opts);
    await r.init();
    return r;
  }

  constructor(canvas, opts) {
    this.canvas = canvas;
    this.opts = opts;
    this.quality = { scale: 1, shadowSize: 2048, particles: 1 };
    this.stats = { cpuMs: 0, gpuMs: null, frames: 0, dispatches: 0, drawCalls: 0 };
    this.onError = null;
    this.onDeviceLost = null;
    this.vehicles = [];
    this.dimsList = null;
    this.particleHead = 0;
    this.particleCount = 0;
    this.lost = false;
    this._gpuBusy = false;
  }

  // -------------------------------------------------------------------------------------------
  async init() {
    if (!navigator.gpu) throw new RendererError('no-webgpu', 'Este navegador não expõe a API WebGPU (navigator.gpu).');
    const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
    if (!adapter) throw new RendererError('no-adapter', 'Nenhum adaptador gráfico compatível com WebGPU foi encontrado.');
    const features = [];
    if (adapter.features.has('timestamp-query')) features.push('timestamp-query');
    this.device = await adapter.requestDevice({ requiredFeatures: features, label: 'ImpactLab3D' });
    this.adapterInfo = adapter.info || {};
    this.hasTimestamps = features.includes('timestamp-query');
    const dev = this.device;
    this.lost = false;
    dev.lost.then((info) => { this.lost = true; if (this.onDeviceLost) this.onDeviceLost(info); });
    dev.addEventListener('uncapturederror', (e) => { if (this.onError) this.onError(e.error && e.error.message ? e.error.message : String(e)); });

    this.format = navigator.gpu.getPreferredCanvasFormat();
    this.offscreen = !!this.opts.offscreen;   // modo de teste/captura: renderiza em textura em vez do canvas
    if (!this.offscreen) {
      this.ctx = this.canvas.getContext('webgpu');
      if (!this.ctx) throw new RendererError('no-context', 'Não foi possível criar o contexto WebGPU no canvas.');
      this.ctx.configure({ device: dev, format: this.format, alphaMode: 'opaque' });
    }

    await this._createShaders();
    this._createLayouts();
    this._createPipelines();
    this._createStaticResources();
    this._createTargets();
    if (this.dimsList) this.loadVehicles(this.dimsList);
  }

  async _module(label, code) {
    const m = this.device.createShaderModule({ label, code });
    const info = await m.getCompilationInfo();
    const errs = info.messages.filter((x) => x.type === 'error');
    if (errs.length) {
      const text = errs.map((e) => `${label}:${e.lineNum}:${e.linePos} ${e.message}`).join('\n');
      throw new RendererError('shader-compile', `Erro ao compilar o shader ${label}:\n${text}`, errs);
    }
    return m;
  }

  async _createShaders() {
    const base = new URL('../shaders/', import.meta.url);
    const [lighting, vehicle, scene, deform, particles] = await Promise.all(['lighting', 'vehicle', 'scene', 'deformation', 'particles'].map((n) => fetchText(new URL(n + '.wgsl', base))));
    const [pCompute, pRender] = particles.split('//#RENDER');
    this.modules = {
      vehicle: await this._module('vehicle.wgsl', lighting + '\n' + vehicle),
      scene: await this._module('scene.wgsl', lighting + '\n' + scene),
      deform: await this._module('deformation.wgsl', deform),
      pcompute: await this._module('particles.wgsl (compute)', pCompute),
      prender: await this._module('particles.wgsl (render)', lighting + '\n' + pCompute.split('@group')[0] + pRender)
    };
  }

  _createLayouts() {
    const d = this.device, V = GPUShaderStage.VERTEX, F = GPUShaderStage.FRAGMENT;
    this.bgl0 = d.createBindGroupLayout({
      label: 'bgl0-main',
      entries: [
        { binding: 0, visibility: V | F, buffer: { type: 'uniform' } },
        { binding: 1, visibility: F, texture: { sampleType: 'depth' } },
        { binding: 2, visibility: F, sampler: { type: 'comparison' } },
        { binding: 3, visibility: F, texture: { sampleType: 'float' } },
        { binding: 4, visibility: F, sampler: { type: 'filtering' } }
      ]
    });
    this.bgl0Frame = d.createBindGroupLayout({ label: 'bgl0-frame', entries: [{ binding: 0, visibility: V, buffer: { type: 'uniform' } }] });
    this.bgl1Veh = d.createBindGroupLayout({
      label: 'bgl1-veh',
      entries: [{ binding: 0, visibility: V | F, buffer: { type: 'uniform' } }, { binding: 1, visibility: V, buffer: { type: 'uniform' } }]
    });
    this.bgl1Obj = d.createBindGroupLayout({ label: 'bgl1-obj', entries: [{ binding: 0, visibility: V | F, buffer: { type: 'uniform' } }] });
    this.bgl1Part = d.createBindGroupLayout({ label: 'bgl1-part', entries: [{ binding: 0, visibility: V, buffer: { type: 'read-only-storage' } }] });
  }

  _createPipelines() {
    const d = this.device, fmt = this.format;
    const L = (...b) => d.createPipelineLayout({ bindGroupLayouts: b });
    const depth = (write = true, cmp = 'less') => ({ format: DEPTH, depthWriteEnabled: write, depthCompare: cmp });
    const ms = { count: SAMPLES };
    const sceneLayout = { arrayStride: 36, attributes: [{ shaderLocation: 0, offset: 0, format: 'float32x3' }, { shaderLocation: 1, offset: 12, format: 'float32x3' }, { shaderLocation: 2, offset: 24, format: 'float32x2' }, { shaderLocation: 3, offset: 32, format: 'float32' }] };
    const v4 = (loc) => ({ arrayStride: 16, attributes: [{ shaderLocation: loc, offset: 0, format: 'float32x4' }] });
    const blend = { color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' }, alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' } };
    const premult = { color: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' }, alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' } };
    const mod = this.modules;
    this.pipes = {
      sky: d.createRenderPipeline({ label: 'sky', layout: L(this.bgl0), vertex: { module: mod.scene, entryPoint: 'vs_sky' }, fragment: { module: mod.scene, entryPoint: 'fs_sky', targets: [{ format: fmt }] }, depthStencil: depth(false, 'always'), multisample: ms, primitive: { cullMode: 'none' } }),
      scene: d.createRenderPipeline({ label: 'scene', layout: L(this.bgl0, this.bgl1Obj), vertex: { module: mod.scene, entryPoint: 'vs_scene', buffers: [sceneLayout] }, fragment: { module: mod.scene, entryPoint: 'fs_scene', targets: [{ format: fmt }] }, depthStencil: depth(), multisample: ms, primitive: { cullMode: 'none' } }),
      body: d.createRenderPipeline({ label: 'body', layout: L(this.bgl0, this.bgl1Veh), vertex: { module: mod.vehicle, entryPoint: 'vs_body', buffers: [v4(0), v4(1), v4(2)] }, fragment: { module: mod.vehicle, entryPoint: 'fs_body', targets: [{ format: fmt }] }, depthStencil: depth(), multisample: ms, primitive: { cullMode: 'none' } }),
      glass: d.createRenderPipeline({ label: 'glass', layout: L(this.bgl0, this.bgl1Veh), vertex: { module: mod.vehicle, entryPoint: 'vs_body', buffers: [v4(0), v4(1), v4(2)] }, fragment: { module: mod.vehicle, entryPoint: 'fs_glass', targets: [{ format: fmt, blend }] }, depthStencil: depth(false), multisample: ms, primitive: { cullMode: 'none' } }),
      wheel: d.createRenderPipeline({ label: 'wheel', layout: L(this.bgl0, this.bgl1Veh), vertex: { module: mod.vehicle, entryPoint: 'vs_wheel', buffers: [v4(0), v4(1)] }, fragment: { module: mod.vehicle, entryPoint: 'fs_wheel', targets: [{ format: fmt }] }, depthStencil: depth(), multisample: ms, primitive: { cullMode: 'none' } }),
      particles: d.createRenderPipeline({ label: 'particles', layout: L(this.bgl0, this.bgl1Part), vertex: { module: mod.prender, entryPoint: 'vs_particle' }, fragment: { module: mod.prender, entryPoint: 'fs_particle', targets: [{ format: fmt, blend: premult }] }, depthStencil: depth(false), multisample: ms, primitive: { cullMode: 'none' } }),
      shadowScene: d.createRenderPipeline({ label: 'shadow-scene', layout: L(this.bgl0Frame, this.bgl1Obj), vertex: { module: mod.scene, entryPoint: 'vs_shadow_scene', buffers: [sceneLayout] }, depthStencil: { ...depth(), depthBias: 2, depthBiasSlopeScale: 2.5 }, primitive: { cullMode: 'none' } }),
      shadowBody: d.createRenderPipeline({ label: 'shadow-body', layout: L(this.bgl0Frame, this.bgl1Veh), vertex: { module: mod.vehicle, entryPoint: 'vs_shadow_body', buffers: [v4(0)] }, depthStencil: { ...depth(), depthBias: 2, depthBiasSlopeScale: 2.5 }, primitive: { cullMode: 'none' } }),
      shadowWheel: d.createRenderPipeline({ label: 'shadow-wheel', layout: L(this.bgl0Frame, this.bgl1Veh), vertex: { module: mod.vehicle, entryPoint: 'vs_shadow_wheel', buffers: [v4(0)] }, depthStencil: { ...depth(), depthBias: 2, depthBiasSlopeScale: 2.5 }, primitive: { cullMode: 'none' } }),
      displace: d.createComputePipeline({ label: 'displace', layout: 'auto', compute: { module: mod.deform, entryPoint: 'displace' } }),
      normals: d.createComputePipeline({ label: 'normals', layout: 'auto', compute: { module: mod.deform, entryPoint: 'normals' } }),
      pupdate: d.createComputePipeline({ label: 'particles-update', layout: 'auto', compute: { module: mod.pcompute, entryPoint: 'update' } })
    };
  }

  _createStaticResources() {
    const d = this.device;
    // textura de sombras e amostradores
    this._createShadowMap(this.quality.shadowSize);
    this.shadowSampler = d.createSampler({ compare: 'less', magFilter: 'linear', minFilter: 'linear' });
    this.linearSampler = d.createSampler({ magFilter: 'linear', minFilter: 'linear', mipmapFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge' });
    // atlas de textos
    const atlas = makeAtlasCanvas();
    this.atlasTex = d.createTexture({ size: [atlas.width, atlas.height], format: 'rgba8unorm', usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT, label: 'atlas' });
    d.queue.copyExternalImageToTexture({ source: atlas }, { texture: this.atlasTex }, [atlas.width, atlas.height]);
    // uniform de quadro (principal) e bind groups
    this.frameBuf = d.createBuffer({ size: FRAME_FLOATS * 4, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST, label: 'frame' });
    this.frameData = new Float32Array(FRAME_FLOATS);
    this._makeFrameBindGroups();
    // cenário
    const mkMesh = (g, label) => {
      const vb = d.createBuffer({ size: g.vertices.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST, label: label + '-vb' });
      const ib = d.createBuffer({ size: g.indices.byteLength, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST, label: label + '-ib' });
      d.queue.writeBuffer(vb, 0, g.vertices); d.queue.writeBuffer(ib, 0, g.indices);
      const ubuf = d.createBuffer({ size: 80, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST, label: label + '-obj' });
      const bg = d.createBindGroup({ layout: this.bgl1Obj, entries: [{ binding: 0, resource: { buffer: ubuf } }] });
      const data = new Float32Array(20); data.set(mat4.identity(), 0); data.set([1, 1, 1, 1], 16);
      d.queue.writeBuffer(ubuf, 0, data);
      return { vb, ib, count: g.indices.length, ubuf, bg, data, label };
    };
    this.meshes = {
      ground: mkMesh(buildTrackGround(), 'ground'), props: mkMesh(buildTrackProps(), 'props'), mountains: mkMesh(buildMountains(), 'mountains'),
      garage: mkMesh(buildGarage(), 'garage')
    };
    const ob = buildObstacles();
    this.obstacleMeshes = { wall: mkMesh(ob.wall, 'wall'), barrier: mkMesh(ob.barrier, 'barrier'), pole: mkMesh(ob.pole, 'pole'), block: mkMesh(ob.block, 'block'), wallBack: mkMesh(ob.wall, 'wall-back') };
    // partículas
    this.particleBuf = d.createBuffer({ size: MAX_PARTICLES * 64, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST, label: 'particles' });
    this.particleSimBuf = d.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    this.particleBgCompute = d.createBindGroup({ layout: this.pipes.pupdate.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: this.particleBuf } }, { binding: 1, resource: { buffer: this.particleSimBuf } }] });
    this.particleBgRender = d.createBindGroup({ layout: this.bgl1Part, entries: [{ binding: 0, resource: { buffer: this.particleBuf } }] });
    this.clearParticles();
    // temporização de GPU
    if (this.hasTimestamps) {
      this.qs = d.createQuerySet({ type: 'timestamp', count: 2 });
      this.qsResolve = d.createBuffer({ size: 16, usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC });
      this.qsRead = d.createBuffer({ size: 16, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
    }
  }

  _createShadowMap(size) {
    if (this.shadowTex) this.shadowTex.destroy();
    this.shadowSize = size;
    this.shadowTex = this.device.createTexture({ size: [size, size], format: DEPTH, usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING, label: 'shadow' });
    this.shadowView = this.shadowTex.createView();
  }

  _makeFrameBindGroups() {
    const d = this.device;
    this.bg0 = d.createBindGroup({
      layout: this.bgl0,
      entries: [
        { binding: 0, resource: { buffer: this.frameBuf } }, { binding: 1, resource: this.shadowView }, { binding: 2, resource: this.shadowSampler },
        { binding: 3, resource: this.atlasTex.createView() }, { binding: 4, resource: this.linearSampler }
      ]
    });
    this.bg0Frame = d.createBindGroup({ layout: this.bgl0Frame, entries: [{ binding: 0, resource: { buffer: this.frameBuf } }] });
  }

  _createTargets() {
    const d = this.device;
    const dpr = Math.min(window.devicePixelRatio || 1, 2) * this.quality.scale;
    let w = Math.max(2, Math.floor(this.canvas.clientWidth * dpr)), h = Math.max(2, Math.floor(this.canvas.clientHeight * dpr));
    // orçamento de pixels (celulares têm telas enormes; MSAA 4x multiplica o custo): reduz a resolução interna se passar do limite
    const budget = this.quality.maxPixels || Infinity;
    if (w * h > budget) { const k = Math.sqrt(budget / (w * h)); w = Math.max(2, Math.floor(w * k)); h = Math.max(2, Math.floor(h * k)); }
    if (this.canvas.width === w && this.canvas.height === h && this.msaaTex) return;
    this.canvas.width = w; this.canvas.height = h;
    if (this.msaaTex) { this.msaaTex.destroy(); this.depthTex.destroy(); }
    this.msaaTex = d.createTexture({ size: [w, h], sampleCount: SAMPLES, format: this.format, usage: GPUTextureUsage.RENDER_ATTACHMENT, label: 'msaa' });
    this.depthTex = d.createTexture({ size: [w, h], sampleCount: SAMPLES, format: DEPTH, usage: GPUTextureUsage.RENDER_ATTACHMENT, label: 'depth' });
    this.msaaView = this.msaaTex.createView(); this.depthView = this.depthTex.createView();
    if (this.offscreen) {
      if (this.offTex) this.offTex.destroy();
      this.offTex = d.createTexture({ size: [w, h], format: this.format, usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC, label: 'offscreen' });
    }
  }

  resize() { if (!this.lost) this._createTargets(); }

  setQuality(q) {
    Object.assign(this.quality, q);
    if (q.shadowSize && q.shadowSize !== this.shadowSize) { this._createShadowMap(q.shadowSize); this._makeFrameBindGroups(); }
    if (this.msaaTex) { this.msaaTex.destroy(); this.depthTex.destroy(); this.msaaTex = null; }
    this._createTargets();
  }

  // -------------------------------------------------------------------------------------------
  // veículos
  // -------------------------------------------------------------------------------------------
  /** @param {object[]} dimsList dimensões físicas de cada veículo (vindas do módulo C) */
  loadVehicles(dimsList) {
    this.dimsList = dimsList;
    for (const v of this.vehicles) if (v) { v.deformer.destroy(); v.wheelPosBuf.destroy(); v.wheelNrmBuf.destroy(); v.wheelIdx.destroy(); }
    const d = this.device;
    this.vehicles = dimsList.map((dims, i) => {
      const geom = buildVehicle(i, dims);
      const deformer = new GPUDeformer(d, { displace: this.pipes.displace, normals: this.pipes.normals }, geom);
      deformer.reset();
      const w = geom.wheels;
      const wheelPosBuf = d.createBuffer({ size: w.pos.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
      const wheelNrmBuf = d.createBuffer({ size: w.nrm.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
      const wheelIdx = d.createBuffer({ size: w.indices.byteLength, usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST });
      d.queue.writeBuffer(wheelPosBuf, 0, w.pos); d.queue.writeBuffer(wheelNrmBuf, 0, w.nrm); d.queue.writeBuffer(wheelIdx, 0, w.indices);
      const ubuf = d.createBuffer({ size: 208, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST, label: 'veh-uniform' });
      const wbuf = d.createBuffer({ size: 256, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST, label: 'wheel-mats' });
      const bg = d.createBindGroup({ layout: this.bgl1Veh, entries: [{ binding: 0, resource: { buffer: ubuf } }, { binding: 1, resource: { buffer: wbuf } }] });
      const opaque = geom.ranges.filter((r) => !isGlass(r.mat));
      const glass = geom.ranges.filter((r) => isGlass(r.mat));
      return { geom, deformer, wheelPosBuf, wheelNrmBuf, wheelIdx, ubuf, wbuf, bg, opaque, glass, udata: new Float32Array(52), wdata: new Float32Array(64) };
    });
    // primeira passada de deformação (campo zerado => malha de repouso + normais)
    const enc = d.createCommandEncoder();
    for (const v of this.vehicles) v.deformer.encode(enc);
    d.queue.submit([enc.finish()]);
  }

  vehicle(i) { return this.vehicles[i]; }

  // -------------------------------------------------------------------------------------------
  // partículas
  // -------------------------------------------------------------------------------------------
  clearParticles() {
    this.device.queue.writeBuffer(this.particleBuf, 0, new Float32Array(MAX_PARTICLES * 16));
    this.particleHead = 0;
  }
  /** @param {Float32Array} data N * 16 floats: pos3 life | vel3 size | col4 | kind4 */
  spawnParticles(data) {
    const n = Math.min(Math.floor(data.length / 16), Math.floor(MAX_PARTICLES * this.quality.particles));
    if (n <= 0) return;
    const cap = Math.max(64, Math.floor(MAX_PARTICLES * this.quality.particles));
    let i = 0;
    while (i < n) {
      const head = this.particleHead % cap;
      const chunk = Math.min(n - i, cap - head);
      this.device.queue.writeBuffer(this.particleBuf, head * 64, data.subarray(i * 16, (i + chunk) * 16));
      this.particleHead = (head + chunk) % cap; i += chunk;
    }
  }

  // -------------------------------------------------------------------------------------------
  // uniforms
  // -------------------------------------------------------------------------------------------
  _packFrame(out, f, aspect, view, proj, shadowFocus) {
    const env = ENVS[f.env] || ENVS.day;
    const viewProj = mat4.multiply(proj, view), inv = mat4.invert(viewProj);
    const sun = vec3.norm(env.sun);
    const R = f.env === 'garage' ? 6.5 : 14;
    const eyeL = vec3.add(shadowFocus, vec3.scale(sun, 80));
    const lv = mat4.lookAt(eyeL, shadowFocus, Math.abs(sun[1]) > 0.98 ? [0, 0, 1] : [0, 1, 0]);
    const lightVP = mat4.multiply(mat4.ortho(-R, R, -R, R, 0.5, 200), lv);
    out.set(viewProj, 0); out.set(lightVP, 16); out.set(inv, 32);
    out.set([f.cam.eye[0], f.cam.eye[1], f.cam.eye[2], 1], 48);
    out.set([sun[0], sun[1], sun[2], env.sunI], 52);
    out.set([env.sunColor[0], env.sunColor[1], env.sunColor[2], 1], 56);
    out.set([env.skyTop[0], env.skyTop[1], env.skyTop[2], 1], 60);
    out.set([env.skyHor[0], env.skyHor[1], env.skyHor[2], 1], 64);
    out.set([env.ground[0], env.ground[1], env.ground[2], 1], 68);
    out.set([f.time || 0, env.night, f.env === 'garage' ? 1 : 0, env.fog], 72);
    out.set([1 / this.shadowSize, f.speed || 0, f.brake || 0, f.flash || 0], 76);
    out.set([view[0], view[4], view[8], 0], 80);
    out.set([view[1], view[5], view[9], 0], 84);
    const h = f.head || { pos: [0, 0, 0], on: 0, dir: [0, 0, 1], side: [1, 0, 0] };
    out.set([h.pos[0], h.pos[1], h.pos[2], h.on], 88);
    out.set([h.dir[0], h.dir[1], h.dir[2], 0], 92);
    out.set([h.side[0], h.side[1], h.side[2], 0], 96);
  }

  _vehicleModel(p, hcg) {
    let m = mat4.translation(p.x, p.y || 0, p.z);
    m = mat4.multiply(m, mat4.rotationY(p.yaw));
    m = mat4.multiply(m, mat4.translation(0, hcg, 0));
    m = mat4.multiply(m, mat4.rotationX(-p.pitch));
    m = mat4.multiply(m, mat4.rotationZ(p.roll));
    return mat4.multiply(m, mat4.translation(0, -hcg, 0));
  }

  _updateVehicleUniforms(v, f) {
    const g = v.geom, vh = f.vehicle, p = vh.pose, d = g.dims;
    const model = this._vehicleModel(p, d.hcg);
    const u = v.udata;
    u.set(model, 0);
    u.set([vh.paint[0], vh.paint[1], vh.paint[2], vh.paint[3]], 16);
    u.set([vh.broken || 0, vh.brake || 0, vh.headlights ? 1 : 0, vh.speedKmh || 0], 20);
    for (let w = 0; w < 4; w++) u.set([g.wheelPos[w][0], g.wheelPos[w][1], g.wheelPos[w][2], g.archR], 24 + 4 * w);
    u.set(g.doorLines, 40);
    u.set([g.beltY, g.sillY, g.clusterCenter[0], g.clusterCenter[1]], 44);
    u.set([g.clusterCenter[2], g.hoodTopY, d.W / 2, f.time || 0], 48);
    this.device.queue.writeBuffer(v.ubuf, 0, u);
    // rodas: sobre o referencial de guinada (sem arfagem/rolagem) => a carroceria "balança" sobre a suspensão
    const base = mat4.multiply(mat4.translation(p.x, p.y || 0, p.z), mat4.rotationY(p.yaw));
    const wh = vh.wheels || { steer: 0, spin: 0, offsets: [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]], toe: [0, 0, 0, 0] };
    for (let w = 0; w < 4; w++) {
      const wp = g.wheelPos[w], off = wh.offsets[w] || [0, 0, 0];
      let m = mat4.multiply(base, mat4.translation(wp[0] + off[0], wp[1] + off[1], wp[2] + off[2]));
      const left = wp[0] > 0;
      const steer = (w < 2 ? wh.steer : 0) + (wh.toe ? wh.toe[w] : 0);
      m = mat4.multiply(m, mat4.rotationY(steer));
      if (!left) m = mat4.multiply(m, mat4.rotationY(Math.PI));
      m = mat4.multiply(m, mat4.rotationX(left ? wh.spin : -wh.spin));
      v.wdata.set(m, 16 * w);
    }
    this.device.queue.writeBuffer(v.wbuf, 0, v.wdata);
    return model;
  }

  // -------------------------------------------------------------------------------------------
  // desenho
  // -------------------------------------------------------------------------------------------
  _drawMesh(pass, mesh, model, tint) {
    if (model) {
      mesh.data.set(model, 0);
      mesh.data.set(tint || [1, 1, 1, 1], 16);
      this.device.queue.writeBuffer(mesh.ubuf, 0, mesh.data);
    }
    pass.setBindGroup(1, mesh.bg);
    pass.setVertexBuffer(0, mesh.vb);
    pass.setIndexBuffer(mesh.ib, 'uint32');
    pass.drawIndexed(mesh.count);
    this.stats.drawCalls++;
  }

  _obstacleItems(f) {
    const o = f.obstacle || { type: 0, travel: 0 };
    const I = mat4.identity();
    const M = this.obstacleMeshes;
    switch (o.type) {
      case 1: {
        const travel = Math.min(1.2, Math.max(0, o.travel || 0));
        const sc = Math.max(0.02, 1 - travel / 1.2);
        // comprime o módulo em z mantendo a face traseira encostada na parede
        const m = mat4.multiply(mat4.translation(0, 0, 1.2), mat4.multiply(mat4.scaling(1, 1, sc), mat4.translation(0, 0, -1.2)));
        return [[M.barrier, m], [M.wallBack, mat4.translation(0, 0, 1.2)]];
      }
      case 2: return [[M.pole, I]];
      case 3: return [[M.block, I]];
      default: return [[M.wall, I]];
    }
  }

  _drawVehicle(pass, v, glassPass) {
    pass.setBindGroup(1, v.bg);
    if (!glassPass) {
      pass.setPipeline(this.pipes.body);
      pass.setVertexBuffer(0, v.deformer.posBuf); pass.setVertexBuffer(1, v.deformer.nrmBuf); pass.setVertexBuffer(2, v.deformer.restBuf);
      pass.setIndexBuffer(v.deformer.indexBuf, 'uint32');
      for (const r of v.opaque) { pass.drawIndexed(r.count, 1, r.first, 0, r.mat); this.stats.drawCalls++; }
      pass.setPipeline(this.pipes.wheel);
      pass.setVertexBuffer(0, v.wheelPosBuf); pass.setVertexBuffer(1, v.wheelNrmBuf); pass.setIndexBuffer(v.wheelIdx, 'uint32');
      pass.drawIndexed(v.geom.wheels.indices.length, 4); this.stats.drawCalls++;
    } else {
      pass.setPipeline(this.pipes.glass);
      pass.setVertexBuffer(0, v.deformer.posBuf); pass.setVertexBuffer(1, v.deformer.nrmBuf); pass.setVertexBuffer(2, v.deformer.restBuf);
      pass.setIndexBuffer(v.deformer.indexBuf, 'uint32');
      for (const r of v.glass) { pass.drawIndexed(r.count, 1, r.first, 0, r.mat); this.stats.drawCalls++; }
    }
  }

  _drawShadowPass(encoder, f, v, bg0Frame) {
    const pass = encoder.beginRenderPass({ colorAttachments: [], depthStencilAttachment: { view: this.shadowView, depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'store' } });
    pass.setBindGroup(0, bg0Frame);
    if (f.mode === 'track') {
      pass.setPipeline(this.pipes.shadowScene);
      this._drawShadowMesh(pass, this.meshes.props);
      for (const [mesh] of this._obstacleItems(f)) this._drawShadowMesh(pass, mesh);
    }
    pass.setPipeline(this.pipes.shadowBody);
    pass.setBindGroup(1, v.bg);
    pass.setVertexBuffer(0, v.deformer.posBuf); pass.setIndexBuffer(v.deformer.indexBuf, 'uint32');
    for (const r of v.opaque) if (r.mat !== 15) pass.drawIndexed(r.count, 1, r.first, 0, 0);
    pass.setPipeline(this.pipes.shadowWheel);
    pass.setVertexBuffer(0, v.wheelPosBuf); pass.setIndexBuffer(v.wheelIdx, 'uint32');
    pass.drawIndexed(v.geom.wheels.indices.length, 4);
    pass.end();
  }
  _drawShadowMesh(pass, mesh) {
    pass.setBindGroup(1, mesh.bg); pass.setVertexBuffer(0, mesh.vb); pass.setIndexBuffer(mesh.ib, 'uint32'); pass.drawIndexed(mesh.count);
  }

  /**
   * Renderiza um quadro completo.
   * f = { mode:'track'|'garage', env:'day'|'dusk'|'night'|'garage', cam:{view,proj,eye}, time, dt, vehicle:{index,paint,pose,wheels,broken,brake,headlights,speedKmh},
   *       obstacle:{type,travel,wallActive}, crush:{crush,dirs,samples}, effects:boolean, flash }
   */
  renderFrame(f) {
    if (this.lost || !this.vehicles.length) return;
    const t0 = performance.now();
    this.stats.drawCalls = 0;
    const d = this.device;
    this._createTargets();
    const v = this.vehicles[f.vehicle.index];
    const aspect = this.canvas.width / this.canvas.height;
    const model = this._updateVehicleUniforms(v, f);
    // deformação: atualiza o campo; despacha apenas se mudou
    if (f.crush) v.deformer.setField(f.crush.crush, f.crush.dirs, f.crush.samples, v.geom.dims, v.geom.beltY);
    const p = f.vehicle.pose;
    const focus = f.mode === 'garage' ? [0, 0.7, 0] : [p.x, 0.5, Math.min(p.z, 6)];
    f.head = f.head || this._headFor(f, v);
    this._packFrame(this.frameData, f, aspect, f.cam.view, f.cam.proj, focus);
    d.queue.writeBuffer(this.frameBuf, 0, this.frameData);

    const enc = d.createCommandEncoder({ label: 'frame' });
    if (v.deformer.encode(enc)) this.stats.dispatches++;
    // partículas (GPU)
    if (f.effects !== false) {
      const ob = f.obstacle || { type: 0 };
      const sim = new Float32Array([Math.min(f.dt || 0, 0.05), f.time || 0, ob.wallActive === false ? 0 : 1, MAX_PARTICLES, 0, ob.type === 2 ? -0.3 : ob.type === 3 ? -1 : -12, ob.type === 2 ? 0.3 : ob.type === 3 ? 1 : 12, 0]);
      d.queue.writeBuffer(this.particleSimBuf, 0, sim);
      const cp = enc.beginComputePass({ label: 'partículas' });
      cp.setPipeline(this.pipes.pupdate); cp.setBindGroup(0, this.particleBgCompute); cp.dispatchWorkgroups(MAX_PARTICLES / 64);
      cp.end();
    }
    this._drawShadowPass(enc, f, v, this.bg0Frame);

    const view = (this.offscreen ? this.offTex : this.ctx.getCurrentTexture()).createView();
    const rp = {
      colorAttachments: [{ view: this.msaaView, resolveTarget: view, clearValue: { r: 0.01, g: 0.012, b: 0.016, a: 1 }, loadOp: 'clear', storeOp: 'discard' }],
      depthStencilAttachment: { view: this.depthView, depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'discard' }
    };
    if (this.hasTimestamps) rp.timestampWrites = { querySet: this.qs, beginningOfPassWriteIndex: 0, endOfPassWriteIndex: 1 };
    const pass = enc.beginRenderPass(rp);
    this._drawWorld(pass, f, v, this.bg0);
    pass.end();
    if (this.hasTimestamps && !this._gpuBusy) {
      enc.resolveQuerySet(this.qs, 0, 2, this.qsResolve, 0);
      enc.copyBufferToBuffer(this.qsResolve, 0, this.qsRead, 0, 16);
    }
    d.queue.submit([enc.finish()]);
    if (this.hasTimestamps && !this._gpuBusy) {
      this._gpuBusy = true;
      this.qsRead.mapAsync(GPUMapMode.READ).then(() => {
        const t = new BigUint64Array(this.qsRead.getMappedRange().slice(0));
        this.qsRead.unmap();
        this.stats.gpuMs = Number(t[1] - t[0]) / 1e6;
        this._gpuBusy = false;
      }).catch(() => { this._gpuBusy = false; });
    }
    this.stats.cpuMs = performance.now() - t0;
    this.stats.frames++;
  }

  _headFor(f, v) {
    const p = f.vehicle.pose, d = v.geom.dims;
    const fx = Math.sin(p.yaw), fz = Math.cos(p.yaw);
    return {
      pos: [p.x + fx * (d.zf - 0.3), 0.68, p.z + fz * (d.zf - 0.3)],
      dir: [fx, -0.06, fz], side: [Math.cos(p.yaw), 0, -Math.sin(p.yaw)], on: f.vehicle.headlights ? 1 : 0
    };
  }

  _drawWorld(pass, f, v, bg0) {
    pass.setBindGroup(0, bg0);
    if (f.mode === 'track') {
      pass.setPipeline(this.pipes.sky); pass.draw(3);
      pass.setPipeline(this.pipes.scene);
      this._drawMesh(pass, this.meshes.mountains, mat4.identity());
      this._drawMesh(pass, this.meshes.ground, mat4.identity());
      this._drawMesh(pass, this.meshes.props, mat4.identity());
      for (const [mesh, m] of this._obstacleItems(f)) this._drawMesh(pass, mesh, m);
    } else {
      pass.setPipeline(this.pipes.scene);
      this._drawMesh(pass, this.meshes.garage, mat4.identity());
    }
    this._drawVehicle(pass, v, false);
    this._drawVehicle(pass, v, true);
    if (f.effects !== false) {
      pass.setPipeline(this.pipes.particles);
      pass.setBindGroup(0, bg0); pass.setBindGroup(1, this.particleBgRender);
      pass.draw(6, MAX_PARTICLES);
    }
  }

  // -------------------------------------------------------------------------------------------
  // miniaturas (renderização real em textura + leitura de pixels)
  // -------------------------------------------------------------------------------------------
  async renderThumbnail(vehIndex, paint, width = 360, height = 190) {
    const d = this.device, v = this.vehicles[vehIndex];
    const fmt = this.format;
    const msaa = d.createTexture({ size: [width, height], sampleCount: SAMPLES, format: fmt, usage: GPUTextureUsage.RENDER_ATTACHMENT });
    const color = d.createTexture({ size: [width, height], format: fmt, usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC });
    const depth = d.createTexture({ size: [width, height], sampleCount: SAMPLES, format: DEPTH, usage: GPUTextureUsage.RENDER_ATTACHMENT });
    const dims = v.geom.dims;
    const sc = dims.length / 4.5;
    const eye = [4.4 * sc, 1.5 + 0.1 * sc, 6.2 * sc];
    const f = {
      mode: 'garage', env: 'garage', time: 3, dt: 0,
      cam: { eye, view: mat4.lookAt(eye, [0, 0.62, 0.15], [0, 1, 0]), proj: mat4.perspective(0.52, width / height, 0.1, 80) },
      vehicle: { index: vehIndex, paint, pose: { x: 0, y: 0.18, z: 0, yaw: 0.0, pitch: 0, roll: 0 }, broken: 0, brake: 0, headlights: false, speedKmh: 0, wheels: { steer: 0, spin: 0, offsets: [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]], toe: [0, 0, 0, 0] } },
      effects: false
    };
    this._updateVehicleUniforms(v, f);
    f.head = this._headFor(f, v);
    const data = new Float32Array(FRAME_FLOATS);
    this._packFrame(data, f, width / height, f.cam.view, f.cam.proj, [0, 0.7, 0]);
    const fbuf = d.createBuffer({ size: FRAME_FLOATS * 4, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    d.queue.writeBuffer(fbuf, 0, data);
    const bg0 = d.createBindGroup({ layout: this.bgl0, entries: [{ binding: 0, resource: { buffer: fbuf } }, { binding: 1, resource: this.shadowView }, { binding: 2, resource: this.shadowSampler }, { binding: 3, resource: this.atlasTex.createView() }, { binding: 4, resource: this.linearSampler }] });
    const bg0Frame = d.createBindGroup({ layout: this.bgl0Frame, entries: [{ binding: 0, resource: { buffer: fbuf } }] });
    const enc = d.createCommandEncoder();
    v.deformer.encode(enc);
    this._drawShadowPass(enc, f, v, bg0Frame);
    const pass = enc.beginRenderPass({
      colorAttachments: [{ view: msaa.createView(), resolveTarget: color.createView(), clearValue: { r: 0.01, g: 0.012, b: 0.016, a: 1 }, loadOp: 'clear', storeOp: 'discard' }],
      depthStencilAttachment: { view: depth.createView(), depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'discard' }
    });
    this._drawWorld(pass, f, v, bg0);
    pass.end();
    d.queue.submit([enc.finish()]);
    const url = await this._readTexture(color, width, height);
    msaa.destroy(); color.destroy(); depth.destroy(); fbuf.destroy();
    return url;
  }

  /** copia uma textura (formato do canvas) para a CPU e devolve um PNG (data URL) */
  async _readTexture(tex, width, height) {
    const d = this.device;
    const bpr = Math.ceil((width * 4) / 256) * 256;
    const rb = d.createBuffer({ size: bpr * height, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
    const enc = d.createCommandEncoder();
    enc.copyTextureToBuffer({ texture: tex }, { buffer: rb, bytesPerRow: bpr }, [width, height]);
    d.queue.submit([enc.finish()]);
    await rb.mapAsync(GPUMapMode.READ);
    const src = new Uint8Array(rb.getMappedRange());
    const img = new ImageData(width, height);
    const bgra = this.format.startsWith('bgra');
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
      const s = y * bpr + x * 4, o = (y * width + x) * 4;
      img.data[o] = bgra ? src[s + 2] : src[s]; img.data[o + 1] = src[s + 1]; img.data[o + 2] = bgra ? src[s] : src[s + 2]; img.data[o + 3] = 255;
    }
    rb.unmap(); rb.destroy();
    const cv = document.createElement('canvas'); cv.width = width; cv.height = height;
    cv.getContext('2d').putImageData(img, 0, 0);
    return cv.toDataURL('image/png');
  }

  /** captura do último quadro (modo offscreen) */
  async capture() { return this._readTexture(this.offTex, this.canvas.width, this.canvas.height); }

  /** captura o quadro atual como PNG (para testes e relatórios) */
  async waitIdle() { await this.device.queue.onSubmittedWorkDone(); }
}
