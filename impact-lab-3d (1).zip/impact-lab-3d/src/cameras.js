// cameras.js - as seis câmeras do simulador: Orbital, Interna, Lateral, Fixa na Parede, Perseguição e Cinematográfica.
// Todas retornam { eye, view, proj }. A posição é suavizada (amortecimento exponencial independente da taxa de quadros).
// Convenção de mundo: parede em z=0, veículo parte de z=-200 em direção a +z; x local positivo = esquerda do veículo.

import { mat4, clamp, lerp } from './math.js';

export const CAMERAS = [
  { id: 'orbital', label: 'Orbital', key: '1' },
  { id: 'interior', label: 'Interna', key: '2' },
  { id: 'side', label: 'Lateral', key: '3' },
  { id: 'wall', label: 'Fixa na Parede', key: '4' },
  { id: 'chase', label: 'Perseguição', key: '5' },
  { id: 'cinematic', label: 'Cinematográfica', key: '6' }
];

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const damp = (cur, target, rate, dt) => lerp(cur, target, 1 - Math.exp(-rate * dt));

export class CameraRig {
  constructor() {
    this.mode = 'orbital';
    this.orbit = { yaw: 0.55, pitch: 0.28, dist: 8.5, auto: true };
    this.eye = [0, 2, -10];
    this.target = [0, 1, 0];
    this.fov = 0.85;
    this.shake = 0;
    this.shakeT = 0;
    this.cine = { shot: 0, t: 0, lastShot: -1 };
    this.garage = { yaw: 0.6, auto: true };
    this._init = false;
  }

  setMode(id) { this.mode = id; this._init = false; this.cine.t = 0; this.cine.shot = 0; }

  /** impulso de tremor de câmera (intensidade 0..1) */
  kick(a) { this.shake = Math.min(1.2, Math.max(this.shake, a)); }

  /** entrada de arrasto/roda do mouse na câmera orbital */
  drag(dx, dy) { this.orbit.yaw -= dx * 0.006; this.orbit.pitch = clamp(this.orbit.pitch + dy * 0.005, -0.1, 1.35); this.orbit.auto = false; }
  zoom(d) { this.orbit.dist = clamp(this.orbit.dist * Math.exp(d * 0.0012), 3.0, 60); }
  dragGarage(dx) { this.garage.yaw -= dx * 0.008; this.garage.auto = false; }

  /** câmera da garagem: o veículo gira na plataforma (turntable) e a câmera permanece fixa */
  garageCamera(dt, aspect, len, layout = {}) {
    if (this.garage.auto) this.garage.yaw += dt * 0.35;
    const sc = len / 4.5;
    // retrato: afasta a câmera para o carro caber na largura; painel aberto: desloca o carro para o lado livre da tela
    const far = aspect < 1.3 ? Math.min(2.4, 1.3 / aspect) : 1;
    const eye = [4.4 * sc * far, 1.5 + 0.1 * sc, 6.2 * sc * far];
    const n = Math.hypot(4.4, 6.2), sx = (layout.shiftRight || 0) * sc * far, sy = (layout.shiftDown || 0) * sc * far;
    const tgt = [(6.2 / n) * sx, 0.62 - sy, 0.15 - (4.4 / n) * sx];
    return { eye, view: mat4.lookAt(eye, tgt, [0, 1, 0]), proj: mat4.perspective(0.52, aspect, 0.1, 80), yaw: this.garage.yaw };
  }

  /**
   * @param {object} s estado: pose{x,y,z,yaw}, speed (m/s), phase, geom, dims, impactPoint, timeSinceImpact, slow (fator de tempo)
   */
  update(dt, aspect, s) {
    const { pose, dims, geom } = s;
    const sy = Math.sin(pose.yaw), cy = Math.cos(pose.yaw);
    const fwd = [sy, 0, cy], left = [cy, 0, -sy];
    const toWorld = (l) => [pose.x + left[0] * l[0] + fwd[0] * l[2], (pose.y || 0) + l[1], pose.z + left[2] * l[0] + fwd[2] * l[2]];
    const L = dims.zf + dims.zr;
    let eye, tgt, fov = 0.85, rate = 6;
    const center = toWorld([0, 0.6, (dims.zf - dims.zr) * 0.5]);

    switch (this.mode) {
      case 'interior': {
        const e = geom.eye;
        eye = toWorld([e[0], e[1], e[2]]);
        const look = toWorld([e[0] * 0.8, e[1] - 0.06, e[2] + 14]);
        tgt = look; fov = 1.15; rate = 40;
        break;
      }
      case 'side': {
        // câmera lateral paralela à trajetória, a 5,5 m do eixo, acompanhando o veículo em z
        const z = Math.min(pose.z, 8) + 0.5;
        eye = [-7.5, 1.35, z - 0.5]; tgt = [pose.x, 0.8, Math.min(pose.z + dims.zf * 0.4, 6)]; fov = 0.62; rate = 5;
        break;
      }
      case 'wall': {
        // montada ao lado do obstáculo, olhando para o veículo que se aproxima
        eye = [2.6, 1.15, -0.8]; tgt = [pose.x * 0.5, 0.8, pose.z + 4];
        // o campo de visão se abre à medida que o veículo se aproxima (mantém o carro enquadrado)
        const d = Math.hypot(pose.z, pose.x - eye[0]);
        fov = clamp(0.2 + d * 0.012, 0.45, 1.0); rate = 12;
        break;
      }
      case 'chase': {
        const back = 6.2 + clamp(s.speed * 0.02, 0, 3);
        eye = toWorld([0, 1.9 + s.speed * 0.006, -back - dims.zr]);
        tgt = toWorld([0, 0.9, dims.zf + 6]);
        // depois do impacto a câmera deixa de girar com o carro (evita enjoo)
        if (s.impacted) { eye = [pose.x + 2.0, 2.2, Math.min(pose.z, 0) - 8.5]; tgt = [pose.x, 0.8, pose.z + 1.0]; }
        fov = 0.9 + clamp(s.speed * 0.003, 0, 0.25); rate = 4.5;
        break;
      }
      case 'cinematic': {
        this.cine.t += dt;
        const c = this.cine, dist = -pose.z;
        let shot;
        if (!s.impacted) shot = dist > 70 ? 0 : dist > 25 ? 1 : 2;
        else shot = s.timeSinceImpact < 1.2 ? 3 : s.timeSinceImpact < 3.2 ? 4 : 5;
        if (shot !== c.lastShot) { c.lastShot = shot; c.t = 0; }
        const t = c.t;
        if (shot === 0) { eye = [-6, 1.5, pose.z + 14]; tgt = center; fov = 0.7; rate = 3; }                      // plano aberto ao lado da pista
        else if (shot === 1) { eye = toWorld([2.2 + t * 0.2, 0.5, dims.zf + 4.5]); tgt = toWorld([0, 0.55, dims.zf + 40]); fov = 0.8; rate = 20; } // baixo, de frente
        else if (shot === 2) { eye = [4.5, 0.9, -3.0 - t * 0.0]; tgt = [pose.x * 0.4, 0.8, pose.z + 6]; fov = clamp(0.1 + Math.abs(pose.z) * 0.012, 0.4, 0.9); rate = 14; } // teleobjetiva na parede
        else if (shot === 3) { eye = [4.2, 1.1, -3.4]; tgt = [pose.x, 0.8, Math.min(pose.z + 0.8, 0)]; fov = 0.55; rate = 10; }          // close do impacto
        else if (shot === 4) { const a = 0.9 + t * 0.35; eye = [pose.x + Math.sin(a) * 7, 2.0, pose.z - Math.cos(a) * 7 - 1]; tgt = center; fov = 0.65; rate = 8; } // órbita lenta
        else { eye = [pose.x - 5, 3.2, pose.z - 7]; tgt = center; fov = 0.75; rate = 4; }
        break;
      }
      default: { // orbital
        const o = this.orbit;
        if (o.auto && !s.paused && s.phase === 0) o.yaw += dt * 0.12;
        const cp = Math.cos(o.pitch), d = o.dist * Math.max(1, L / 4.5) ;
        const c = center;
        eye =[c[0] + Math.sin(o.yaw) * cp * d, Math.max(0.35, c[1] + Math.sin(o.pitch) * d), c[2] - Math.cos(o.yaw) * cp * d];
        // não deixa a câmera atravessar o obstáculo
        if (eye[2] > -0.6 && center[2] < 1) eye[2] = -0.6;
        tgt = center; fov = 0.8; rate = 30;
      }
    }

    if (!this._init) { this.eye = eye.slice(); this.target = tgt.slice(); this.fov = fov; this._init = true; }
    else {
      const r = rate;
      for (let i = 0; i < 3; i++) { this.eye[i] = damp(this.eye[i], eye[i], r, dt); this.target[i] = damp(this.target[i], tgt[i], r * 1.3, dt); }
      this.fov = damp(this.fov, fov, 5, dt);
    }

    // tremor decrescente (impacto)
    let e = this.eye.slice(), t = this.target.slice();
    this.shakeT += dt * 60;
    if (this.shake > 0.001) {
      const a = this.shake * 0.06;
      e[0] += Math.sin(this.shakeT * 1.7) * a; e[1] += Math.sin(this.shakeT * 2.3 + 1.1) * a * 0.7; e[2] += Math.sin(this.shakeT * 1.3 + 2.0) * a * 0.5;
      this.shake *= Math.exp(-4.5 * dt);
    }
    return { eye: e, view: mat4.lookAt(e, t, [0, 1, 0]), proj: mat4.perspective(this.fov, aspect, 0.08, 3000) };
  }
}
