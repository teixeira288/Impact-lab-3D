/*
 * Impact Lab 3D - sim.c
 * Veja sim.h para convenções de unidades e coordenadas.
 *
 * Compila para WebAssembly sem libc (clang --target=wasm32 -nostdlib) e também nativamente
 * (gcc/clang + libm) para os testes de consistência física (physics/test_sim.c).
 * Funções matemáticas transcendentes são importadas do JavaScript no build WASM (módulo "env").
 */
#include "sim.h"

#ifdef __wasm__
double sin(double);
double cos(double);
double tan(double);
double atan2(double, double);
double exp(double);
double tanh(double);
double pow(double, double);
#define SQRT __builtin_sqrt
#define FABS __builtin_fabs
#else
#include <math.h>
#define SQRT sqrt
#define FABS fabs
#endif

#define G_ACC      9.81
#define RHO_AIR    1.225
#define MU_TIRE    0.95
#define PI_        3.14159265358979323846
#define ELASTIC_FRAC 0.006   /* fração da penetração máxima recuperada elasticamente */
#define X0_CRUSH   0.035     /* escala da rampa inicial da curva força x esmagamento [m] */
#define LOWPASS_TAU 0.004    /* filtro de 1ª ordem (~40 Hz) aplicado à aceleração reportada [s] */

static double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
static double sgn_smooth(double v, double w) { return tanh(v / w); }
static double wrap_pi(double a) {
    while (a > PI_) a -= 2.0 * PI_;
    while (a < -PI_) a += 2.0 * PI_;
    return a;
}

/* ------------------------------------------------------------------------------------------
 * Dados dos veículos
 * ---------------------------------------------------------------------------------------- */
typedef struct {
    double wheelbase, front_over, rear_over, width, height, wf, hcg, rw, cda, track, brake_g;
    double kf_front, kf_rear, kf_side;      /* patamar de força em múltiplos de (m0*g) */
    double cap_front, cap_rear, cap_side;   /* capacidade de esmagamento [m] */
    double beta_front, beta_rear, beta_side;
    int driven;                             /* 0 = dianteira, 1 = traseira */
    double gear_ratio;
} VBase;

static const VBase VB[3] = {
    /* hatch compacto */
    { 2.52, 0.80, 0.75, 1.74, 1.50, 0.60, 0.52, 0.31, 0.64, 1.50, 1.00,
      13.0, 10.0, 22.0,   0.95, 0.60, 0.28,   7.0, 8.0, 6.0,  0, 12.0 },
    /* sedan executivo */
    { 2.80, 0.95, 1.00, 1.84, 1.46, 0.57, 0.55, 0.33, 0.62, 1.57, 1.05,
      13.0, 10.0, 22.0,   1.15, 0.75, 0.30,   7.0, 8.0, 6.0,  0, 12.5 },
    /* SUV / picape */
    { 3.18, 0.95, 1.22, 1.93, 1.85, 0.55, 0.80, 0.37, 1.25, 1.65, 0.95,
      12.0, 10.0, 20.0,   1.10, 0.90, 0.32,   7.0, 8.0, 6.0,  1, 14.0 }
};

/* cv, Nm, massa [kg] por veículo x motorização (econômica, esportiva, alta potência) */
static const double ENG[3][3][3] = {
    { {  78.0, 104.0, 1130.0 }, {  95.0, 128.0, 1160.0 }, { 110.0, 150.0, 1200.0 } },
    { { 110.0, 150.0, 1420.0 }, { 150.0, 220.0, 1470.0 }, { 200.0, 300.0, 1520.0 } },
    { { 140.0, 250.0, 2000.0 }, { 180.0, 330.0, 2080.0 }, { 220.0, 420.0, 2150.0 } }
};
static const double BRAKE_ADD[3] = { 0.0, 0.03, 0.06 };

typedef struct {
    double m0, m, a, b, zf, zr, W, H, hcg, rw, cda, crr, P, Tq, gr, brake_g, iz, cf, cr, track;
    int driven;
    double fp[4], cap[4], beta[4], kb[4];
} Veh;

typedef struct { double hw, fo, travel, mu; } Obs;
static const Obs OBSTACLES[4] = {
    { 40.0, 1e18, 0.0, 0.35 },      /* parede de concreto: rígida */
    { 40.0, 2.2e5, 1.2, 0.25 },     /* barreira de segurança: absorve energia, curso 1,2 m */
    { 0.30, 1e18, 0.0, 0.30 },      /* poste de concreto 0,6 m x 0,6 m */
    { 1.00, 1e18, 0.0, 0.35 }       /* bloco rígido de 2 m */
};

typedef struct {
    double lx, lz, nx, nz;
    int face;
    double fpi, cap, beta, kbi, fo, xstar;
} Sample;

/* ------------------------------------------------------------------------------------------
 * Estado global (memória estática: sem malloc, endereços estáveis para o JavaScript)
 * ---------------------------------------------------------------------------------------- */
static Veh V;
static Obs O;
static Sample S[SIM_NSAMP];
static double pen[SIM_NSAMP], peak[SIM_NSAMP], fn_s[SIM_NSAMP], vis_c[SIM_NSAMP];

static float out_[SIM_OUT_COUNT];
static float crush_out[SIM_NSAMP];
static float samples_out[SIM_NSAMP * SIM_SAMPLE_STRIDE];
static float dir_out[SIM_NSAMP * 2];
static double dir_x[SIM_NSAMP], dir_z[SIM_NSAMP];
static float spec_out[SIM_SPEC_COUNT];

static int cfg_veh, cfg_motor, cfg_obstacle, cfg_face, cfg_mode;
static double cfg_extra, cfg_target, cfg_angle, cfg_offset;

static double st_t, px, pz, psi, om, vx, vz;
static double pitch, pitch_r, roll, roll_r;
static double ax_f, ay_f, ax_lp, az_lp;      /* aceleração filtrada (mundo) */
static double a_long_f, a_lat_f;
static double spin, steer_act;
static double in_thr, in_brk, in_str;
static int gear_cmd;
static int phase;
static int impacted;
static double v_before, vn_before, t_impact, ke0, impulse, peak_a, e_crush, e_fric, launch_v;
static double jx, jz, peak_f, contact_t, yaw_at_imp, obs_travel_max;
static double imp_x, imp_y, imp_z, imp_lx, imp_lz;
static double events, evstr, ftotal;
static int ncontact, contact_prev, nsub_last, steps;
static double settle_t, since_impact;
static double speed_prev;
static double ctl_i;      /* integral do controle de velocidade */
static double thr_app, brk_app;
static int sled;
static unsigned broken_mask;
static double zone_dmg[Z_COUNT], zone_disp[Z_COUNT];

/* ------------------------------------------------------------------------------------------
 * Construção do veículo
 * ---------------------------------------------------------------------------------------- */
static void build_vehicle(int veh, int motor, double extra) {
    const VBase *B = &VB[veh];
    const double *E = ENG[veh][motor];
    V.m0 = E[2];
    V.m = E[2] + extra;
    V.W = B->width; V.H = B->height; V.hcg = B->hcg; V.rw = B->rw; V.cda = B->cda;
    V.crr = 0.012; V.P = E[0] * 735.5; V.Tq = E[1]; V.gr = B->gear_ratio;
    V.brake_g = B->brake_g + BRAKE_ADD[motor];
    V.driven = B->driven; V.track = B->track;
    V.a = B->wheelbase * (1.0 - B->wf);
    V.b = B->wheelbase * B->wf;
    V.zf = V.a + B->front_over;
    V.zr = V.b + B->rear_over;
    double L = V.zf + V.zr;
    double k = 0.28 * L;
    V.iz = V.m * k * k;
    double n_axle_f = V.m * G_ACC * B->wf * 0.0 + V.m * G_ACC * (V.b / B->wheelbase);
    double n_axle_r = V.m * G_ACC * (V.a / B->wheelbase);
    V.cf = 9.0 * n_axle_f;
    V.cr = 9.0 * n_axle_r;
    /* resistência estrutural depende da massa de fábrica (carga extra não reforça a carroceria) */
    V.fp[FACE_FRONT] = V.m0 * G_ACC * B->kf_front;
    V.fp[FACE_REAR]  = V.m0 * G_ACC * B->kf_rear;
    V.fp[FACE_LEFT]  = V.m0 * G_ACC * B->kf_side;
    V.fp[FACE_RIGHT] = V.m0 * G_ACC * B->kf_side;
    V.cap[FACE_FRONT] = B->cap_front; V.cap[FACE_REAR] = B->cap_rear;
    V.cap[FACE_LEFT] = V.cap[FACE_RIGHT] = B->cap_side;
    V.beta[FACE_FRONT] = B->beta_front; V.beta[FACE_REAR] = B->beta_rear;
    V.beta[FACE_LEFT] = V.beta[FACE_RIGHT] = B->beta_side;
    double kbs = 8.0e6 * (V.m0 / 1500.0);
    V.kb[FACE_FRONT] = kbs; V.kb[FACE_REAR] = kbs * 0.8;
    V.kb[FACE_LEFT] = V.kb[FACE_RIGHT] = kbs * 1.2;
}

static double f_veh(const Sample *s, double x) {
    if (x <= 0.0) return 0.0;
    double r = x / s->cap;
    double f = s->fpi * (1.0 - exp(-x / X0_CRUSH)) * (1.0 + s->beta * r * r);
    if (x > s->cap) f += s->kbi * (x - s->cap);
    return f;
}

/* força efetiva do par veículo+obstáculo em série, em função da penetração total p */
static double f_eff(const Sample *s, double p) {
    if (p <= 0.0) return 0.0;
    if (O.travel <= 0.0 || p < s->xstar) return f_veh(s, p);
    if (p < s->xstar + O.travel) return s->fo;
    return f_veh(s, p - O.travel);
}

/* parcela da penetração p absorvida pela carroceria (o restante é do obstáculo) */
static double crush_vehicle_share(const Sample *s, double p) {
    if (p <= 0.0) return 0.0;
    if (O.travel <= 0.0 || p < s->xstar) return p;
    if (p < s->xstar + O.travel) return s->xstar;
    return p - O.travel;
}
static double obstacle_share(const Sample *s, double p) {
    if (O.travel <= 0.0 || p <= s->xstar) return 0.0;
    double d = p - s->xstar;
    return d < O.travel ? d : O.travel;
}

static double x_perm(double pk) {
    double v = (1.0 - ELASTIC_FRAC) * pk - 0.004;
    return v > 0.0 ? v : 0.0;
}

static double sample_force(int i, double p) {
    if (p <= 0.0) return 0.0;
    double pk = peak[i];
    if (p >= pk) return f_eff(&S[i], p);
    double xp = x_perm(pk);
    if (p <= xp) return 0.0;
    return f_eff(&S[i], pk) * (p - xp) / (pk - xp);
}

static void build_samples(void) {
    for (int f = 0; f < SIM_NFACE; f++) {
        for (int k = 0; k < SIM_PER_FACE; k++) {
            Sample *s = &S[f * SIM_PER_FACE + k];
            double t = (k - 4) / 4.0;
            s->face = f;
            switch (f) {
                case FACE_FRONT: s->lx = t * 0.46 * V.W; s->lz = V.zf;  s->nx = 0; s->nz = -1; break;
                case FACE_REAR:  s->lx = t * 0.46 * V.W; s->lz = -V.zr; s->nx = 0; s->nz = 1;  break;
                case FACE_LEFT:  s->lx = V.W * 0.5; s->lz = 0.5 * (V.zf - V.zr) + t * 0.40 * (V.zf + V.zr);
                                 s->nx = -1; s->nz = 0; break;
                default:         s->lx = -V.W * 0.5; s->lz = 0.5 * (V.zf - V.zr) + t * 0.40 * (V.zf + V.zr);
                                 s->nx = 1; s->nz = 0; break;
            }
            s->cap = V.cap[f];
            s->beta = V.beta[f];
            s->fpi = V.fp[f] / SIM_PER_FACE;
            s->kbi = V.kb[f] / SIM_PER_FACE;
            s->fo = O.fo / SIM_PER_FACE;
            /* esmagamento do veículo em que f_veh = fo (série com o obstáculo) */
            if (O.travel > 0.0) {
                double lo = 0.0, hi = 5.0;
                for (int it = 0; it < 50; it++) {
                    double mid = 0.5 * (lo + hi);
                    if (f_veh(s, mid) < s->fo) lo = mid; else hi = mid;
                }
                s->xstar = 0.5 * (lo + hi);
            } else {
                s->xstar = 1e9;
            }
            int idx = f * SIM_PER_FACE + k;
            samples_out[idx * SIM_SAMPLE_STRIDE + 0] = (float)s->lx;
            samples_out[idx * SIM_SAMPLE_STRIDE + 1] = (float)s->lz;
            samples_out[idx * SIM_SAMPLE_STRIDE + 2] = (float)s->nx;
            samples_out[idx * SIM_SAMPLE_STRIDE + 3] = (float)s->nz;
            samples_out[idx * SIM_SAMPLE_STRIDE + 4] = (float)f;
            samples_out[idx * SIM_SAMPLE_STRIDE + 5] = (float)s->cap;
            samples_out[idx * SIM_SAMPLE_STRIDE + 6] = 0.f;
            samples_out[idx * SIM_SAMPLE_STRIDE + 7] = 0.f;
        }
    }
}

/* ------------------------------------------------------------------------------------------
 * Dinâmica longitudinal/lateral
 * ---------------------------------------------------------------------------------------- */
static double engine_force_max(double u_abs, int gear) {
    double f_launch = V.Tq * V.gr * 0.9 / V.rw;
    double f_pow = V.P * 0.9 / (u_abs > 0.5 ? u_abs : 0.5);
    double f = f_launch < f_pow ? f_launch : f_pow;
    if (gear < 0) f *= 0.6;
    return f;
}

static double steer_limit(double u_abs) {
    double d0 = 0.52;
    double r = u_abs / 22.0;
    return d0 / (1.0 + r * r);
}

/* ponto de referência (centro da face que lidera o movimento) em coordenadas locais */
static void ref_local(int face, double *rx, double *rz) {
    switch (face) {
        case FACE_FRONT: *rx = 0; *rz = V.zf; break;
        case FACE_REAR:  *rx = 0; *rz = -V.zr; break;
        case FACE_LEFT:  *rx = V.W * 0.5; *rz = 0; break;
        default:         *rx = -V.W * 0.5; *rz = 0; break;
    }
}

static int gear_for_face(int face) { return face == FACE_REAR ? -1 : 1; }

/* Controle automático de velocidade: PI sobre o erro da velocidade na direção de deslocamento. */
static double auto_throttle(double speed_dir, double target, double *integ, double dt) {
    double err = target - speed_dir;
    *integ = clampd(*integ + err * dt, -1.0, 1.5);
    return clampd(0.6 * err + 0.45 * (*integ), 0.0, 1.0);
}

/* Planejador: menor velocidade de lançamento v0 para atingir a velocidade-alvo ao fim de 200 m. */
static double sim_1d_final_speed(double v0, double target, int gear, double dist) {
    double u = v0, s = 0.0, integ = 0.0;
    const double dt = 1.0 / 200.0;
    double N = V.m * G_ACC;
    int guard = 0;
    while (s < dist && guard++ < 200000) {
        double thr = auto_throttle(u, target, &integ, dt);
        double fmax = engine_force_max(u, gear);
        double ftr = MU_TIRE * (V.driven == 0 ? N * (V.b / (V.a + V.b)) : N * (V.a / (V.a + V.b)));
        double fd = thr * (fmax < ftr ? fmax : ftr);
        double fres = 0.5 * RHO_AIR * V.cda * u * u + V.crr * N;
        double a = (fd - fres) / V.m;
        u += a * dt;
        if (u < 0.0) u = 0.0;
        s += u * dt;
    }
    return u;
}

static double plan_launch(double target, int gear, double dist) {
    if (sim_1d_final_speed(0.0, target, gear, dist) >= target - 0.08) return 0.0;
    double lo = 0.0, hi = target;
    for (int it = 0; it < 40; it++) {
        double mid = 0.5 * (lo + hi);
        if (sim_1d_final_speed(mid, target, gear, dist) >= target - 0.08) hi = mid; else lo = mid;
    }
    return hi;
}

/* ------------------------------------------------------------------------------------------
 * Zonas de dano (estimativa simplificada, derivada dos esmagamentos efetivamente simulados)
 * ---------------------------------------------------------------------------------------- */
static void update_damage(double peak_g) {
    /* A força de contato aponta na direção da normal da parede; o esmagamento de cada ponto é atribuído
       às faces do veículo conforme essa direção no referencial local (dir_x, dir_z). Assim, o canto frontal
       atingido num impacto lateral conta como dano lateral e não como dano frontal. */
    double mx[4] = {0, 0, 0, 0}, mean[4] = {0, 0, 0, 0}, cmax[4] = {0, 0, 0, 0};
    double fa[SIM_PER_FACE], ra[SIM_PER_FACE];
    for (int k = 0; k < SIM_PER_FACE; k++) { fa[k] = 0; ra[k] = 0; }
    double cen = 0.0;
    for (int i = 0; i < SIM_NSAMP; i++) {
        double c = vis_c[i];
        if (c <= 0.0) continue;
        double dx = dir_x[i], dz = dir_z[i];
        double w[4];
        w[FACE_FRONT] = dz < 0 ? dz * dz : 0.0;
        w[FACE_REAR]  = dz > 0 ? dz * dz : 0.0;
        w[FACE_LEFT]  = dx < 0 ? dx * dx : 0.0;
        w[FACE_RIGHT] = dx > 0 ? dx * dx : 0.0;
        double ws = w[0] + w[1] + w[2] + w[3];
        if (ws < 1e-9) { w[S[i].face] = 1.0; ws = 1.0; }
        for (int f = 0; f < 4; f++) {
            double cc = c * w[f] / ws;
            if (cc <= 0.0) continue;
            double r = cc / V.cap[f];
            if (r > mx[f]) mx[f] = r;
            if (cc > cmax[f]) cmax[f] = cc;
            mean[f] += r / SIM_PER_FACE;
            if (f == FACE_FRONT && i < SIM_PER_FACE) fa[i] = cc;
            if (f == FACE_FRONT && i >= 2 && i <= 6 && i < SIM_PER_FACE) cen += cc / 5.0;
            if (f == FACE_REAR && i >= SIM_PER_FACE && i < 2 * SIM_PER_FACE) ra[i - SIM_PER_FACE] = cc;
        }
    }
    double cmean_central = cen;

    zone_dmg[Z_FRONT] = clampd(0.65 * mx[0] + 0.35 * mean[0], 0, 1);
    zone_disp[Z_FRONT] = cmax[0];
    zone_dmg[Z_HOOD] = clampd((cmean_central - 0.10) / (0.70 * V.cap[0]), 0, 1);
    zone_disp[Z_HOOD] = 0.35 * cmax[0];
    zone_dmg[Z_LEFT] = clampd(0.7 * mx[2] + 0.3 * mean[2], 0, 1);
    zone_disp[Z_LEFT] = cmax[2];
    zone_dmg[Z_RIGHT] = clampd(0.7 * mx[3] + 0.3 * mean[3], 0, 1);
    zone_disp[Z_RIGHT] = cmax[3];
    double roof = 0.8 * clampd((mx[0] - 0.75) / 0.25, 0, 1) + 0.8 * clampd((mx[2] > mx[3] ? mx[2] : mx[3]) - 0.8, 0, 1) / 0.2
                + 0.6 * clampd((mx[1] - 0.85) / 0.15, 0, 1);
    zone_dmg[Z_ROOF] = clampd(roof, 0, 1);
    zone_disp[Z_ROOF] = zone_dmg[Z_ROOF] * 0.15;
    zone_dmg[Z_REAR] = clampd(0.65 * mx[1] + 0.35 * mean[1], 0, 1);
    zone_disp[Z_REAR] = cmax[1];

    /* rodas e suspensão: esmagamento alcança as rodas, ou intrusão lateral na região dos eixos */
    double ov_f = V.zf - V.a, ov_r = V.zr - V.b;
    double cfc = 0.0, crc = 0.0, csw = 0.0;
    for (int k = 0; k < SIM_PER_FACE; k++) {
        if (k <= 1 || k >= 7) {
            double cf = fa[k], cr = ra[k];
            if (cf > cfc) cfc = cf;
            if (cr > crc) crc = cr;
        }
    }
    for (int f = 2; f <= 3; f++) {
        for (int k = 0; k < SIM_PER_FACE; k++) {
            double lz = S[f * SIM_PER_FACE + k].lz;
            if (FABS(lz - V.a) < 0.55 || FABS(lz + V.b) < 0.55) {
                double c = vis_c[f * SIM_PER_FACE + k];
                if (c > csw) csw = c;
            }
        }
    }
    double wf = clampd((cfc - (ov_f - V.rw)) / 0.45, 0, 1);
    double wr = clampd((crc - (ov_r - V.rw)) / 0.45, 0, 1);
    double ws = clampd((csw - 0.05) / 0.22, 0, 1);
    double wmax = wf > wr ? wf : wr; if (ws > wmax) wmax = ws;
    zone_dmg[Z_WHEELS] = wmax;
    zone_disp[Z_WHEELS] = cfc > crc ? (cfc > csw ? cfc : csw) : (crc > csw ? crc : csw);

    double st = 0.6 * clampd((mx[0] - 0.55) / 0.45, 0, 1) + 0.6 * clampd((((mx[2] > mx[3]) ? mx[2] : mx[3]) - 0.6) / 0.4, 0, 1)
              + 0.6 * clampd((mx[1] - 0.7) / 0.3, 0, 1) + 0.4 * clampd((peak_g - 40.0) / 110.0, 0, 1);
    zone_dmg[Z_STRUCT] = clampd(st, 0, 1);
    zone_disp[Z_STRUCT] = zone_dmg[Z_STRUCT] * 0.30;

    unsigned b = 0;
    for (int k = 0; k < SIM_PER_FACE; k++) {
        double lx = S[k].lx;
        double cf = fa[k], cr = ra[k];
        if (cf > 0.18 && lx > 0.18 * V.W) b |= BRK_HEAD_L;
        if (cf > 0.18 && lx < -0.18 * V.W) b |= BRK_HEAD_R;
        if (cr > 0.14 && lx > 0.18 * V.W) b |= BRK_TAIL_L;
        if (cr > 0.14 && lx < -0.18 * V.W) b |= BRK_TAIL_R;
    }
    if (cmax[0] > 0.45 * V.cap[0]) b |= BRK_WSHIELD;
    if (cmax[1] > 0.50 * V.cap[1]) b |= BRK_RGLASS;
    if (cmax[2] > 0.10) b |= BRK_WIN_L;
    if (cmax[3] > 0.10) b |= BRK_WIN_R;
    if (cmax[0] > 0.55 * V.cap[0]) b |= BRK_HOOD;
    if (cmax[0] > 0.60 * V.cap[0]) b |= BRK_BUMPER_F;
    if (cmax[1] > 0.60 * V.cap[1]) b |= BRK_BUMPER_R;
    broken_mask = b;
}

/* ------------------------------------------------------------------------------------------
 * Reset / configuração
 * ---------------------------------------------------------------------------------------- */
static void reset_state(void) {
    double rx, rz;
    int face = cfg_face;
    double th = cfg_angle * PI_ / 180.0;
    sled = (face == FACE_LEFT || face == FACE_RIGHT) ? 1 : 0;
    double dirx = sin(th), dirz = cos(th);

    if (face == FACE_FRONT) psi = th;
    else if (face == FACE_REAR) psi = th + PI_;
    else if (face == FACE_LEFT) psi = th - PI_ / 2.0;
    else psi = th + PI_ / 2.0;

    ref_local(face, &rx, &rz);
    double c = cos(psi), s = sin(psi);
    double refx = cfg_offset - 200.0 * tan(th);
    double refz = -200.0;
    px = refx - (c * rx + s * rz);
    pz = refz - (-s * rx + c * rz);

    gear_cmd = gear_for_face(face);
    double target = cfg_target;
    if (cfg_mode == 0) {
        launch_v = sled ? target : plan_launch(target, gear_cmd, 200.0);
        vx = launch_v * dirx; vz = launch_v * dirz;
    } else {
        launch_v = 0.0; vx = 0.0; vz = 0.0;
        gear_cmd = 1;
        /* modo manual: veículo sempre apontado para a parede, frente à frente */
    }
    if (cfg_mode == 1) {
        psi = th; sled = 0;
        double fx = 0, fz = V.zf;
        px = (cfg_offset - 200.0 * tan(th)) - (cos(psi) * fx + sin(psi) * fz);
        pz = -200.0 - (-sin(psi) * fx + cos(psi) * fz);
    }
    om = 0; st_t = 0; pitch = pitch_r = roll = roll_r = 0;
    ax_f = ay_f = ax_lp = az_lp = a_long_f = a_lat_f = 0;
    spin = 0; steer_act = 0; in_thr = in_brk = in_str = 0; thr_app = brk_app = 0;
    phase = PH_IDLE; impacted = 0;
    v_before = vn_before = t_impact = ke0 = impulse = peak_a = e_crush = e_fric = 0;
    jx = jz = peak_f = contact_t = yaw_at_imp = obs_travel_max = 0;
    imp_x = imp_y = imp_z = imp_lx = imp_lz = 0;
    events = evstr = ftotal = 0; ncontact = contact_prev = 0; nsub_last = 1; steps = 0;
    settle_t = since_impact = 0; speed_prev = launch_v; ctl_i = 0; broken_mask = 0;
    for (int i = 0; i < SIM_NSAMP; i++) { pen[i] = 0; peak[i] = 0; fn_s[i] = 0; vis_c[i] = 0; crush_out[i] = 0; dir_x[i] = S[i].nx; dir_z[i] = S[i].nz; }
    for (int z = 0; z < Z_COUNT; z++) { zone_dmg[z] = 0; zone_disp[z] = 0; }
}

/* ------------------------------------------------------------------------------------------
 * Publicação dos resultados
 * ---------------------------------------------------------------------------------------- */
static void publish(void) {
    double rx, rz;
    ref_local(cfg_face, &rx, &rz);
    double c = cos(psi), s = sin(psi);
    double refx = px + c * rx + s * rz, refz = pz + (-s * rx + c * rz);
    double fx = s, fzv = c;
    double lx = c, lz = -s;
    double u = vx * fx + vz * fzv;
    double v = vx * lx + vz * lz;
    double speed = SQRT(vx * vx + vz * vz);
    out_[O_T] = (float)st_t; out_[O_X] = (float)px; out_[O_Z] = (float)pz; out_[O_Y] = 0.f;
    out_[O_YAW] = (float)psi; out_[O_PITCH] = (float)pitch; out_[O_ROLL] = (float)roll;
    out_[O_SPEED] = (float)speed; out_[O_U] = (float)u; out_[O_V] = (float)v;
    out_[O_VX] = (float)vx; out_[O_VZ] = (float)vz; out_[O_OMEGA] = (float)om;
    out_[O_ALONG] = (float)a_long_f; out_[O_ALAT] = (float)a_lat_f;
    out_[O_GNOW] = (float)(SQRT(ax_lp * ax_lp + az_lp * az_lp) / G_ACC);
    out_[O_DIST] = (float)(-refz);
    out_[O_THR] = (float)thr_app; out_[O_BRK] = (float)brk_app; out_[O_STEER] = (float)steer_act;
    out_[O_PHASE] = (float)phase; out_[O_IMPACTED] = (float)impacted;
    out_[O_VBEFORE] = (float)v_before; out_[O_VNORM] = (float)vn_before; out_[O_TIMPACT] = (float)t_impact;
    out_[O_KE0] = (float)ke0; out_[O_IMPULSE] = (float)impulse;
    out_[O_PEAKA] = (float)peak_a; out_[O_PEAKG] = (float)(peak_a / G_ACC);
    out_[O_ECRUSH] = (float)e_crush; out_[O_EFRIC] = (float)e_fric;
    out_[O_MASS] = (float)V.m; out_[O_TARGET] = (float)cfg_target; out_[O_LAUNCH] = (float)launch_v;
    out_[O_SPIN] = (float)spin;
    out_[O_KENOW] = (float)(0.5 * V.m * speed * speed + 0.5 * V.iz * om * om);
    double dsum = 0, dmax = 0;
    for (int z = 0; z < Z_COUNT; z++) {
        out_[O_ZONE0 + 2 * z] = (float)zone_dmg[z];
        out_[O_ZONE0 + 2 * z + 1] = (float)zone_disp[z];
        dsum += zone_dmg[z];
        if (zone_dmg[z] > dmax) dmax = zone_dmg[z];
    }
    double dmg = 0.6 * dmax + 0.4 * dsum / Z_COUNT;
    out_[O_DAMAGE] = (float)dmg;
    out_[O_STATE] = dmg < 0.04 ? 0.f : dmg < 0.25 ? 1.f : dmg < 0.5 ? 2.f : dmg < 0.75 ? 3.f : 4.f;
    out_[O_BROKEN] = (float)broken_mask;
    out_[O_IMPX] = (float)imp_x; out_[O_IMPY] = (float)imp_y; out_[O_IMPZ] = (float)imp_z;
    out_[O_IMPLX] = (float)imp_lx; out_[O_IMPLZ] = (float)imp_lz;
    out_[O_EVENTS] = (float)events; out_[O_EVSTR] = (float)evstr;
    out_[O_NCONTACT] = (float)ncontact; out_[O_FTOTAL] = (float)ftotal;
    out_[O_BRAKELIGHT] = (brk_app > 0.05 || (cfg_mode == 0 && impacted)) ? 1.f : 0.f;
    out_[O_OBSTRAVEL] = (float)obs_travel_max;
    out_[O_ANGLEDEG] = (float)(atan2(vx, vz > 1e-6 || vz < -1e-6 ? vz : 1e-6) * 180.0 / PI_);
    out_[O_VAFTER] = impacted ? (float)speed : 0.f;
    out_[O_SLED] = (float)sled; out_[O_MODE] = (float)cfg_mode; out_[O_FACE] = (float)cfg_face;
    out_[O_OBSTACLE] = (float)cfg_obstacle;
    out_[O_REFX] = (float)refx; out_[O_REFZ] = (float)refz;
    out_[O_STEPS] = (float)steps;
    out_[O_YAWDEG_IMP] = impacted ? (float)(wrap_pi(psi - yaw_at_imp) * 180.0 / PI_) : 0.f;
    out_[O_CONTACT_T] = (float)contact_t; out_[O_PEAKF] = (float)peak_f;
    out_[O_NSUB] = (float)nsub_last;
    out_[O_JVEC_X] = (float)jx; out_[O_JVEC_Z] = (float)jz;
    for (int i = 0; i < SIM_NSAMP; i++) { crush_out[i] = (float)vis_c[i]; dir_out[2 * i] = (float)dir_x[i]; dir_out[2 * i + 1] = (float)dir_z[i]; }
}

/* ------------------------------------------------------------------------------------------
 * Integração (um sub-passo)
 * ---------------------------------------------------------------------------------------- */
static void substep(double h) {
    double c = cos(psi), s = sin(psi);
    double fxv = s, fzv = c, lxv = c, lzv = -s;
    double u = vx * fxv + vz * fzv;
    double vl = vx * lxv + vz * lzv;
    double u_abs = FABS(u);
    double spd = SQRT(vx * vx + vz * vz);

    double Fx = 0.0, Fy = 0.0, Tq = 0.0;  /* forças no referencial do corpo e torque */
    double thr = 0.0, brk = 0.0, str = 0.0;

    /* --- comandos ------------------------------------------------------------------- */
    if (cfg_mode == 0) {
        int dir = gear_cmd;
        if (phase == PH_RUNNING && !impacted && !sled) {
            double sd = dir * u;
            thr = auto_throttle(sd, cfg_target, &ctl_i, h);
            double tpsi = (cfg_face == FACE_REAR ? PI_ : 0.0) + cfg_angle * PI_ / 180.0;
            double e = wrap_pi(tpsi - psi);
            str = dir * clampd(1.2 * e - 0.5 * om, -0.12, 0.12) / 0.52;
        } else if (impacted) {
            thr = 0.0; brk = 1.0;
        }
    } else {
        thr = in_thr; brk = in_brk; str = in_str;
        if (impacted && phase >= PH_IMPACT && since_impact > 0.5) { thr = 0.0; brk = 1.0; }
    }
    thr_app = thr; brk_app = brk;

    double d_target = str * steer_limit(u_abs);
    double dmax = 2.2 * h;
    double dd = d_target - steer_act;
    steer_act += clampd(dd, -dmax, dmax);

    /* --- pneus / resistências ---------------------------------------------------------- */
    if (!sled) {
        double wb = V.a + V.b;
        double N = V.m * G_ACC;
        double Nf = N * (V.b / wb) - V.m * a_long_f * V.hcg / wb;
        double Nr = N * (V.a / wb) + V.m * a_long_f * V.hcg / wb;
        Nf = clampd(Nf, 0.08 * N, 0.92 * N);
        Nr = clampd(Nr, 0.08 * N, 0.92 * N);
        int gdir = (cfg_mode == 0) ? gear_cmd : gear_cmd;

        double fdrive = 0.0;
        if (thr > 0.0) {
            double fm = engine_force_max(u_abs, gdir);
            double Nd = V.driven == 0 ? Nf : Nr;
            double ft = MU_TIRE * Nd;
            fdrive = thr * (fm < ft ? fm : ft) * gdir;
        }
        double fbrake = 0.0;
        if (brk > 0.0) {
            double fb = brk * V.brake_g * N;
            double fl = MU_TIRE * (Nf + Nr);
            fbrake = -(fb < fl ? fb : fl) * sgn_smooth(u, 0.4);
        }
        double froll = -V.crr * N * sgn_smooth(u, 0.3);
        double fdrag = -0.5 * RHO_AIR * V.cda * u * u_abs;
        Fx += fdrive + fbrake + froll + fdrag;

        double delta = steer_act;
        double v_f = vl + V.a * om;
        double v_r = vl - V.b * om;
        /* velocidade do eixo no referencial da roda */
        double cd = cos(delta), sd = sin(delta);
        double v_par_f = u * cd + v_f * sd;
        double v_perp_f = v_f * cd - u * sd;
        double alpha_f = atan2(v_perp_f, (FABS(v_par_f) > 1.0 ? FABS(v_par_f) : 1.0));
        double alpha_r = atan2(v_r, (u_abs > 1.0 ? u_abs : 1.0));
        double Fyf = clampd(-V.cf * alpha_f, -MU_TIRE * Nf, MU_TIRE * Nf);
        double Fyr = clampd(-V.cr * alpha_r, -MU_TIRE * Nr, MU_TIRE * Nr);
        /* força da roda dianteira: perpendicular ao eixo da roda */
        Fy += Fyf * cd + Fyr;
        Fx += -Fyf * sd;
        Tq += V.a * (Fyf * cd) - V.b * Fyr + V.a * (-0.0);
        Tq += -om * 0.0;
    }

    /* --- forças de contato ----------------------------------------------------------- */
    double Fcx = 0.0, Fcz = 0.0, Tc = 0.0, Fn_total = 0.0;
    int nc = 0;
    double cwx = 0.0, cwz = 0.0, clx = 0.0, clz = 0.0;
    for (int i = 0; i < SIM_NSAMP; i++) {
        const Sample *sm = &S[i];
        double rx = c * sm->lx + s * sm->lz;
        double rz = -s * sm->lx + c * sm->lz;
        double wx = px + rx, wz = pz + rz;
        double p = wz;                       /* penetração além do plano z = 0 */
        int inside = (p > 0.0) && (FABS(wx) <= O.hw);
        double pen_new = inside ? p : 0.0;
        double fprev = fn_s[i];
        double F = 0.0;
        if (pen_new > 0.0) {
            F = sample_force(i, pen_new);
            if (pen_new > peak[i]) {
                peak[i] = pen_new;
                /* direção (local) em que a carroceria é empurrada: normal da parede (0,0,-1) no referencial do corpo */
                dir_x[i] = s; dir_z[i] = -c;
            }
            double ptx = vx + om * rz;
            double Ft = -O.mu * F * ptx / (FABS(ptx) + 0.15);
            double ptz = vz - om * rx;
            (void)ptz;
            Fcz += -F;
            Fcx += Ft;
            Tc += rz * Ft - rx * (-F);
            e_fric += FABS(Ft * ptx) * h;
            Fn_total += F;
            if (F > 0.0) { nc++; cwx += F * wx; cwz += F * wz; clx += F * sm->lx; clz += F * sm->lz; }
        }
        double dpen = pen_new - pen[i];
        if (fprev > 0.0 || F > 0.0) e_crush += 0.5 * (fprev + F) * dpen;
        pen[i] = pen_new;
        fn_s[i] = F;
        double cvp = crush_vehicle_share(sm, peak[i]);
        double cperm = x_perm(cvp);
        double cnow = crush_vehicle_share(sm, pen_new);
        double cv = cnow > cperm ? cnow : cperm;
        vis_c[i] = cv;
        if (O.travel > 0.0) {
            double ot = obstacle_share(sm, peak[i]);
            if (ot > obs_travel_max) obs_travel_max = ot;
        }
    }

    ncontact = nc;
    ftotal = Fn_total;
    if (Fn_total > peak_f) peak_f = Fn_total;
    if (nc > 0 && !impacted) {
        impacted = 1; phase = PH_IMPACT;
        v_before = speed_prev;
        vn_before = FABS(vz);
        t_impact = st_t;
        ke0 = 0.5 * V.m * v_before * v_before;
        yaw_at_imp = psi;
        imp_x = cwx / Fn_total; imp_z = cwz / Fn_total; imp_y = 0.5;
        imp_lx = clx / Fn_total; imp_lz = clz / Fn_total;
        since_impact = 0.0;
    }
    if (nc > 0 && contact_prev == 0) { events += 1.0; evstr = Fn_total; }
    if (nc > 0) { contact_t += h; impulse += Fn_total * h; jx += Fcx * h; jz += Fcz * h; }
    contact_prev = nc;

    /* --- soma e integração ---------------------------------------------------------- */
    double Fwx = Fx * fxv + Fy * lxv + Fcx;
    double Fwz = Fx * fzv + Fy * lzv + Fcz;
    double Ttot = Tq + Tc;
    if (sled && impacted) {
        /* trenó: após o impacto, o veículo desliza sobre o solo com atrito de deslizamento */
        double fg = 0.55 * V.m * G_ACC;
        Fwx += -fg * vx / (spd + 0.2);
        Fwz += -fg * vz / (spd + 0.2);
        Ttot += -V.iz * 1.2 * om;
    }
    double ax = Fwx / V.m, az = Fwz / V.m;
    double aom = Ttot / V.iz;

    speed_prev = spd;
    vx += ax * h; vz += az * h;
    om += aom * h;
    psi += om * h;
    px += vx * h; pz += vz * h;
    st_t += h;
    if (impacted) since_impact += h;

    /* grandezas de telemetria: aceleração filtrada no referencial do corpo */
    double k = h / (LOWPASS_TAU + h);
    ax_lp += (ax - ax_lp) * k;
    az_lp += (az - az_lp) * k;
    double al = ax_lp * fxv + az_lp * fzv;
    double alat = ax_lp * lxv + az_lp * lzv;
    a_long_f = al; a_lat_f = alat;
    double amag = SQRT(ax_lp * ax_lp + az_lp * az_lp);
    if (impacted && amag > peak_a) peak_a = amag;

    /* roda e atitude visual (arfagem/rolagem): mola-amortecedor sobre a aceleração filtrada */
    double wn = 2.0 * PI_ * 1.4, zeta = 0.45;
    double p_eq = clampd(0.0035 * al, -0.10, 0.10);
    double r_eq = clampd(0.0040 * alat, -0.12, 0.12);
    double pa = wn * wn * (p_eq - pitch) - 2.0 * zeta * wn * pitch_r;
    double ra = wn * wn * (r_eq - roll) - 2.0 * zeta * wn * roll_r;
    pitch_r += pa * h; pitch += pitch_r * h;
    roll_r += ra * h; roll += roll_r * h;
    pitch = clampd(pitch, -0.14, 0.14);
    roll = clampd(roll, -0.18, 0.18);
    spin += (u / V.rw) * h;
}

SIM_EXPORT("sim_step")
void sim_step(float dt_f) {
    double dt = dt_f;
    if (phase == PH_IDLE || phase == PH_SETTLED) return;
    double rmax = V.zf + V.zr + V.W;
    double spd = SQRT(vx * vx + vz * vz) + FABS(om) * rmax * 0.5;
    int n = (int)(spd * dt / 0.03) + 1;     /* prevenção de atravessamento: deslocamento <= ~3 cm por sub-passo */
    if (n > 24) n = 24;
    if (impacted && n < 2) n = 2;
    double h = dt / n;
    for (int i = 0; i < n; i++) substep(h);
    nsub_last = n;
    steps++;
    if (impacted) {
        double speed = SQRT(vx * vx + vz * vz);
        if (speed < 0.05 && FABS(om) < 0.02 && ncontact == 0) settle_t += dt; else settle_t = 0.0;
        if (settle_t > 1.0 || since_impact > 25.0) phase = PH_SETTLED;
    }
    update_damage(peak_a / G_ACC);
    publish();
}

/* ------------------------------------------------------------------------------------------
 * API pública
 * ---------------------------------------------------------------------------------------- */
SIM_EXPORT("sim_version") int sim_version(void) { return SIM_VERSION; }
SIM_EXPORT("sim_out_count") int sim_out_count(void) { return SIM_OUT_COUNT; }
SIM_EXPORT("sim_out") float *sim_out(void) { return out_; }
SIM_EXPORT("sim_crush") float *sim_crush(void) { return crush_out; }
SIM_EXPORT("sim_samples") float *sim_samples(void) { return samples_out; }
SIM_EXPORT("sim_crush_dir") float *sim_crush_dir(void) { return dir_out; }
SIM_EXPORT("sim_spec_ptr") float *sim_spec_ptr(void) { return spec_out; }

SIM_EXPORT("sim_vehicle_dims")
void sim_vehicle_dims(int veh, int motor, float extra) {
    if (veh < 0 || veh > 2) veh = 0;
    if (motor < 0 || motor > 2) motor = 0;
    Veh sv = V;
    build_vehicle(veh, motor, extra);
    spec_out[S_MASS] = (float)V.m; spec_out[S_POWER] = (float)ENG[veh][motor][0];
    spec_out[S_TORQUE] = (float)V.Tq;
    spec_out[S_ZF] = (float)V.zf; spec_out[S_ZR] = (float)V.zr; spec_out[S_WIDTH] = (float)V.W;
    spec_out[S_HEIGHT] = (float)V.H; spec_out[S_A] = (float)V.a; spec_out[S_B] = (float)V.b;
    spec_out[S_HCG] = (float)V.hcg; spec_out[S_RW] = (float)V.rw; spec_out[S_TRACK] = (float)V.track;
    spec_out[S_BRAKEG] = (float)V.brake_g; spec_out[S_LENGTH] = (float)(V.zf + V.zr);

    /* 0-100 km/h simulado (aceleração máxima, limite de tração, resistências) */
    {
        double u = 0.0, t = 0.0, N = V.m * G_ACC, wb = V.a + V.b, al = 0.0;
        const double dt = 0.002;
        double t100 = -1.0;
        while (t < 60.0) {
            double Nd = (V.driven == 0) ? (N * (V.b / wb) - V.m * al * V.hcg / wb)
                                        : (N * (V.a / wb) + V.m * al * V.hcg / wb);
            double fm = engine_force_max(u, 1);
            double ft = MU_TIRE * (Nd > 0.05 * N ? Nd : 0.05 * N);
            double fd = fm < ft ? fm : ft;
            double fres = 0.5 * RHO_AIR * V.cda * u * u + V.crr * N;
            al = (fd - fres) / V.m;
            u += al * dt; t += dt;
            if (u >= 100.0 / 3.6) { t100 = t; break; }
        }
        spec_out[S_0100] = (float)t100;
    }
    /* velocidade máxima: equilíbrio entre potência na roda e resistências */
    {
        double lo = 5.0, hi = 120.0, N = V.m * G_ACC;
        for (int it = 0; it < 60; it++) {
            double mid = 0.5 * (lo + hi);
            double fd = engine_force_max(mid, 1);
            double fres = 0.5 * RHO_AIR * V.cda * mid * mid + V.crr * N;
            if (fd > fres) lo = mid; else hi = mid;
        }
        spec_out[S_VMAX] = (float)(lo * 3.6);
    }
    V = sv;
}

SIM_EXPORT("sim_configure")
void sim_configure(int veh, int motor, float extra, int obstacle, float target_kmh, int face,
                   float angle_deg, float offset_m, int mode) {
    cfg_veh = (veh < 0 || veh > 2) ? 0 : veh;
    cfg_motor = (motor < 0 || motor > 2) ? 0 : motor;
    cfg_obstacle = (obstacle < 0 || obstacle > 3) ? 0 : obstacle;
    cfg_face = (face < 0 || face > 3) ? 0 : face;
    cfg_mode = mode ? 1 : 0;
    cfg_extra = clampd(extra, -200.0, 800.0);
    cfg_target = clampd(target_kmh, 5.0, 300.0) / 3.6;
    cfg_angle = clampd(angle_deg, -60.0, 60.0);
    cfg_offset = clampd(offset_m, -4.0, 4.0);
    build_vehicle(cfg_veh, cfg_motor, cfg_extra);
    O = OBSTACLES[cfg_obstacle];
    build_samples();
    reset_state();
    update_damage(0.0);
    publish();
}

SIM_EXPORT("sim_reset")
void sim_reset(void) {
    reset_state();
    update_damage(0.0);
    publish();
}

SIM_EXPORT("sim_start")
void sim_start(void) {
    if (phase == PH_IDLE) phase = PH_RUNNING;
    publish();
}

SIM_EXPORT("sim_set_input")
void sim_set_input(float thr, float brk, float str) {
    in_thr = clampd(thr, 0.0, 1.0);
    in_brk = clampd(brk, 0.0, 1.0);
    in_str = clampd(str, -1.0, 1.0);
}

SIM_EXPORT("sim_set_gear")
void sim_set_gear(int gear) {
    if (cfg_mode == 1) gear_cmd = gear < 0 ? -1 : 1;
}

SIM_EXPORT("sim_wheel_info")
void sim_wheel_info(float *o) {
    o[0] = (float)steer_act; o[1] = (float)spin;
}
