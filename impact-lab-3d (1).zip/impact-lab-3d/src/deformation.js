// deformation.js - ponte entre o campo de esmagamento calculado pelo módulo físico (WASM) e a deformação de malha na GPU.
//
// Divisão de trabalho (decisão arquitetural):
//   * WASM/C: física (contato, força, esmagamento permanente de 36 pontos). Poucos dados, lógica sequencial.
//   * GPU (compute): para cada vértice (milhares, independentes) calcula o deslocamento a partir do campo compacto e
//     recalcula as normais por adjacência. Só 36x2 vec4 (1,1 KB) atravessam o barramento por atualização;
//     a geometria deformada nunca volta para a CPU. Atualização seletiva: só despacha quando o campo muda.

const N = 36;

export class GPUDeformer {
  /**
   * @param {GPUDevice} device
   * @param {{displace: GPUComputePipeline, normals: GPUComputePipeline}} pipes
   * @param {object} geom resultado de buildVehicle()
   */
  constructor(device, pipes, geom) {
    this.device = device;
    this.geom = geom;
    const n = geom.vertexCount;
    const mk = (size, usage, label) => device.createBuffer({ size: Math.max(16, size), usage, label });
    const S = GPUBufferUsage.STORAGE, C = GPUBufferUsage.COPY_DST, V = GPUBufferUsage.VERTEX, I = GPUBufferUsage.INDEX;
    this.restBuf = mk(n * 16, S | V | C, 'rest');
    this.restNBuf = mk(n * 16, S | C, 'restN');
    this.posBuf = mk(n * 16, S | V | C, 'pos+dmg');
    this.nrmBuf = mk(n * 16, S | V | C, 'normals');
    this.indexBuf = mk(geom.indices.byteLength, I | S | C, 'indices');
    this.adjOffBuf = mk(geom.adjOffsets.byteLength, S | C, 'adjOff');
    this.adjListBuf = mk(geom.adjList.byteLength, S | C, 'adjList');
    this.fieldBuf = mk(N * 32 + 16, GPUBufferUsage.UNIFORM | C, 'field');
    this.paramBuf = mk(16, GPUBufferUsage.UNIFORM | C, 'params');
    device.queue.writeBuffer(this.restBuf, 0, geom.rest);
    device.queue.writeBuffer(this.restNBuf, 0, geom.restNrm);
    device.queue.writeBuffer(this.indexBuf, 0, geom.indices);
    device.queue.writeBuffer(this.adjOffBuf, 0, geom.adjOffsets);
    device.queue.writeBuffer(this.adjListBuf, 0, geom.adjList);
    device.queue.writeBuffer(this.paramBuf, 0, new Uint32Array([n, 0, 0, 0]));
    this.bgDisplace = device.createBindGroup({
      layout: pipes.displace.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: this.restBuf } }, { binding: 1, resource: { buffer: this.restNBuf } },
        { binding: 2, resource: { buffer: this.posBuf } }, { binding: 3, resource: { buffer: this.fieldBuf } },
        { binding: 4, resource: { buffer: this.paramBuf } }
      ]
    });
    this.bgNormals = device.createBindGroup({
      layout: pipes.normals.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: this.posBuf } }, { binding: 1, resource: { buffer: this.indexBuf } },
        { binding: 2, resource: { buffer: this.adjOffBuf } }, { binding: 3, resource: { buffer: this.adjListBuf } },
        { binding: 4, resource: { buffer: this.nrmBuf } }, { binding: 5, resource: { buffer: this.paramBuf } }
      ]
    });
    this.pipes = pipes;
    this.field = new Float32Array(N * 8 + 4);
    this.last = new Float32Array(N * 3);
    this.dirty = true;
    this.statsDispatches = 0;
    this.maxCrush = 0;
  }

  /**
   * Atualiza o campo a partir das saídas do módulo físico.
   * @returns {boolean} true se houve mudança (despacho necessário)
   */
  setField(crush, dirs, samples, dims, beltY) {
    let changed = this.dirty;
    for (let i = 0; i < N && !changed; i++) {
      if (Math.abs(crush[i] - this.last[3 * i]) > 1e-5 || Math.abs(dirs[2 * i] - this.last[3 * i + 1]) > 1e-4 || Math.abs(dirs[2 * i + 1] - this.last[3 * i + 2]) > 1e-4) changed = true;
    }
    if (!changed) return false;
    const L = dims.zf + dims.zr;
    let mx = 0;
    for (let i = 0; i < N; i++) {
      const face = samples[i * 8 + 4];
      const sigma = face < 1.5 ? 0.1265 * dims.W : 0.11 * L;
      this.field[8 * i] = samples[i * 8]; this.field[8 * i + 1] = samples[i * 8 + 1];
      this.field[8 * i + 2] = dirs[2 * i]; this.field[8 * i + 3] = dirs[2 * i + 1];
      this.field[8 * i + 4] = crush[i]; this.field[8 * i + 5] = samples[i * 8 + 5];
      this.field[8 * i + 6] = sigma; this.field[8 * i + 7] = face;
      this.last[3 * i] = crush[i]; this.last[3 * i + 1] = dirs[2 * i]; this.last[3 * i + 2] = dirs[2 * i + 1];
      if (crush[i] > mx) mx = crush[i];
    }
    this.maxCrush = mx;
    // layout do uniform: a[36] (vec4), b[36] (vec4), info; reorganiza intercalado -> separado
    const packed = new Float32Array(N * 8 + 4);
    for (let i = 0; i < N; i++) {
      for (let k = 0; k < 4; k++) { packed[4 * i + k] = this.field[8 * i + k]; packed[4 * (N + i) + k] = this.field[8 * i + 4 + k]; }
    }
    packed[8 * N] = beltY;
    this.device.queue.writeBuffer(this.fieldBuf, 0, packed);
    this.dirty = true; // despacho pendente
    return true;
  }

  /** registra os dois dispatches no encoder (se houver trabalho pendente) */
  encode(encoder) {
    if (!this.dirty) return false;
    const groups = Math.ceil(this.geom.vertexCount / 64);
    const pass = encoder.beginComputePass({ label: 'deformação' });
    pass.setPipeline(this.pipes.displace); pass.setBindGroup(0, this.bgDisplace); pass.dispatchWorkgroups(groups);
    pass.setPipeline(this.pipes.normals); pass.setBindGroup(0, this.bgNormals); pass.dispatchWorkgroups(groups);
    pass.end();
    this.dirty = false;
    this.statsDispatches++;
    return true;
  }

  /** zera o campo (restaura a carroceria) */
  reset() {
    this.last.fill(0);
    const packed = new Float32Array(N * 8 + 4);
    for (let i = 0; i < N; i++) { packed[4 * i + 2] = 0; packed[4 * (N + i) + 2] = 0.1; packed[4 * (N + i) + 1] = 1; }
    packed[8 * N] = this.field[8 * N] || 0.9;
    this.device.queue.writeBuffer(this.fieldBuf, 0, packed);
    this.dirty = true;
    this.maxCrush = 0;
  }

  destroy() { for (const b of [this.restBuf, this.restNBuf, this.posBuf, this.nrmBuf, this.indexBuf, this.adjOffBuf, this.adjListBuf, this.fieldBuf, this.paramBuf]) b.destroy(); }
}

/**
 * Espelho em CPU do núcleo do shader (sem ruído) para um ponto local: usado para deslocar as rodas dianteiras/traseiras
 * quando o esmagamento as alcança (suspensão avariada) e nos testes.
 */
export function displacePoint(crush, dirs, samples, dims, p, beltY) {
  const L = dims.zf + dims.zr;
  let mag4 = 0, dx = 0, dz = 0;
  for (let s = 0; s < N; s++) {
    const c = crush[s]; if (c < 0.002) continue;
    const face = samples[s * 8 + 4], cap = samples[s * 8 + 5];
    const sigma = face < 1.5 ? 0.1265 * dims.W : 0.11 * L;
    let ddx = dirs[2 * s], ddz = dirs[2 * s + 1]; const dl = Math.hypot(ddx, ddz) || 1; ddx /= dl; ddz /= dl;
    const rx = p[0] - samples[s * 8], rz = p[2] - samples[s * 8 + 1];
    const along = rx * ddx + rz * ddz, perp = -rx * ddz + rz * ddx;
    const g = Math.exp(-(perp * perp) / (2 * sigma * sigma));
    const dcr = Math.max(1.7 * cap, 0.7);
    const prof = Math.pow(1 - Math.min(1, Math.max(along, 0) / dcr), 1.5);
    const t = Math.min(1, Math.max(0, (along + 0.55) / 0.43)), ahead = t * t * (3 - 2 * t);
    const tv = Math.min(1, Math.max(0, (p[1] - (beltY + 0.05)) / 0.55)), vf = 1 - 0.55 * tv * tv * (3 - 2 * tv);
    const m = Math.min(c, 1.03 * cap) * g * prof * ahead * vf, m4 = m ** 4;
    mag4 += m4; dx += ddx * m4; dz += ddz * m4;
  }
  if (mag4 < 1e-12) return [0, 0, 0, 0];
  const M = Math.sqrt(Math.sqrt(mag4)), dl = Math.hypot(dx, dz) || 1;
  return [dx / dl * M, 0, dz / dl * M, M];
}
