// particles.wgsl - partículas de impacto (poeira, fumaça, faíscas, fragmentos, estilhaços de vidro).
// Parte 1: compute (integração na GPU). Parte 2 (após o marcador): render em billboards.
// O carregador divide o arquivo no marcador abaixo; a parte de render recebe lighting.wgsl antes.

struct Particle {
  pos: vec3f,
  life: f32,
  vel: vec3f,
  size: f32,
  col: vec4f,
  kind: vec4f,   // x: tipo (0 poeira/fumaça, 1 faísca, 2 fragmento, 3 vidro), y: vida máxima, z: giro, w: semente
};

struct SimU {
  v: vec4f,      // x: dt, y: tempo, z: parede ativa (1) ou não (0), w: nº de partículas
  q: vec4f,      // x: z do plano do obstáculo (0), y: x min do obstáculo, z: x max do obstáculo, w: ativo lateral
};

@group(0) @binding(0) var<storage, read_write> parts: array<Particle>;
@group(0) @binding(1) var<uniform> simu: SimU;

@compute @workgroup_size(64)
fn update(@builtin(global_invocation_id) gid: vec3u) {
  let i = gid.x;
  if (f32(i) >= simu.v.w) { return; }
  var p = parts[i];
  if (p.life <= 0.0) { return; }
  let dt = simu.v.x;
  let kind = u32(p.kind.x + 0.5);
  if (kind == 0u) {
    p.vel *= exp(-1.6 * dt);
    p.vel.y += 0.9 * dt;
  } else if (kind == 1u) {
    p.vel.y -= 9.81 * dt;
    p.vel *= exp(-0.25 * dt);
  } else {
    p.vel.y -= 9.81 * dt;
    p.vel *= exp(-0.08 * dt);
  }
  p.pos += p.vel * dt;
  // solo
  if (p.pos.y < 0.02 && kind >= 1u) {
    p.pos.y = 0.02;
    p.vel.y = abs(p.vel.y) * 0.35;
    p.vel.x *= 0.7;
    p.vel.z *= 0.7;
    if (length(p.vel) < 0.3) { p.vel = vec3f(0.0); }
  }
  if (p.pos.y < 0.02 && kind == 0u) { p.pos.y = 0.02; p.vel.y = 0.0; }
  // superfície do obstáculo
  if (simu.v.z > 0.5 && p.pos.z > simu.q.x && p.vel.z > 0.0 && p.pos.x > simu.q.y && p.pos.x < simu.q.z && p.pos.y < 4.2) {
    p.pos.z = simu.q.x - 0.01;
    p.vel.z = -p.vel.z * 0.4;
  }
  p.life -= dt;
  parts[i] = p;
}

//#RENDER
@group(1) @binding(0) var<storage, read> pr: array<Particle>;

struct PVOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) col: vec4f,
  @location(2) kind: f32,
};

@vertex
fn vs_particle(@builtin(vertex_index) vi: u32, @builtin(instance_index) ii: u32) -> PVOut {
  var corners = array<vec2f, 6>(vec2f(-1.0, -1.0), vec2f(1.0, -1.0), vec2f(-1.0, 1.0), vec2f(-1.0, 1.0), vec2f(1.0, -1.0), vec2f(1.0, 1.0));
  let p = pr[ii];
  var o: PVOut;
  o.kind = p.kind.x;
  if (p.life <= 0.0) {
    o.clip = vec4f(2.0, 2.0, 2.0, 1.0);
    o.uv = vec2f(0.0);
    o.col = vec4f(0.0);
    return o;
  }
  let c = corners[vi];
  let age = 1.0 - clamp(p.life / max(p.kind.y, 0.001), 0.0, 1.0);
  var size = p.size;
  if (p.kind.x < 0.5) { size = p.size * (1.0 + age * 2.8); }
  // giro do billboard
  let a = p.kind.z * age * 6.0 + p.kind.w * 6.28;
  let ca = cos(a);
  let sa = sin(a);
  let rc = vec2f(c.x * ca - c.y * sa, c.x * sa + c.y * ca);
  let wp = p.pos + (frame.camRight.xyz * rc.x + frame.camUp.xyz * rc.y) * size;
  o.clip = frame.viewProj * vec4f(wp, 1.0);
  o.uv = c;
  var alpha = p.col.a * clamp(p.life / (p.kind.y * 0.55), 0.0, 1.0);
  if (p.kind.x < 0.5) { alpha = alpha * (1.0 - age * 0.6); }
  o.col = vec4f(p.col.rgb, alpha);
  return o;
}

@fragment
fn fs_particle(in: PVOut) -> @location(0) vec4f {
  let k = u32(in.kind + 0.5);
  let d = length(in.uv);
  let sun = max(dot(vec3f(0.0, 1.0, 0.0), normalize(frame.sunDir.xyz)), 0.15);
  let lightMul = mix(0.45 + 0.55 * sun, 1.0, frame.params.y * 0.3);
  if (k == 0u) {
    let n = fbm(in.uv * 2.0 + in.col.rg * 10.0);
    let a = smoothstep(1.0, 0.15, d) * in.col.a * (0.6 + 0.6 * n);
    return vec4f(in.col.rgb * lightMul * a, a);
  }
  if (k == 1u) {
    let a = smoothstep(1.0, 0.0, d) * in.col.a;
    return vec4f(in.col.rgb * a * 3.0, 0.0);
  }
  if (k == 3u) {
    let a = step(max(abs(in.uv.x), abs(in.uv.y)), 0.9) * step(0.0, 1.0 - d * 0.0);
    let glint = 0.6 + 0.4 * sin(in.uv.x * 6.0 + in.col.r * 20.0);
    return vec4f(in.col.rgb * glint * 1.6 * a, a * 0.8);
  }
  if (max(abs(in.uv.x), abs(in.uv.y)) > 0.9) { discard; }
  return vec4f(in.col.rgb * lightMul, 1.0);
}
