// ui.js - interface: navegação entre telas, garagem (personalização), configurações, HUD, resultado e erros.
// Não conhece o renderizador: recebe callbacks. O estado de configuração do teste fica em `ui.config`.

import { CAMERAS } from './cameras.js';
import { DamageMap, ZONE_LABELS, damageLabel, damageColor } from './damage-map.js';
import { ZONES, BRK } from './physics-bridge.js';

export const VEHICLES = [
  { name: 'Hatch', desc: 'Compacto · tração dianteira' },
  { name: 'Sedan', desc: 'Médio · tração dianteira' },
  { name: 'SUV / Picape', desc: 'Utilitário · alto e pesado' }
];
export const MOTORS = ['Econômica', 'Esportiva', 'Alta Potência'];
export const OBSTACLES = ['Parede de Concreto', 'Barreira de Segurança', 'Poste de Concreto', 'Outro (bloco)'];
export const SPEEDS = [30, 50, 80, 100, 120, 150];
export const PAINTS = [
  ['#c8c8cc', 'Prata', 0.8], ['#101114', 'Preto', 0.5], ['#f2f2f2', 'Branco', 0.0], ['#c1121f', 'Vermelho', 0.4], ['#0b3fa8', 'Azul', 0.4],
  ['#1f7a3a', 'Verde', 0.4], ['#f2b705', 'Amarelo', 0.2], ['#ff6a00', 'Laranja', 0.3], ['#6b3fa0', 'Roxo', 0.4], ['#7b5a3a', 'Bronze', 0.7], ['#4a5560', 'Grafite', 0.8], ['#e8d9b8', 'Areia', 0.2]
];

/** dispositivo de toque (celular/tablet) */
export const TOUCH = (navigator.maxTouchPoints || 0) > 0 || matchMedia('(pointer: coarse)').matches;
export const MOBILE = TOUCH && /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
const fmt = (v, d = 1) => v.toFixed(d).replace('.', ',');
const $ = (id) => document.getElementById(id);
const store = {
  get(k, def) { try { const v = localStorage.getItem('impactlab.' + k); return v ? JSON.parse(v) : def; } catch { return def; } },
  set(k, v) { try { localStorage.setItem('impactlab.' + k, JSON.stringify(v)); } catch { /* armazenamento indisponível */ } }
};

export class UI {
  /** @param {object} h callbacks: go(screen), startTest(), thumbnails(veh,paint), configChanged(), settingChanged(key,val), action(name) */
  constructor(h) {
    this.h = h;
    this.config = {
      vehicle: 1, paint: 4, customPaint: null, finish: 0.35, motor: 1, extra: 0, target: 100, obstacle: 0, face: 0, angle: 0, offset: 0, manual: false,
      ...store.get('config', {})
    };
    this.settings = { quality: MOBILE ? 'low' : 'high', env: 'day', volume: 0.5, audio: true, shake: true, particles: true, telemetry: false, ...store.get('settings', {}) };
    this.screen = 'loading';
    this.specFn = null;
    this.damage = null;
    this._toastT = 0;
  }

  init() {
    for (const b of document.querySelectorAll('[data-go]')) b.addEventListener('click', () => this.h.go(b.dataset.go));
    this._buildGarage();
    this._buildSettings();
    this._buildHud();
    $('start-test').addEventListener('click', () => this.h.startTest());
    $('start-test-top').addEventListener('click', () => this.h.startTest());
    // abas da garagem em telas pequenas (Veículo | Teste)
    const lay = document.querySelector('.garage-layout');
    document.querySelectorAll('.tabs [data-tab]').forEach((b) => b.addEventListener('click', () => {
      lay.dataset.tab = b.dataset.tab;
      document.querySelectorAll('.tabs [data-tab]').forEach((x) => x.classList.toggle('sel', x === b));
    }));

    $('fatal-retry').addEventListener('click', () => location.reload());
    $('about-sys').textContent = '';
  }

  show(name) {
    this.screen = name;
    document.body.dataset.screen = name;
    for (const id of ['menu', 'garage', 'settings', 'about']) $('screen-' + id).classList.toggle('hidden', id !== name);
    $('hud').classList.toggle('hidden', name !== 'track');
    $('loading').classList.add('hidden');
    $('result').classList.add('hidden');
    $('touch').classList.toggle('hidden', !(name === 'track' && this.config.manual && TOUCH));
  }

  toast(msg, warn = false, ms = 3500) {
    const t = $('toast'); t.textContent = msg; t.className = 'toast' + (warn ? ' warn' : '');
    clearTimeout(this._toastT); this._toastT = setTimeout(() => t.classList.add('hidden'), ms);
  }

  fatal(title, msg, detail, help = []) {
    $('loading').classList.add('hidden');
    $('fatal-title').textContent = title; $('fatal-msg').textContent = msg; $('fatal-detail').textContent = detail || '';
    const ul = $('fatal-help'); ul.innerHTML = ''; for (const h of help) { const li = document.createElement('li'); li.textContent = h; ul.appendChild(li); }
    $('fatal').classList.remove('hidden');
  }

  setLoading(msg) { $('loading-msg').textContent = msg; }
  setAbout(text) { $('about-sys').textContent = text; }

  // ---------------------------------------------------------------------------------------------
  // garagem
  // ---------------------------------------------------------------------------------------------
  _buildGarage() {
    const c = this.config;
    const cards = $('veh-cards');
    VEHICLES.forEach((v, i) => {
      const b = document.createElement('button'); b.className = 'veh-card'; b.dataset.i = i;
      b.innerHTML = `<img alt="" width="112" height="58"><span><b>${v.name}</b><small>${v.desc}</small></span>`;
      b.addEventListener('click', () => this.setVehicle(i));
      cards.appendChild(b);
    });
    $('veh-prev').addEventListener('click', () => this.setVehicle((c.vehicle + 2) % 3));
    $('veh-next').addEventListener('click', () => this.setVehicle((c.vehicle + 1) % 3));

    const sw = $('swatches');
    PAINTS.forEach((p, i) => {
      const b = document.createElement('button'); b.className = 'sw'; b.style.background = p[0]; b.title = p[1]; b.setAttribute('aria-label', 'Cor ' + p[1]);
      b.addEventListener('click', () => { c.paint = i; c.customPaint = null; c.finish = p[2]; $('paint-finish').value = this._nearestFinish(p[2]); this._changed(true); });
      sw.appendChild(b);
    });
    $('paint-custom').addEventListener('input', (e) => { c.customPaint = e.target.value; this._changed(true); });
    $('paint-finish').addEventListener('change', (e) => { c.finish = +e.target.value; this._changed(true); });
    $('paint-finish').value = this._nearestFinish(c.finish);

    const mo = $('motors');
    MOTORS.forEach((m, i) => { const b = document.createElement('button'); b.textContent = m; b.addEventListener('click', () => { c.motor = i; this._changed(); }); mo.appendChild(b); });
    $('extra').addEventListener('input', (e) => { c.extra = +e.target.value; this._changed(); });

    const sp = $('speeds');
    SPEEDS.forEach((s) => { const b = document.createElement('button'); b.className = 'chip'; b.textContent = s + ' km/h'; b.dataset.v = s; b.addEventListener('click', () => { c.target = s; $('speed-custom').value = ''; this._changed(); }); sp.appendChild(b); });
    $('speed-custom').addEventListener('input', (e) => {
      const v = parseFloat(e.target.value);
      if (v >= 5 && v <= 250) { c.target = v; this._changed(); }
    });
    const ob = $('obstacles');
    OBSTACLES.forEach((n, i) => { const b = document.createElement('button'); b.textContent = n; b.addEventListener('click', () => { c.obstacle = i; this._changed(); }); ob.appendChild(b); });
    $('face').addEventListener('change', (e) => { c.face = +e.target.value; this._changed(); });
    $('angle').addEventListener('input', (e) => { c.angle = +e.target.value; this._changed(); });
    $('offset').addEventListener('input', (e) => { c.offset = +e.target.value; this._changed(); });
    $('manual').addEventListener('change', (e) => { c.manual = e.target.checked; this._changed(); });
    this._syncGarage();
  }

  _nearestFinish(f) { return ['0.35', '0.0', '0.9'].reduce((a, b) => (Math.abs(+b - f) < Math.abs(+a - f) ? b : a)); }

  setVehicle(i) { this.config.vehicle = i; this._changed(true); }

  _changed(visual = false) {
    store.set('config', this.config);
    this._syncGarage();
    this.h.configChanged(visual);
  }

  _syncGarage() {
    const c = this.config;
    document.querySelectorAll('.veh-card').forEach((b) => b.classList.toggle('sel', +b.dataset.i === c.vehicle));
    document.querySelectorAll('.sw').forEach((b, i) => b.classList.toggle('sel', !c.customPaint && i === c.paint));
    document.querySelectorAll('#motors button').forEach((b, i) => b.classList.toggle('sel', i === c.motor));
    document.querySelectorAll('#speeds .chip').forEach((b) => b.classList.toggle('sel', +b.dataset.v === c.target));
    document.querySelectorAll('#obstacles button').forEach((b, i) => b.classList.toggle('sel', i === c.obstacle));
    $('extra').value = c.extra; $('extra-val').textContent = c.extra + ' kg';
    $('angle').value = c.angle; $('angle-val').textContent = c.angle + '°';
    $('offset').value = c.offset; $('offset-val').textContent = fmt(c.offset, 2) + ' m';
    $('face').value = c.face; $('manual').checked = c.manual;
    if (c.customPaint) $('paint-custom').value = c.customPaint;
    if (!SPEEDS.includes(c.target) && !$('speed-custom').value) $('speed-custom').value = c.target;
  }

  /** cor atual como [r,g,b,metal] em espaço linear */
  paintColor() {
    const c = this.config;
    const hex = c.customPaint || PAINTS[c.paint][0];
    const n = parseInt(hex.slice(1), 16);
    const lin = (v) => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return [lin((n >> 16) & 255), lin((n >> 8) & 255), lin(n & 255), c.finish];
  }

  setThumb(i, url) { const im = document.querySelector(`.veh-card[data-i="${i}"] img`); if (im) im.src = url; }

  renderSpecs(sp, launch) {
    const rows = [
      ['Massa (com carga)', Math.round(sp.mass) + ' kg'], ['Potência', Math.round(sp.power) + ' cv'], ['Torque', Math.round(sp.torque) + ' Nm'],
      ['0–100 km/h (simulado)', fmt(sp.t0100) + ' s'], ['Vel. máx. (equilíbrio)', Math.round(sp.vmax) + ' km/h'], ['Frenagem máx.', fmt(sp.brakeG, 2) + ' g'],
      ['Comprimento × Largura', fmt(sp.length, 2) + ' × ' + fmt(sp.W, 2) + ' m'], ['Altura', fmt(sp.H, 2) + ' m']
    ];
    $('specs').innerHTML = rows.map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('');
    const c = this.config;
    const sled = c.face >= 2;
    let note = `Partida a 200 m da barreira. `;
    if (sled) note += 'Impacto lateral: o veículo é lançado lateralmente (modo trenó).';
    else if (launch && launch.launchKmh > 0) {
      note += `Para impactar a ${Math.round(c.target)} km/h em 200 m o simulador parte de ${Math.round(launch.launchKmh)} km/h.`;
      if (launch.reachable === false) note += ' Alvo acima do alcançável: será o máximo possível.';
    }
    $('launch-note').textContent = note;
  }

  // ---------------------------------------------------------------------------------------------
  // configurações
  // ---------------------------------------------------------------------------------------------
  _buildSettings() {
    const s = this.settings;
    const bind = (id, key, prop = 'value', conv = (v) => v) => {
      const e = $(id); e[prop] = s[key];
      e.addEventListener('input', () => { s[key] = conv(e[prop]); store.set('settings', s); this.h.settingChanged(key, s[key]); });
    };
    bind('set-quality', 'quality'); bind('set-env', 'env'); bind('set-volume', 'volume', 'value', Number);
    bind('set-audio', 'audio', 'checked'); bind('set-shake', 'shake', 'checked'); bind('set-particles', 'particles', 'checked'); bind('set-telemetry', 'telemetry', 'checked');
    $('set-reset').addEventListener('click', () => {
      Object.assign(s, { quality: MOBILE ? 'low' : 'high', env: 'day', volume: 0.5, audio: true, shake: true, particles: true, telemetry: false });
      store.set('settings', s);
      for (const [id, k, p] of [['set-quality', 'quality', 'value'], ['set-env', 'env', 'value'], ['set-volume', 'volume', 'value'], ['set-audio', 'audio', 'checked'], ['set-shake', 'shake', 'checked'], ['set-particles', 'particles', 'checked'], ['set-telemetry', 'telemetry', 'checked']]) { $(id)[p] = s[k]; this.h.settingChanged(k, s[k]); }
    });
  }

  // ---------------------------------------------------------------------------------------------
  // HUD
  // ---------------------------------------------------------------------------------------------
  _buildHud() {
    const box = $('cams');
    CAMERAS.forEach((c, i) => {
      const b = document.createElement('button'); b.textContent = c.label; b.title = 'Tecla ' + c.key; b.dataset.i = i;
      b.addEventListener('click', () => this.h.action('cam' + i)); box.appendChild(b);
    });
    this.damage = new DamageMap($('dmg-map'), (z) => this.showZone(z));
    const act = (id, name) => $(id).addEventListener('click', () => this.h.action(name));
    act('b-start', 'start'); act('b-pause', 'pause'); act('b-restart', 'restart'); act('b-reset200', 'reset200'); act('b-slow', 'slowmo');
    $('b-rate').addEventListener('change', (e) => this.h.action('rate', +e.target.value));
    $('hud-exit').addEventListener('click', () => this.h.go('garage'));
    $('res-again').addEventListener('click', () => this.h.action('restart'));
    $('res-garage').addEventListener('click', () => this.h.go('garage'));
    $('res-close').addEventListener('click', () => $('result').classList.add('hidden'));
    this.gauge = $('gauge').getContext('2d');
  }

  setCamera(i) { document.querySelectorAll('#cams button').forEach((b) => b.classList.toggle('sel', +b.dataset.i === i)); }
  setTitle(t) { $('hud-title').textContent = t; }
  setRate(r) { $('b-rate').value = String(r); }
  setSlow(on) { $('b-slow').classList.toggle('on', on); }
  setPaused(p) { $('b-pause').textContent = p ? '▶ Continuar' : '⏸ Pausar'; $('b-pause').classList.toggle('on', p); }
  setPhase(t) { $('phase').textContent = t; }
  showTelemetry(on) { $('tele').classList.toggle('hidden', !on); }

  showZone(id) {
    if (!this.lastOut) return;
    const i = ZONES.indexOf(id), d = this.lastOut[40 + 2 * i], disp = this.lastOut[41 + 2 * i];
    $('dmg-detail').innerHTML = `<b>${ZONE_LABELS[id]}</b><br>Dano: <b style="color:${damageColor(d)}">${Math.round(d * 100)}% — ${damageLabel(d)}</b><br>Deslocamento permanente: <b>${fmt(disp * 100, 0)} cm</b>`;
  }

  /** atualiza o HUD a cada quadro. v: {speedKmh, dist, time, g, out, gaugeMax} */
  updateHud(v) {
    this.lastOut = v.out;
    $('g-speed').textContent = Math.round(v.speedKmh);
    $('r-dist').textContent = fmt(Math.max(0, v.dist)) + ' m';
    $('r-time').textContent = fmt(v.time, 2) + ' s';
    $('r-g').textContent = fmt(v.g) + ' g';
    $('distfill').style.width = Math.min(100, Math.max(0, (1 - v.dist / 200) * 100)) + '%';
    this.damage.update(v.out);
    $('dmg-total').textContent = Math.round(v.out[56] * 100) + '%';
    if (this.damage.selected) this.showZone(this.damage.selected);
    this._drawGauge(v.speedKmh, v.gaugeMax, v.targetKmh);
  }

  _drawGauge(speed, max, target) {
    const g = this.gauge, W = 260, cx = W / 2, cy = W / 2, R = 108;
    g.clearRect(0, 0, W, W);
    const a0 = Math.PI * 0.75, a1 = Math.PI * 2.25, at = (v) => a0 + (a1 - a0) * Math.min(1, v / max);
    g.lineCap = 'round';
    g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fillStyle = 'rgba(8,11,16,.72)'; g.fill();
    g.lineWidth = 12; g.strokeStyle = 'rgba(255,255,255,.12)'; g.beginPath(); g.arc(cx, cy, R - 10, a0, a1); g.stroke();
    const grad = g.createLinearGradient(0, W, W, 0); grad.addColorStop(0, '#2fd0ff'); grad.addColorStop(0.6, '#ffb03a'); grad.addColorStop(1, '#ff3d2e');
    g.strokeStyle = grad; g.beginPath(); g.arc(cx, cy, R - 10, a0, at(speed)); g.stroke();
    // marcas
    g.fillStyle = '#c9d2e0'; g.font = '11px ui-monospace,monospace'; g.textAlign = 'center'; g.textBaseline = 'middle';
    const step = max > 200 ? 40 : 20;
    for (let v = 0; v <= max; v += step) {
      const a = at(v), c = Math.cos(a), s = Math.sin(a);
      g.lineWidth = 2; g.strokeStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.moveTo(cx + c * (R - 2), cy + s * (R - 2)); g.lineTo(cx + c * (R - 9), cy + s * (R - 9)); g.stroke();
      if (v % (step * 2) === 0) g.fillText(String(v), cx + c * (R - 28), cy + s * (R - 28));
    }
    if (target > 0) { // marca da velocidade-alvo
      const a = at(target), c = Math.cos(a), s = Math.sin(a);
      g.strokeStyle = '#ff7a1a'; g.lineWidth = 4; g.beginPath(); g.moveTo(cx + c * (R + 2), cy + s * (R + 2)); g.lineTo(cx + c * (R - 16), cy + s * (R - 16)); g.stroke();
    }
    const a = at(speed), c = Math.cos(a), s = Math.sin(a);
    g.strokeStyle = '#fff'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - c * 8, cy - s * 8); g.lineTo(cx + c * (R - 26), cy + s * (R - 26)); g.stroke();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(cx, cy, 6, 0, Math.PI * 2); g.fill();
  }

  // ---------------------------------------------------------------------------------------------
  // resultado
  // ---------------------------------------------------------------------------------------------
  showResult(r) {
    const o = r.out, parts = [];
    const rows = [
      ['Obstáculo', OBSTACLES[this.config.obstacle]], ['Velocidade-alvo', fmt(r.target, 0) + ' km/h'], ['Velocidade de lançamento (a 200 m)', fmt(r.launch, 0) + ' km/h'],
      ['Velocidade real de impacto', fmt(o[22] * 3.6) + ' km/h'], ['Componente normal à superfície', fmt(o[23] * 3.6) + ' km/h'],
      ['Energia cinética no impacto (½mv²)', fmt(o[25] / 1000, 1) + ' kJ'], ['Energia dissipada por esmagamento', fmt(o[29] / 1000, 1) + ' kJ'],
      ['Impulso normal', fmt(o[26] / 1000, 1) + ' kN·s'], ['Força normal máxima', fmt(o[82] / 1000, 0) + ' kN'],
      ['Pico de desaceleração (corpo rígido)', fmt(o[28], 0) + ' g'], ['Duração do contato', fmt(o[81] * 1000, 0) + ' ms'],
      ['Esmagamento máximo (frente)', fmt(r.maxCrush * 100, 0) + ' cm'], ['Dano global', Math.round(o[56] * 100) + '%']
    ];
    for (let i = 0; i < ZONES.length; i++) rows.push(['Dano — ' + ZONE_LABELS[ZONES[i]], Math.round(o[40 + 2 * i] * 100) + '%']);
    const b = o[58] | 0;
    if (b & BRK.WSHIELD) parts.push('para-brisa'); if (b & BRK.RGLASS) parts.push('vidro traseiro'); if (b & (BRK.WIN_L | BRK.WIN_R)) parts.push('vidros laterais');
    if (b & (BRK.HEAD_L | BRK.HEAD_R)) parts.push('faróis'); if (b & (BRK.TAIL_L | BRK.TAIL_R)) parts.push('lanternas'); if (b & BRK.HOOD) parts.push('capô');
    rows.push(['Componentes quebrados', parts.length ? parts.join(', ') : 'nenhum']);
    $('result-body').innerHTML = `<table>${rows.map((x) => `<tr><td>${x[0]}</td><td>${x[1]}</td></tr>`).join('')}</table>` +
      `<p class="warn">Modelo simplificado de corpo rígido com esmagamento — não é análise por elementos finitos. As desacelerações não representam as sofridas por ocupantes.</p>`;
    $('result').classList.remove('hidden');
  }
}
