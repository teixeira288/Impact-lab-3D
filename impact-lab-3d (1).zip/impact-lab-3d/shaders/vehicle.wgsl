// vehicle.wgsl - carroceria, vidros, faróis, interior e rodas dos veículos (PBR + efeitos procedurais)
// Pressupõe lighting.wgsl concatenado antes.

struct VehU {
  model: mat4x4f,
  paint: vec4f,        // rgb, metálico (0..1)
  flags: vec4f,        // x: máscara de componentes quebrados, y: luz de freio, z: faróis ligados, w: velocidade (km/h)
  arch: array<vec4f, 4>, // centro local (x,y,z) e raio do recorte do arco da roda
  doorZ: vec4f,        // z das janelas laterais (w1a, w1b, w2a, w2b)
  misc: vec4f,         // beltY, sillY, cluster cx, cluster cy
  misc2: vec4f,        // cluster cz, hoodTopY, meia-largura, tempo
};
@group(1) @binding(0) var<uniform> veh: VehU;
@group(1) @binding(1) var<uniform> wheelMats: array<mat4x4f, 4>;

const M_PAINT: u32 = 0u;
const M_PLASTIC: u32 = 1u;
const M_RUBBER: u32 = 2u;
const M_GLASS_WS: u32 = 3u;
const M_GLASS_RR: u32 = 4u;
const M_GLASS_L: u32 = 5u;
const M_GLASS_R: u32 = 6u;
const M_HEAD_L: u32 = 7u;
const M_HEAD_R: u32 = 8u;
const M_TAIL_L: u32 = 9u;
const M_TAIL_R: u32 = 10u;
const M_INTERIOR: u32 = 11u;
const M_METAL: u32 = 12u;
const M_CLUSTER: u32 = 13u;
const M_SCREEN: u32 = 14u;
const M_UNDER: u32 = 15u;
const M_BED: u32 = 16u;

fn brokenBit(bit: u32) -> bool {
  return (u32(veh.flags.x + 0.5) & (1u << bit)) != 0u;
}

struct VOut {
  @builtin(position) clip: vec4f,
  @location(0) wpos: vec3f,
  @location(1) wn: vec3f,
  @location(2) rpos: vec3f,
  @location(3) dmg: f32,
  @location(4) @interpolate(flat) mat: u32,
  @location(5) lnorm: vec3f,
};

@vertex
fn vs_body(@location(0) pos: vec4f, @location(1) nrm: vec4f, @location(2) rest: vec4f, @builtin(instance_index) ii: u32) -> VOut {
  var o: VOut;
  let wp = veh.model * vec4f(pos.xyz, 1.0);
  o.clip = frame.viewProj * wp;
  o.wpos = wp.xyz;
  o.wn = normalize((veh.model * vec4f(nrm.xyz, 0.0)).xyz);
  o.rpos = rest.xyz;
  o.dmg = pos.w;
  o.mat = ii;
  o.lnorm = nrm.xyz;
  return o;
}

@vertex
fn vs_shadow_body(@location(0) pos: vec4f) -> @builtin(position) vec4f {
  return frame.lightVP * veh.model * vec4f(pos.xyz, 1.0);
}

@vertex
fn vs_shadow_wheel(@location(0) pos: vec4f, @builtin(instance_index) ii: u32) -> @builtin(position) vec4f {
  return frame.lightVP * wheelMats[ii] * vec4f(pos.xyz, 1.0);
}

fn gaugeDial(q: vec2f, v: f32) -> vec3f {
  let r = length(q);
  var col = vec3f(0.0);
  let ring = smoothstep(0.004, 0.0, abs(r - 0.050));
  col += vec3f(0.1, 0.8, 1.0) * ring * 0.9;
  let ang = atan2(q.x, q.y);
  let tick = step(0.92, fract((ang + 2.4) / 0.52)) * step(0.040, r) * step(r, 0.046) * step(abs(ang), 2.4);
  col += vec3f(0.8, 0.95, 1.0) * tick * 0.8;
  let a = mix(-2.35, 2.35, clamp(v, 0.0, 1.0));
  let d = vec2f(sin(a), cos(a));
  let pr = dot(q, d);
  let pp = abs(dot(q, vec2f(d.y, -d.x)));
  let needle = step(0.0, pr) * step(pr, 0.046) * smoothstep(0.0032, 0.0008, pp);
  col += vec3f(1.0, 0.25, 0.1) * needle * 1.6;
  col += vec3f(0.05, 0.12, 0.2) * smoothstep(0.052, 0.0, r) * 0.6;
  return col;
}

fn doorSeam(z: f32) -> f32 {
  let d = veh.doorZ;
  var m = 0.0;
  let z0 = d.x + 0.10;
  let z2 = select(d.y, d.w, d.w != 0.0);
  let z1 = select(d.y - 0.02, 0.5 * (d.y + d.z), d.z != 0.0);
  let zr = z2 - 0.12;
  m = max(m, smoothstep(0.0045, 0.002, abs(z - z0)));
  m = max(m, smoothstep(0.0045, 0.002, abs(z - z1)));
  m = max(m, smoothstep(0.0045, 0.002, abs(z - zr)));
  return m;
}

@fragment
fn fs_body(in: VOut, @builtin(front_facing) ff: bool) -> @location(0) vec4f {
  let m = in.mat;
  var N = normalize(in.wn);
  if (!ff) { N = -N; }
  let V = normalize(frame.camPos.xyz - in.wpos);
  let halfW = veh.misc2.z;

  // recorte dos arcos das rodas nas superfícies laterais da carroceria
  if (m == M_PAINT || m == M_PLASTIC) {
    for (var w = 0; w < 4; w++) {
      let c = veh.arch[w];
      if (sign(in.rpos.x) == sign(c.x) && abs(in.rpos.x) > 0.55 * halfW) {
        let d = length(in.rpos.yz - c.yz);
        if (d < c.w) { discard; }
      }
    }
  }
  let sh = shadowFactor(in.wpos, N);
  let R = reflect(-V, N);
  let NdV = max(dot(N, V), 0.0);
  var col = vec3f(0.0);

  if (!ff && (m == M_PAINT || m == M_PLASTIC || m == M_UNDER || m == M_BED)) {
    // face interna da lataria: forro do veículo
    col = shadePBR(vec3f(0.055, 0.055, 0.06) + 0.03 * hash31(floor(in.rpos * 40.0)), 0.0, 0.9, N, V, in.wpos, sh * 0.6, 0.5);
    return finishColor(col, in.wpos);
  }

  if (m == M_PAINT) {
    var albedo = veh.paint.rgb;
    var metallic = veh.paint.a * 0.75;
    var rough = 0.34 + 0.2 * (1.0 - veh.paint.a);
    if (veh.paint.a > 0.5) {
      let f = hash31(floor(in.rpos * 220.0));
      albedo *= 0.85 + 0.35 * f;
      rough -= 0.06 * pow(f, 6.0);
    }
    // soleiras em plástico escuro e frisos das portas
    let sill = smoothstep(veh.misc.y, veh.misc.y - 0.06, in.rpos.y);
    albedo = mix(albedo, vec3f(0.03), sill * 0.9);
    metallic = mix(metallic, 0.0, sill);
    if (abs(in.lnorm.x) > 0.6 && in.rpos.y > veh.misc.y && in.rpos.y < veh.misc.x) {
      let seam = doorSeam(in.rpos.z);
      albedo = mix(albedo, vec3f(0.01), seam * 0.9);
    }
    // danos: pintura raspada, metal exposto e sujeira de impacto
    let dm = in.dmg;
    let scratch = smoothstep(0.35, 0.8, fbm(in.rpos.xz * 14.0 + in.rpos.y * 9.0) + dm * 0.55);
    let bare = vec3f(0.33, 0.32, 0.31);
    albedo = mix(albedo, bare, clamp(scratch * smoothstep(0.08, 0.5, dm), 0.0, 1.0) * 0.8);
    albedo *= 1.0 - 0.45 * smoothstep(0.35, 1.0, dm) * (0.5 + 0.5 * vnoise(in.rpos.xy * 25.0));
    metallic = mix(metallic, 0.3, smoothstep(0.1, 0.5, dm));
    rough = mix(rough, 0.7, smoothstep(0.05, 0.5, dm));
    col = shadePBR(albedo, metallic, rough, N, V, in.wpos, sh, 1.0);
    // verniz (clear coat)
    let fcc = 0.04 + 0.96 * pow(1.0 - NdV, 5.0);
    col += envColor(R) * fcc * 0.9 * (1.0 - smoothstep(0.1, 0.6, dm)) * smoothstep(-0.1, 0.1, R.y);
    return finishColor(col, in.wpos);
  }
  if (m == M_PLASTIC) {
    col = shadePBR(vec3f(0.03) + 0.02 * vnoise(in.rpos.xy * 60.0), 0.0, 0.55, N, V, in.wpos, sh, 0.8);
    // aletas da grade / entradas de ar
    let slat = smoothstep(0.35, 0.5, abs(sin(in.rpos.y * 90.0)));
    col *= 0.6 + 0.6 * slat;
    return finishColor(col, in.wpos);
  }
  if (m == M_UNDER) {
    col = shadePBR(vec3f(0.02), 0.0, 0.9, N, V, in.wpos, sh, 0.35);
    return finishColor(col, in.wpos);
  }
  if (m == M_BED) {
    let ridge = 0.5 + 0.5 * sin(in.rpos.z * 38.0);
    col = shadePBR(vec3f(0.018 + 0.01 * ridge), 0.0, 0.5, N, V, in.wpos, sh, 1.0);
    return finishColor(col, in.wpos);
  }
  if (m == M_INTERIOR) {
    let up = clamp(N.y, 0.0, 1.0);
    let alb = vec3f(0.045, 0.047, 0.052) + vec3f(0.04) * up + 0.02 * hash31(floor(in.rpos * 120.0));
    col = shadePBR(alb, 0.0, 0.82, N, V, in.wpos, mix(1.0, sh, 0.5), 0.55);
    return finishColor(col, in.wpos);
  }
  if (m == M_METAL) {
    col = shadePBR(vec3f(0.75, 0.75, 0.72), 0.0, 0.5, N, V, in.wpos, sh, 1.0);
    return finishColor(col, in.wpos);
  }
  if (m == M_CLUSTER) {
    let q = in.rpos.xy - veh.misc.zw;
    let spd = veh.flags.w / 240.0;
    var g = gaugeDial(q - vec2f(-0.075, 0.0), spd);
    g += gaugeDial(q - vec2f(0.075, 0.0), 0.25 + 0.5 * clamp(veh.flags.w / 200.0, 0.0, 1.0) * 0.6);
    col = vec3f(0.01, 0.02, 0.03) + g;
    return finishColor(col * 1.5, in.wpos);
  }
  if (m == M_SCREEN) {
    let t = veh.misc2.w;
    let road = smoothstep(0.02, 0.0, abs(in.rpos.x * 3.0 + sin(in.rpos.y * 25.0 - t * 2.0) * 0.15));
    col = vec3f(0.03, 0.08, 0.16) + vec3f(0.1, 0.5, 0.9) * road * 0.5 + vec3f(0.06, 0.1, 0.2) * fbm(in.rpos.xy * 30.0);
    return finishColor(col * 1.6, in.wpos);
  }
  if (m == M_HEAD_L || m == M_HEAD_R) {
    let isBroken = select(brokenBit(1u), brokenBit(0u), m == M_HEAD_L);
    let on = veh.flags.z;
    let core = smoothstep(0.6, 0.0, abs(fract(in.rpos.x * 14.0) - 0.5) * 1.6);
    var base = vec3f(0.30, 0.33, 0.37) * (0.35 + 0.65 * core) + vec3f(1.0, 0.96, 0.85) * on * 3.0 * (0.4 + core);
    if (isBroken) {
      let cr = 1.0 - smoothstep(0.0, 0.05, voronoiEdge(in.rpos.xy * 28.0 + in.rpos.z * 11.0));
      base = vec3f(0.12, 0.12, 0.13) + vec3f(0.5) * cr;
    }
    col = base * mix(1.0, 0.6, 1.0 - sh) + shadePBR(vec3f(0.02), 0.0, 0.1, N, V, in.wpos, sh, 1.0) * 0.5;
    return finishColor(col, in.wpos);
  }
  if (m == M_TAIL_L || m == M_TAIL_R) {
    let isBroken = select(brokenBit(5u), brokenBit(4u), m == M_TAIL_L);
    var base = vec3f(0.55, 0.02, 0.02) * (0.5 + 0.5 * smoothstep(0.3, 0.0, abs(fract(in.rpos.x * 11.0) - 0.5))) + vec3f(1.0, 0.1, 0.05) * veh.flags.y * 3.2;
    if (isBroken) {
      let cr = 1.0 - smoothstep(0.0, 0.05, voronoiEdge(in.rpos.xy * 28.0 + in.rpos.z * 11.0));
      base = vec3f(0.12, 0.02, 0.02) + vec3f(0.5, 0.3, 0.3) * cr;
    }
    col = base + shadePBR(vec3f(0.02), 0.0, 0.1, N, V, in.wpos, sh, 1.0) * 0.4;
    return finishColor(col, in.wpos);
  }
  return vec4f(1.0, 0.0, 1.0, 1.0);
}

// ---------------------------------------------------------------------------------------------
// vidros (blend)
// ---------------------------------------------------------------------------------------------
@fragment
fn fs_glass(in: VOut, @builtin(front_facing) ff: bool) -> @location(0) vec4f {
  var N = normalize(in.wn);
  if (!ff) { N = -N; }
  let V = normalize(frame.camPos.xyz - in.wpos);
  let R = reflect(-V, N);
  let NdV = max(dot(N, V), 0.0);
  let fres = 0.05 + 0.95 * pow(1.0 - NdV, 4.0);
  var tint = vec3f(0.015, 0.022, 0.03);
  var alpha = mix(0.30, 0.92, fres);
  var broken = false;
  var uv = in.rpos.xz * 5.0;
  if (in.mat == M_GLASS_WS) { broken = brokenBit(2u); uv = in.rpos.xz * 5.0; }
  if (in.mat == M_GLASS_RR) { broken = brokenBit(3u); uv = in.rpos.xz * 5.0; }
  if (in.mat == M_GLASS_L) { broken = brokenBit(6u); uv = in.rpos.zy * 6.0; }
  if (in.mat == M_GLASS_R) { broken = brokenBit(7u); uv = in.rpos.zy * 6.0; }
  var col = envColor(R) * fres * 1.1 + tint;
  col += shadePBR(vec3f(0.0), 0.0, 0.05, N, V, in.wpos, shadowFactor(in.wpos, N), 1.0) * 0.6;
  if (broken) {
    let e = voronoiEdge(uv + vec2f(hash21(floor(uv)) * 0.0, 0.0));
    let e2 = voronoiEdge(uv * 2.7 + 5.0);
    let cr = max(1.0 - smoothstep(0.0, 0.07, e), 0.6 * (1.0 - smoothstep(0.0, 0.06, e2)));
    col = mix(col, vec3f(0.75, 0.8, 0.85) * (0.4 + 0.6 * max(dot(N, normalize(frame.sunDir.xyz)), 0.2)), cr * 0.85);
    alpha = clamp(alpha + cr * 0.6 + 0.25, 0.0, 0.97);
    // buracos: fragmentos faltantes (vidro quebrado e solto)
    let hole = hash21(floor(uv * 1.3) + 3.0);
    if (hole > 0.93 && in.dmg > 0.0) { discard; }
  }
  let f = finishColor(col, in.wpos);
  return vec4f(f.rgb, alpha);
}

// ---------------------------------------------------------------------------------------------
// rodas (4 instâncias, matrizes em wheelMats)
// ---------------------------------------------------------------------------------------------
struct WOut {
  @builtin(position) clip: vec4f,
  @location(0) wpos: vec3f,
  @location(1) wn: vec3f,
  @location(2) lpos: vec3f,
  @location(3) code: f32,
};

@vertex
fn vs_wheel(@location(0) pos: vec4f, @location(1) nrm: vec4f, @builtin(instance_index) ii: u32) -> WOut {
  var o: WOut;
  let M = wheelMats[ii];
  let wp = M * vec4f(pos.xyz, 1.0);
  o.clip = frame.viewProj * wp;
  o.wpos = wp.xyz;
  o.wn = normalize((M * vec4f(nrm.xyz, 0.0)).xyz);
  o.lpos = pos.xyz / max(nrm.w, 0.01);   // normalizado pelo raio do aro
  o.code = pos.w;
  return o;
}

@fragment
fn fs_wheel(in: WOut, @builtin(front_facing) ff: bool) -> @location(0) vec4f {
  var N = normalize(in.wn);
  if (!ff) { N = -N; }
  let V = normalize(frame.camPos.xyz - in.wpos);
  let sh = shadowFactor(in.wpos, N);
  let code = u32(in.code + 0.5);
  let r = length(in.lpos.yz);
  var col = vec3f(0.0);
  if (code == 20u) {
    let tread = 0.5 + 0.5 * sin(atan2(in.lpos.z, in.lpos.y) * 60.0);
    let band = smoothstep(0.35, 0.5, abs(in.lpos.x) / 0.5);
    col = shadePBR(vec3f(0.022 + 0.006 * tread * (1.0 - band)), 0.0, 0.88, N, V, in.wpos, sh, 0.75);
  } else if (code == 21u) {
    let a = atan2(in.lpos.z, in.lpos.y);
    let lobe = smoothstep(0.50, 0.62, abs(sin(2.5 * a)));
    let hub = step(r, 0.38);
    let lip = step(0.93, r);
    if (hub + lip + lobe < 0.5) { discard; }
    col = shadePBR(vec3f(0.74, 0.76, 0.80), 0.95, 0.22, N, V, in.wpos, sh, 0.9);
  } else if (code == 22u) {
    let groove = 0.7 + 0.3 * sin(r * 55.0);
    col = shadePBR(vec3f(0.30, 0.28, 0.27) * groove, 0.85, 0.5, N, V, in.wpos, sh, 0.5);
  } else {
    col = shadePBR(vec3f(0.035), 0.5, 0.6, N, V, in.wpos, sh, 0.4);
  }
  return finishColor(col, in.wpos);
}
