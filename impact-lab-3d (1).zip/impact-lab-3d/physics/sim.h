/*
 * Impact Lab 3D - motor físico (C -> WebAssembly)
 *
 * Unidades SI: metros, segundos, quilogramas, newtons, joules.
 * Sistema de coordenadas (mão direita, Y para cima):
 *   - A parede/obstáculo ocupa o plano z = 0; o veículo começa em z = -200 m e se move para +z.
 *   - Eixos locais do veículo: +z = frente, +x = LADO ESQUERDO, +y = cima. Origem = CG projetado no solo.
 *   - yaw (psi) positivo gira de +z para +x (curva à esquerda).
 *     frente = (sin psi, cos psi), esquerda = (cos psi, -sin psi).
 *
 * Modelo (simplificado, NÃO é elementos finitos):
 *   - Corpo rígido planar (x, z, yaw) com modelo de pneus tipo "bicicleta" e transferência de carga.
 *   - Colisão: 36 pontos de contato na superfície da carroceria (9 por face: frente, traseira,
 *     esquerda, direita). Cada ponto tem uma lei força x esmagamento (plástica com histerese).
 *   - O esmagamento permanente de cada ponto alimenta o campo de deformação da malha 3D (GPU).
 */
#ifndef IMPACT_LAB_SIM_H
#define IMPACT_LAB_SIM_H

#ifdef __wasm__
#define SIM_EXPORT(n) __attribute__((export_name(n)))
#else
#define SIM_EXPORT(n)
#endif

#define SIM_VERSION      3
#define SIM_NFACE        4
#define SIM_PER_FACE     9
#define SIM_NSAMP        36
#define SIM_SAMPLE_STRIDE 8
#define SIM_OUT_COUNT    128
#define SIM_SPEC_COUNT   16

/* faces */
enum { FACE_FRONT = 0, FACE_REAR = 1, FACE_LEFT = 2, FACE_RIGHT = 3 };
/* veículos */
enum { VEH_HATCH = 0, VEH_SEDAN = 1, VEH_SUV = 2 };
/* obstáculos */
enum { OBS_WALL = 0, OBS_BARRIER = 1, OBS_POLE = 2, OBS_BLOCK = 3 };
/* fases */
enum { PH_IDLE = 0, PH_RUNNING = 1, PH_IMPACT = 2, PH_SETTLED = 3 };

/* zonas do mapa de danos */
enum { Z_FRONT = 0, Z_HOOD, Z_LEFT, Z_RIGHT, Z_ROOF, Z_REAR, Z_WHEELS, Z_STRUCT, Z_COUNT };

/* bits de componentes quebrados */
#define BRK_HEAD_L   (1 << 0)
#define BRK_HEAD_R   (1 << 1)
#define BRK_WSHIELD  (1 << 2)
#define BRK_RGLASS   (1 << 3)
#define BRK_TAIL_L   (1 << 4)
#define BRK_TAIL_R   (1 << 5)
#define BRK_WIN_L    (1 << 6)
#define BRK_WIN_R    (1 << 7)
#define BRK_HOOD     (1 << 8)
#define BRK_BUMPER_F (1 << 9)
#define BRK_BUMPER_R (1 << 10)

/* índices do vetor de saída (floats) */
#define O_T          0   /* tempo de simulação [s] */
#define O_X          1   /* CG, mundo [m] */
#define O_Z          2
#define O_Y          3   /* (reservado) */
#define O_YAW        4   /* [rad] */
#define O_PITCH      5   /* [rad] + = nariz para cima (visual) */
#define O_ROLL       6   /* [rad] + = lado esquerdo sobe (visual) */
#define O_SPEED      7   /* |v| [m/s] */
#define O_U          8   /* velocidade longitudinal (com sinal) [m/s] */
#define O_V          9   /* velocidade lateral [m/s] */
#define O_VX         10
#define O_VZ         11
#define O_OMEGA      12  /* velocidade de guinada [rad/s] */
#define O_ALONG      13  /* aceleração longitudinal filtrada [m/s²] */
#define O_ALAT       14
#define O_GNOW       15  /* |a| filtrada / g */
#define O_DIST       16  /* distância ponto de referência -> superfície [m] */
#define O_THR        17
#define O_BRK        18
#define O_STEER      19  /* esterçamento aplicado [rad] */
#define O_PHASE      20
#define O_IMPACTED   21  /* 1 após o primeiro contato */
#define O_VBEFORE    22  /* velocidade imediatamente antes do contato [m/s] */
#define O_VNORM      23  /* componente normal à parede antes do contato [m/s] */
#define O_TIMPACT    24  /* instante do primeiro contato [s] */
#define O_KE0        25  /* energia cinética antes do impacto [J] = 1/2 m v² */
#define O_IMPULSE    26  /* impulso normal acumulado [N·s] */
#define O_PEAKA      27  /* desaceleração máxima filtrada [m/s²] */
#define O_PEAKG      28
#define O_ECRUSH     29  /* energia dissipada por esmagamento [J] */
#define O_EFRIC      30  /* energia dissipada por atrito com o obstáculo [J] */
#define O_MASS       31
#define O_TARGET     32  /* velocidade-alvo [m/s] */
#define O_LAUNCH     33  /* velocidade inicial de lançamento [m/s] */
#define O_SPIN       34  /* ângulo de rotação das rodas [rad] */
#define O_KENOW      35  /* energia cinética atual (translação+rotação) [J] */
#define O_ZONE0      40  /* 8 zonas x (dano 0..1, deslocamento [m]) = 40..55 */
#define O_DAMAGE     56  /* índice global de dano 0..1 */
#define O_STATE      57  /* 0 íntegro .. 4 falha estrutural */
#define O_BROKEN     58  /* máscara de bits BRK_* */
#define O_IMPX       60  /* ponto do primeiro contato (mundo) */
#define O_IMPY       61
#define O_IMPZ       62
#define O_IMPLX      63  /* ponto do primeiro contato (local do veículo) */
#define O_IMPLZ      64
#define O_EVENTS     65  /* contador de novos eventos de contato */
#define O_EVSTR      66  /* intensidade (força total) do último evento [N] */
#define O_NCONTACT   67  /* pontos em contato agora */
#define O_FTOTAL     68  /* força normal total agora [N] */
#define O_BRAKELIGHT 69
#define O_OBSTRAVEL  70  /* deslocamento da barreira deformável [m] */
#define O_ANGLEDEG   71  /* ângulo de impacto estimado (rumo da velocidade vs normal) [graus] */
#define O_VAFTER     72  /* velocidade pós-impacto (atual, após 1º contato) */
#define O_SLED       73
#define O_MODE       74
#define O_FACE       75
#define O_OBSTACLE   76
#define O_REFX       77  /* ponto de referência frontal (mundo) */
#define O_REFZ       78
#define O_STEPS      79  /* passos fixos executados */
#define O_YAWDEG_IMP 80  /* guinada acumulada desde o impacto [graus] */
#define O_CONTACT_T  81  /* duração do contato [s] */
#define O_PEAKF      82  /* força normal total máxima [N] */
#define O_NSUB       83  /* sub-passos CCD no último passo */
#define O_JVEC_X     84  /* impulso vetorial acumulado (mundo) */
#define O_JVEC_Z     85

/* índices do vetor de especificações (sim_spec / sim_vehicle_dims) */
#define S_MASS   0
#define S_POWER  1   /* cv */
#define S_TORQUE 2   /* Nm */
#define S_0100   3   /* s (simulado) */
#define S_VMAX   4   /* km/h (equilíbrio de potência) */
#define S_ZF     5   /* extensão frontal a partir do CG [m] */
#define S_ZR     6
#define S_WIDTH  7
#define S_HEIGHT 8
#define S_A      9   /* CG -> eixo dianteiro */
#define S_B      10  /* CG -> eixo traseiro */
#define S_HCG    11
#define S_RW     12  /* raio da roda */
#define S_TRACK  13
#define S_BRAKEG 14
#define S_LENGTH 15

#ifdef __cplusplus
extern "C" {
#endif

SIM_EXPORT("sim_version")        int    sim_version(void);
SIM_EXPORT("sim_out_count")      int    sim_out_count(void);
SIM_EXPORT("sim_out")            float *sim_out(void);
SIM_EXPORT("sim_crush")          float *sim_crush(void);    /* 36 floats: esmagamento visual atual por ponto [m] */
SIM_EXPORT("sim_samples")        float *sim_samples(void);  /* 36 x 8: lx, lz, nx, nz, face, cap, 0, 0 */
SIM_EXPORT("sim_crush_dir")      float *sim_crush_dir(void);/* 36 x 2: direção local (x,z) do esmagamento de cada ponto */
SIM_EXPORT("sim_spec_ptr")       float *sim_spec_ptr(void);

SIM_EXPORT("sim_vehicle_dims")   void   sim_vehicle_dims(int veh, int motor, float extra_mass_kg);
SIM_EXPORT("sim_configure")      void   sim_configure(int veh, int motor, float extra_mass_kg, int obstacle,
                                                      float target_kmh, int face, float angle_deg,
                                                      float offset_m, int mode);
SIM_EXPORT("sim_reset")          void   sim_reset(void);
SIM_EXPORT("sim_start")          void   sim_start(void);
SIM_EXPORT("sim_set_input")      void   sim_set_input(float throttle, float brake, float steer);
SIM_EXPORT("sim_set_gear")       void   sim_set_gear(int gear);
SIM_EXPORT("sim_step")           void   sim_step(float dt);
SIM_EXPORT("sim_wheel_info")     void   sim_wheel_info(float *out8);

#ifdef __cplusplus
}
#endif
#endif
